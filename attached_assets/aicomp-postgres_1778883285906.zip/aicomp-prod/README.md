# AIComp — AI-Powered Electronics Comparison Platform

> India's most advanced electronics comparison platform. GSMArena + Smartprix + PCPartPicker — but AI-driven.

**Live:** https://aicomp.in · **Repo:** https://github.com/SayedTouseef/aicomp

---

## 🏗️ Project Structure

```
aicomp/
├── apps/
│   ├── web/          → Next.js 14 consumer website (port 3000)
│   ├── admin/        → Next.js 14 admin dashboard (port 3001)
│   ├── api/          → Express.js REST API (port 4000)
│   └── extension/    → Chrome/Edge browser extension
├── packages/
│   ├── database/     → Prisma schema + seed
│   ├── types/        → Shared TypeScript types
│   └── utils/        → Shared utility functions
├── scripts/          → SQL init scripts
├── docker/           → Nginx config
└── docker-compose.yml
```

---

## 🚀 Local Development

### Prerequisites
- Node.js 20+
- pnpm 9+
- PostgreSQL 15+
- Redis (optional for caching)

### 1. Install dependencies
```bash
pnpm install
```

### 2. Set up environment
```bash
cp .env.example .env
# Edit .env with your values
```

### 3. Set up database
```bash
# Create PostgreSQL database
createdb aicomp

# Generate Prisma client
pnpm db:generate

# Run migrations
pnpm db:migrate

# Seed initial data
pnpm db:seed
```

### 4. Start development servers
```bash
pnpm dev
# Web:   http://localhost:3000
# Admin: http://localhost:3001
# API:   http://localhost:4000
```

---

## 🎨 Theme System

AIComp uses **next-themes** with Tailwind `darkMode: 'class'`.

- **Default:** Dark mode (`#050810` background)
- **Light mode:** Clean white (`#f8fafc`)
- **System:** Follows OS preference
- **Persisted:** `localStorage` key `aicomp-theme`

Theme toggle is in the **Navbar** (Sun/Moon/System icons).

CSS variables are defined in `globals.css`:
```css
:root { /* dark mode */ }
.light { /* light mode */ }
```

---

## 🔑 Admin Login

After seeding:
- **URL:** http://localhost:3001/dashboard
- **Email:** admin@aicomp.in
- **Password:** admin@aicomp123

**Change the password immediately in production.**

---

## 📦 Adding Products

### Via Admin Panel
1. Go to http://localhost:3001/products
2. Click "Add Product"
3. Fill in name, brand, category, specs
4. Upload images
5. Set prices for each seller
6. Submit for review → Approve

### Via API (admin token required)
```bash
curl -X POST http://localhost:4000/api/v1/products \
  -H "Authorization: Bearer YOUR_ADMIN_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Samsung Galaxy S25",
    "brandId": "brand_id",
    "categoryId": "category_id",
    "specs": {
      "Display": [{ "name": "Screen Size", "value": "6.7", "unit": "inches" }]
    }
  }'
```

### Via Database seed
Edit `packages/database/seed.ts` and add products to the seed array.

---

## 🔍 SEO Management

### Dynamic metadata
Every page generates metadata via `generateMetadata()`:
```ts
export async function generateMetadata({ params }): Promise<Metadata> {
  const product = await getProduct(params.slug);
  return {
    title: `${product.name} Price in India, Specs & Review`,
    description: product.shortDesc,
    openGraph: { images: [product.thumbnail] },
    alternates: { canonical: `https://aicomp.in/products/${params.slug}` },
  };
}
```

### JSON-LD schemas
- **Product pages:** Product schema with offers, ratings
- **Breadcrumbs:** BreadcrumbList schema  
- **Organization:** In Footer

### Sitemap
Auto-generated at `/sitemap.xml` via `src/app/sitemap.ts`.
Add product slugs from DB by fetching the API.

### Robots.txt
Auto-generated at `/robots.txt` via `src/app/robots.txt/route.ts`.

---

## 🚢 Deployment

### Frontend → Vercel
```bash
# Install Vercel CLI
npm i -g vercel

# Deploy
cd apps/web
vercel --prod

# Environment variables needed:
# NEXT_PUBLIC_API_URL=https://api.aicomp.in
# NEXTAUTH_URL=https://aicomp.in
# NEXTAUTH_SECRET=your_secret
```

`vercel.json` in `apps/web/`:
```json
{
  "buildCommand": "pnpm build",
  "outputDirectory": ".next",
  "framework": "nextjs"
}
```

### API → Railway
```bash
# Install Railway CLI
npm i -g @railway/cli

railway login
railway init
railway up
```

Set environment variables in Railway dashboard.

### Database → Neon (PostgreSQL)
1. Create project at https://neon.tech
2. Copy connection string
3. Set `DATABASE_URL` in Railway environment
4. Run: `npx prisma migrate deploy`

### Admin → Vercel (separate project)
```bash
cd apps/admin
vercel --prod
```

---

## 🤖 AI Features Setup

Add your OpenAI key to `.env`:
```
OPENAI_API_KEY=sk-your-key-here
```

AI features work without the key (fallback responses), but full AI requires GPT-4 access.

**AI endpoints:**
- `POST /api/v1/ai/chat` — Shopping assistant
- `POST /api/v1/ai/chat/stream` — Streaming chat
- `POST /api/v1/ai/compare` — Comparison verdict
- `GET /api/v1/ai/should-i-buy/:id` — Buy prediction
- `GET /api/v1/products/:slug/ai-summary` — Product summary

---

## 📊 Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | Next.js 14, React 18, TailwindCSS, Framer Motion |
| Theme | next-themes (dark/light/system) |
| State | TanStack Query v5, Zustand |
| Backend | Express.js, TypeScript |
| Database | PostgreSQL + Prisma ORM |
| Cache | Redis (ioredis) |
| AI | OpenAI GPT-4 |
| Auth | JWT + bcrypt |
| Build | Turborepo, pnpm workspaces |
| Deploy | Vercel (web/admin), Railway (api), Neon (db) |

---

## 🌐 Routes Reference

| Route | Description |
|-------|-------------|
| `/` | Homepage with AI features |
| `/products` | All products listing |
| `/products/[slug]` | Product detail page |
| `/category/[slug]` | Category listing with filters |
| `/compare` | Side-by-side comparison |
| `/search` | Search results |
| `/deals` | Live price deals |
| `/gaming` | GPU benchmark database |
| `/pc-builder` | PC build tool |
| `/ai-assistant` | Chat with AI |
| `/guides` | Buying guides |
| `/launches` | New product launches |
| `/wishlist` | Saved products |
| `/alerts` | Price alerts |
| `/account` | User profile |

---

## 💡 Key Design Decisions

1. **Dark-first design** — Indian electronics buyers prefer dark UI for extended browsing
2. **CSS variables for theming** — Fast theme switching without re-renders
3. **Paise for prices** — All prices stored in paise (₹×100) for precision
4. **No Prisma binary in API** — API uses `pg` directly for Docker compatibility; Prisma only in packages/database
5. **React Query** — Automatic caching, background refresh for live price data
6. **Turborepo v2** — `tasks` key (not `pipeline`) for build orchestration

---

## 📬 Contact

- **Web:** https://aicomp.in
- **Email:** hello@aicomp.in
- **GitHub:** https://github.com/SayedTouseef/aicomp
