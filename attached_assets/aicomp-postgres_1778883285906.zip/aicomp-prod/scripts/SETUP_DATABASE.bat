@echo off
echo ===============================================
echo   AIComp — Database Setup
echo   PostgreSQL password: admin123
echo ===============================================
echo.

echo [Step 1] Creating aicomp database...
psql -U postgres -c "CREATE DATABASE aicomp;" 2>nul
if errorlevel 1 (
  echo Database may already exist, continuing...
)

echo.
echo [Step 2] Running schema (creating all tables)...
psql -U postgres -d aicomp -f scripts\init.sql
if errorlevel 1 (
  echo Schema via Prisma instead...
  cd packages\database && npx prisma db push && cd ..\..
)

echo.
echo [Step 3] Seeding initial data...
cd packages\database && npx tsx seed-pg.ts && cd ..\..

echo.
echo ===============================================
echo   ✅ Database setup complete!
echo   Admin login: admin@aicomp.in / admin@aicomp123
echo ===============================================
pause
