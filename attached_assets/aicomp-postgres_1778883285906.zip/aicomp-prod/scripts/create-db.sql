-- Run this as postgres superuser to create the aicomp database
-- psql -U postgres -f scripts/create-db.sql

CREATE DATABASE aicomp;

-- Grant all privileges to postgres user (already has them as superuser)
-- If you want a separate aicomp user later, uncomment:
-- CREATE USER aicomp WITH PASSWORD 'aicomp_dev';
-- GRANT ALL PRIVILEGES ON DATABASE aicomp TO aicomp;

\echo '✅ Database aicomp created'
