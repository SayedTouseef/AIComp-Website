// ─── Utility: cn (className merger) ──────────────────────
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// ─── Utility: slug generator ─────────────────────────────

export function slugify(text: string): string {
  return text
    .toLowerCase()
    .trim()
    .replace(/[^\w\s-]/g, '')
    .replace(/[\s_-]+/g, '-')
    .replace(/^-+|-+$/g, '');
}

// ─── Utility: price formatters ────────────────────────────

export function formatPrice(paise: number): string {
  return `₹${(paise / 100).toLocaleString('en-IN')}`;
}

export function formatPriceShort(paise: number): string {
  const rupees = paise / 100;
  if (rupees >= 100000) return `₹${(rupees / 100000).toFixed(1)}L`;
  if (rupees >= 1000) return `₹${(rupees / 1000).toFixed(0)}K`;
  return `₹${rupees}`;
}

export function discountPct(price: number, mrp: number): number {
  return Math.round((1 - price / mrp) * 100);
}

// ─── Utility: date formatters ─────────────────────────────

export function timeAgo(date: string | Date): string {
  const seconds = Math.floor((Date.now() - new Date(date).getTime()) / 1000);
  if (seconds < 60) return 'just now';
  if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`;
  if (seconds < 86400) return `${Math.floor(seconds / 3600)}h ago`;
  if (seconds < 2592000) return `${Math.floor(seconds / 86400)}d ago`;
  return new Date(date).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
}

export function formatDate(date: string | Date, short = false): string {
  return new Date(date).toLocaleDateString('en-IN', {
    day: 'numeric',
    month: short ? 'short' : 'long',
    year: 'numeric',
  });
}

// ─── Utility: score helpers ───────────────────────────────

export function scoreColor(score: number): string {
  if (score >= 85) return '#48bb78';
  if (score >= 70) return '#f6ad55';
  return '#fc8181';
}

export function scoreLabel(score: number): string {
  if (score >= 90) return 'Excellent';
  if (score >= 80) return 'Very Good';
  if (score >= 70) return 'Good';
  if (score >= 60) return 'Average';
  return 'Below Average';
}

// ─── Utility: truncate ────────────────────────────────────

export function truncate(text: string, length: number): string {
  if (text.length <= length) return text;
  return text.slice(0, length).trim() + '…';
}

// ─── Utility: debounce ────────────────────────────────────

export function debounce<T extends (...args: any[]) => any>(
  fn: T,
  delay: number
): (...args: Parameters<T>) => void {
  let timer: ReturnType<typeof setTimeout>;
  return (...args) => {
    clearTimeout(timer);
    timer = setTimeout(() => fn(...args), delay);
  };
}

// ─── Utility: array chunk ─────────────────────────────────

export function chunk<T>(arr: T[], size: number): T[][] {
  return Array.from({ length: Math.ceil(arr.length / size) }, (_, i) =>
    arr.slice(i * size, i * size + size)
  );
}

// ─── Utility: random pick ─────────────────────────────────

export function randomPick<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

// ─── Utility: sleep ──────────────────────────────────────

export const sleep = (ms: number) => new Promise(r => setTimeout(r, ms));

// ─── Utility: env getter (throws if missing) ──────────────

export function env(key: string): string {
  const val = process.env[key];
  if (!val) throw new Error(`Missing required env var: ${key}`);
  return val;
}

// ─── Utility: safe JSON parse ─────────────────────────────

export function safeJson<T>(str: string, fallback: T): T {
  try { return JSON.parse(str); }
  catch { return fallback; }
}
