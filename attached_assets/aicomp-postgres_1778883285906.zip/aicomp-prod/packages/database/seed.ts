import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function seed() {
  console.log('🌱 Seeding AIComp database...');

  // ─── Categories ─────────────────────────────────────────

  const categories = [
    { name: 'Smartphones', slug: 'smartphones', emoji: '📱', description: 'Mobile phones from all major brands' },
    { name: 'Laptops', slug: 'laptops', emoji: '💻', description: 'Laptops for work, gaming and creativity' },
    { name: 'TVs', slug: 'tvs', emoji: '📺', description: 'Smart TVs, 4K, OLED, QLED' },
    { name: 'Air Conditioners', slug: 'air-conditioners', emoji: '❄️', description: 'Split, window, and portable ACs' },
    { name: 'Gaming PCs', slug: 'gaming-pcs', emoji: '🎮', description: 'Gaming desktops and rigs' },
    { name: 'Cameras', slug: 'cameras', emoji: '📷', description: 'DSLRs, mirrorless, and action cameras' },
    { name: 'Monitors', slug: 'monitors', emoji: '🖥️', description: 'Gaming, 4K, and professional monitors' },
    { name: 'Smartwatches', slug: 'smartwatches', emoji: '⌚', description: 'Fitness trackers and smartwatches' },
    { name: 'Headphones', slug: 'headphones', emoji: '🎧', description: 'Earbuds, over-ear, and gaming headsets' },
    { name: 'Refrigerators', slug: 'refrigerators', emoji: '🧊', description: 'Single door, double door, side-by-side' },
    { name: 'Washing Machines', slug: 'washing-machines', emoji: '🫧', description: 'Front load and top load washers' },
    { name: 'Tablets', slug: 'tablets', emoji: '📱', description: 'iPads, Android tablets, and e-readers' },
    { name: 'GPUs', slug: 'gpus', emoji: '🎮', description: 'Graphics cards for gaming and AI workloads' },
    { name: 'CPUs', slug: 'cpus', emoji: '⚡', description: 'Processors for desktop and laptop builds' },
  ];

  for (const cat of categories) {
    await prisma.category.upsert({
      where: { slug: cat.slug },
      update: cat,
      create: cat,
    });
  }
  console.log(`✅ ${categories.length} categories seeded`);

  // ─── Category attributes ─────────────────────────────────

  const phoneCat = await prisma.category.findUnique({ where: { slug: 'smartphones' } });
  if (phoneCat) {
    const phoneAttrs = [
      { name: 'RAM', slug: 'ram', unit: 'GB', type: 'enum', options: ['4 GB', '6 GB', '8 GB', '12 GB', '16 GB'], sortOrder: 1 },
      { name: 'Storage', slug: 'storage', unit: 'GB', type: 'enum', options: ['64 GB', '128 GB', '256 GB', '512 GB', '1 TB'], sortOrder: 2 },
      { name: 'Battery', slug: 'battery', unit: 'mAh', type: 'number', options: [], sortOrder: 3 },
      { name: 'Screen Size', slug: 'screen-size', unit: 'inches', type: 'number', options: [], sortOrder: 4 },
      { name: 'OS', slug: 'os', type: 'enum', options: ['Android', 'iOS'], sortOrder: 5 },
      { name: '5G', slug: '5g', type: 'boolean', options: ['Yes', 'No'], sortOrder: 6 },
    ];
    for (const attr of phoneAttrs) {
      await prisma.categoryAttribute.upsert({
        where: { categoryId_slug: { categoryId: phoneCat.id, slug: attr.slug } },
        update: attr,
        create: { categoryId: phoneCat.id, ...attr },
      });
    }
  }

  // ─── Brands ──────────────────────────────────────────────

  const brands = [
    { name: 'Apple', slug: 'apple', country: 'USA', website: 'https://apple.com' },
    { name: 'Samsung', slug: 'samsung', country: 'South Korea', website: 'https://samsung.com' },
    { name: 'Google', slug: 'google', country: 'USA', website: 'https://store.google.com' },
    { name: 'OnePlus', slug: 'oneplus', country: 'China', website: 'https://oneplus.com' },
    { name: 'Realme', slug: 'realme', country: 'China', website: 'https://realme.com' },
    { name: 'Poco', slug: 'poco', country: 'China', website: 'https://poco.in' },
    { name: 'Xiaomi', slug: 'xiaomi', country: 'China', website: 'https://mi.com' },
    { name: 'Motorola', slug: 'motorola', country: 'USA', website: 'https://motorola.in' },
    { name: 'ASUS', slug: 'asus', country: 'Taiwan', website: 'https://asus.com' },
    { name: 'Lenovo', slug: 'lenovo', country: 'China', website: 'https://lenovo.com' },
    { name: 'HP', slug: 'hp', country: 'USA', website: 'https://hp.com' },
    { name: 'Dell', slug: 'dell', country: 'USA', website: 'https://dell.com' },
    { name: 'MSI', slug: 'msi', country: 'Taiwan', website: 'https://msi.com' },
    { name: 'Acer', slug: 'acer', country: 'Taiwan', website: 'https://acer.com' },
    { name: 'Sony', slug: 'sony', country: 'Japan', website: 'https://sony.co.in' },
    { name: 'LG', slug: 'lg', country: 'South Korea', website: 'https://lg.com' },
    { name: 'Daikin', slug: 'daikin', country: 'Japan', website: 'https://daikin.co.in' },
    { name: 'Voltas', slug: 'voltas', country: 'India', website: 'https://voltas.com' },
    { name: 'Blue Star', slug: 'blue-star', country: 'India', website: 'https://bluestarindia.com' },
    { name: 'Bosch', slug: 'bosch', country: 'Germany', website: 'https://bosch-home.com' },
    { name: 'NVIDIA', slug: 'nvidia', country: 'USA', website: 'https://nvidia.com' },
    { name: 'AMD', slug: 'amd', country: 'USA', website: 'https://amd.com' },
    { name: 'Intel', slug: 'intel', country: 'USA', website: 'https://intel.com' },
  ];

  for (const brand of brands) {
    await prisma.brand.upsert({ where: { slug: brand.slug }, update: brand, create: brand });
  }
  console.log(`✅ ${brands.length} brands seeded`);

  // ─── Sellers ─────────────────────────────────────────────

  const sellers = [
    { name: 'Amazon', slug: 'amazon', website: 'https://amazon.in', network: 'AMAZON' as const, rating: 4.5 },
    { name: 'Flipkart', slug: 'flipkart', website: 'https://flipkart.com', network: 'FLIPKART' as const, rating: 4.3 },
    { name: 'Croma', slug: 'croma', website: 'https://croma.com', network: 'CROMA' as const, rating: 4.2 },
    { name: 'Reliance Digital', slug: 'reliance-digital', website: 'https://reliancedigital.in', network: 'RELIANCE_DIGITAL' as const, rating: 4.1 },
    { name: 'Vijay Sales', slug: 'vijay-sales', website: 'https://vijaysales.com', network: 'VIJAY_SALES' as const, rating: 4.0 },
  ];

  for (const seller of sellers) {
    await prisma.seller.upsert({ where: { slug: seller.slug }, update: seller, create: seller });
  }
  console.log(`✅ ${sellers.length} sellers seeded`);

  // ─── Sample admin user ────────────────────────────────────

  const bcrypt = await import('bcryptjs');
  const hash = await bcrypt.hash('admin@aicomp123', 12);
  await prisma.user.upsert({
    where: { email: 'admin@aicomp.in' },
    update: {},
    create: {
      email: 'admin@aicomp.in',
      name: 'AIComp Admin',
      passwordHash: hash,
      role: 'SUPER_ADMIN',
      isVerified: true,
    },
  });
  console.log('✅ Admin user seeded (admin@aicomp.in)');

  // ─── Homepage sections ────────────────────────────────────

  await prisma.homepageSection.createMany({
    skipDuplicates: true,
    data: [
      { type: 'hero', title: 'AI-Powered Electronics Comparison', data: { variant: 'default' }, sortOrder: 1 },
      { type: 'featured', title: 'Featured Products', data: {}, sortOrder: 2 },
      { type: 'trending', title: 'Trending Now', data: {}, sortOrder: 3 },
      { type: 'deals', title: 'Today\'s Best Deals', data: {}, sortOrder: 4 },
    ],
  });

  console.log('\n🎉 Database seeded successfully!');
  console.log('📧 Admin login: admin@aicomp.in / admin@aicomp123');
}

seed()
  .catch(e => { console.error('Seed failed:', e); process.exit(1); })
  .finally(() => prisma.$disconnect());
