/**
 * AIComp Database Seed — Uses pg directly (no Prisma binary needed)
 * Run: npx tsx seed-pg.ts
 */
import 'dotenv/config';
import { Pool } from 'pg';
import bcrypt from 'bcryptjs';

const pool = new Pool({
  connectionString: process.env.DATABASE_URL || 'postgresql://postgres:admin123@localhost:5432/aicomp',
});

async function seed() {
  console.log('🌱 Seeding AIComp database (pg-direct)...\n');

  // Categories
  const categories = [
    { name:'Smartphones',     slug:'smartphones',     emoji:'📱', sort_order:1 },
    { name:'Laptops',         slug:'laptops',         emoji:'💻', sort_order:2 },
    { name:'TVs',             slug:'tvs',             emoji:'📺', sort_order:3 },
    { name:'Air Conditioners',slug:'air-conditioners',emoji:'❄️', sort_order:4 },
    { name:'Gaming PCs',      slug:'gaming-pcs',      emoji:'🎮', sort_order:5 },
    { name:'Cameras',         slug:'cameras',         emoji:'📷', sort_order:6 },
    { name:'Monitors',        slug:'monitors',        emoji:'🖥️', sort_order:7 },
    { name:'Smartwatches',    slug:'smartwatches',    emoji:'⌚', sort_order:8 },
    { name:'Headphones',      slug:'headphones',      emoji:'🎧', sort_order:9 },
    { name:'Tablets',         slug:'tablets',         emoji:'📟', sort_order:10 },
    { name:'GPUs',            slug:'gpus',            emoji:'🎮', sort_order:11 },
    { name:'CPUs',            slug:'cpus',            emoji:'⚡', sort_order:12 },
    { name:'Refrigerators',   slug:'refrigerators',   emoji:'🧊', sort_order:13 },
    { name:'Washing Machines', slug:'washing-machines',emoji:'🫧', sort_order:14 },
  ];

  for (const c of categories) {
    await pool.query(`
      INSERT INTO categories (name, slug, emoji, sort_order, is_active)
      VALUES ($1,$2,$3,$4,true)
      ON CONFLICT (slug) DO UPDATE SET name=EXCLUDED.name, emoji=EXCLUDED.emoji
    `, [c.name, c.slug, c.emoji, c.sort_order]);
  }
  console.log(`✅ ${categories.length} categories`);

  // Brands
  const brands = [
    'Apple','Samsung','Google','OnePlus','Realme','Poco','Xiaomi','Motorola',
    'ASUS','Lenovo','HP','Dell','MSI','Acer','Sony','LG','Daikin','Voltas',
    'Blue Star','Bosch','NVIDIA','AMD','Intel','Nothing','iQOO',
  ].map(name => ({ name, slug: name.toLowerCase().replace(/[^a-z0-9]+/g, '-'), is_active: true }));

  for (const b of brands) {
    await pool.query(`
      INSERT INTO brands (name, slug, is_active)
      VALUES ($1,$2,true)
      ON CONFLICT (slug) DO UPDATE SET name=EXCLUDED.name
    `, [b.name, b.slug]);
  }
  console.log(`✅ ${brands.length} brands`);

  // Sellers
  const sellers = [
    { name:'Amazon',          slug:'amazon',          network:'AMAZON' },
    { name:'Flipkart',        slug:'flipkart',        network:'FLIPKART' },
    { name:'Croma',           slug:'croma',           network:'CROMA' },
    { name:'Reliance Digital',slug:'reliance-digital',network:'RELIANCE_DIGITAL' },
    { name:'Vijay Sales',     slug:'vijay-sales',     network:'VIJAY_SALES' },
  ];

  for (const s of sellers) {
    await pool.query(`
      INSERT INTO sellers (name, slug, network, is_active)
      VALUES ($1,$2,$3,true)
      ON CONFLICT (slug) DO UPDATE SET name=EXCLUDED.name
    `, [s.name, s.slug, s.network]);
  }
  console.log(`✅ ${sellers.length} sellers`);

  // Admin user
  const hash = await bcrypt.hash('admin@aicomp123', 12);
  await pool.query(`
    INSERT INTO users (email, name, password_hash, role, is_verified)
    VALUES ($1,$2,$3,'SUPER_ADMIN',true)
    ON CONFLICT (email) DO NOTHING
  `, ['admin@aicomp.in', 'AIComp Admin', hash]);
  console.log('✅ Admin user (admin@aicomp.in / admin@aicomp123)');

  // Sample products (3)
  const { rows: [phoneCat] } = await pool.query("SELECT id FROM categories WHERE slug='smartphones'");
  const { rows: [appleBrand] } = await pool.query("SELECT id FROM brands WHERE slug='apple'");
  const { rows: [samsungBrand] } = await pool.query("SELECT id FROM brands WHERE slug='samsung'");
  const { rows: [asusB] } = await pool.query("SELECT id FROM brands WHERE slug='asus'");
  const { rows: [laptopCat] } = await pool.query("SELECT id FROM categories WHERE slug='laptops'");

  if (phoneCat && appleBrand) {
    await pool.query(`
      INSERT INTO products (name, slug, brand_id, category_id, status, is_trending, is_featured,
        overall_score, perf_score, camera_score, battery_score, value_score, game_score,
        avg_rating, review_count, ai_pros, ai_cons)
      VALUES ($1,$2,$3,$4,'APPROVED',true,true,96,98,94,72,82,95,4.7,1240,
        ARRAY['Best-in-class A18 Pro performance','Excellent ProRes video','Premium build quality','Advanced AI features'],
        ARRAY['Expensive','Battery life could be better','No USB 4 on base model'])
      ON CONFLICT (slug) DO NOTHING
    `, ['Apple iPhone 16 Pro 256GB', 'apple-iphone-16-pro-256gb', appleBrand.id, phoneCat.id]);

    // Add prices
    const { rows: [prod] } = await pool.query("SELECT id FROM products WHERE slug='apple-iphone-16-pro-256gb'");
    if (prod) {
      const { rows: sellers } = await pool.query("SELECT id, slug FROM sellers WHERE slug IN ('amazon','flipkart','croma')");
      for (const s of sellers) {
        const price = s.slug==='amazon' ? 11990000 : s.slug==='flipkart' ? 11999000 : 12199000;
        await pool.query(`
          INSERT INTO product_prices (product_id, seller_id, price, mrp, discount, in_stock, affiliate_url)
          VALUES ($1,$2,$3,13490000,11,true,'https://amazon.in/iphone16pro?tag=aicomp-21')
          ON CONFLICT (product_id, seller_id) DO UPDATE SET price=EXCLUDED.price
        `, [prod.id, s.id, price]);
      }

      // Specs
      const specs = [
        ['Display','Screen Size','6.3','inches'],['Display','Technology','Super Retina XDR OLED',null],
        ['Display','Refresh Rate','120','Hz'],['Performance','Chipset','Apple A18 Pro',null],
        ['Performance','RAM','8','GB'],['Camera','Main Camera','48','MP'],
        ['Battery','Capacity','3274','mAh'],['Battery','Fast Charging','27','W'],
      ];
      for (const [group,name,val,unit] of specs) {
        await pool.query(`
          INSERT INTO product_specs (product_id, group_name, spec_name, spec_value, unit)
          VALUES ($1,$2,$3,$4,$5) ON CONFLICT DO NOTHING
        `, [prod.id, group, name, val, unit]);
      }
    }
    console.log('✅ iPhone 16 Pro sample product');
  }

  if (phoneCat && samsungBrand) {
    await pool.query(`
      INSERT INTO products (name, slug, brand_id, category_id, status, is_trending,
        overall_score, camera_score, battery_score, value_score, avg_rating, review_count)
      VALUES ($1,$2,$3,$4,'APPROVED',true,91,95,90,78,4.5,890)
      ON CONFLICT (slug) DO NOTHING
    `, ['Samsung Galaxy S25 Ultra', 'samsung-galaxy-s25-ultra', samsungBrand.id, phoneCat.id]);
    console.log('✅ Samsung Galaxy S25 Ultra sample product');
  }

  if (laptopCat && asusB) {
    await pool.query(`
      INSERT INTO products (name, slug, brand_id, category_id, status, is_trending,
        overall_score, game_score, perf_score, value_score, avg_rating, review_count)
      VALUES ($1,$2,$3,$4,'APPROVED',true,92,96,94,80,4.6,342)
      ON CONFLICT (slug) DO NOTHING
    `, ['ASUS ROG Strix G16 (2024)', 'asus-rog-strix-g16-2024', asusB.id, laptopCat.id]);
    console.log('✅ ASUS ROG Strix G16 sample product');
  }

  console.log('\n🎉 Seed complete!');
  console.log('   Admin: admin@aicomp.in / admin@aicomp123\n');
  await pool.end();
}

seed().catch(e => { console.error('❌ Seed failed:', e.message); process.exit(1); });
