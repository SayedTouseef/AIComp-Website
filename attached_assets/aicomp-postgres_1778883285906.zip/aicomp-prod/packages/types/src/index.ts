// ─── AIComp Shared Types ─────────────────────────────────

export interface ApiResponse<T = unknown> {
  data?: T;
  error?: string;
  message?: string;
  pagination?: Pagination;
}

export interface Pagination {
  page: number;
  limit: number;
  total: number;
  totalPages: number;
  hasNext: boolean;
  hasPrev: boolean;
}

// ─── Product ──────────────────────────────────────────────

export type ProductStatus = 'PENDING' | 'APPROVED' | 'REJECTED' | 'DRAFT' | 'ARCHIVED';

export interface ProductListItem {
  id: string;
  name: string;
  slug: string;
  thumbnail: string | null;
  images: string[];
  avgRating: number;
  reviewCount: number;
  overallScore: number | null;
  valueScore: number | null;
  isTrending: boolean;
  isFeatured: boolean;
  brand: { name: string; slug: string; logo: string | null };
  category: { name: string; slug: string; emoji: string | null };
  prices: ProductPriceItem[];
}

export interface ProductDetail extends ProductListItem {
  description: string | null;
  shortDesc: string | null;
  aiSummary: string | null;
  aiPros: string[];
  aiCons: string[];
  releaseDate: string | null;
  gameScore: number | null;
  batteryScore: number | null;
  cameraScore: number | null;
  perfScore: number | null;
  coolingScore: number | null;
  groupedSpecs: Record<string, { name: string; value: string; unit: string | null }[]>;
  priceHistory: PriceHistoryPoint[];
  priceStats: PriceStats | null;
  benchmarks: Benchmark[];
  fpsData: FpsData[];
  energyData: EnergyData | null;
  videos: ProductVideo[];
  tags: { tag: string }[];
  launchInfo: LaunchInfo | null;
}

export interface ProductPriceItem {
  price: number; // paise
  mrp: number | null;
  discount: number | null;
  inStock: boolean;
  deliveryDays: number | null;
  cashback: string | null;
  affiliateUrl: string | null;
  lastChecked: string;
  seller: { name: string; logo: string | null; slug: string };
}

export interface PriceHistoryPoint {
  price: number;
  recordedAt: string;
  sellerId: string | null;
}

export interface PriceStats {
  min: number;
  max: number;
  avg: number;
  historicMin: number | null;
  historicMax: number | null;
}

// ─── Benchmark ────────────────────────────────────────────

export interface Benchmark {
  id: string;
  category: string;
  testName: string;
  score: number;
  unit: string | null;
  description: string | null;
  source: string | null;
}

export interface FpsData {
  id: string;
  gameTitle: string;
  resolution: string;
  quality: string;
  rayTracing: boolean;
  dlss: boolean;
  fsr: boolean;
  avgFps: number;
  minFps: number | null;
  maxFps: number | null;
}

export interface EnergyData {
  ratedWatts: number;
  starRating: number | null;
  annualKwh: number | null;
  monthlyCostMin: number | null;
  monthlyCostMax: number | null;
  yearlyCost: number | null;
  coolingCapacity: number | null;
  isInverter: boolean | null;
}

export interface ProductVideo {
  id: string;
  title: string;
  youtubeId: string;
  channelName: string | null;
  thumbnail: string | null;
  duration: number | null;
  isShort: boolean;
}

export interface LaunchInfo {
  expectedDate: string | null;
  confirmedDate: string | null;
  expectedPrice: number | null;
  confirmedPrice: number | null;
  isConfirmed: boolean;
  notes: string | null;
}

// ─── Category ─────────────────────────────────────────────

export interface Category {
  id: string;
  name: string;
  slug: string;
  emoji: string | null;
  description: string | null;
  icon: string | null;
  image: string | null;
  children?: Category[];
  attributes?: CategoryAttribute[];
}

export interface CategoryAttribute {
  id: string;
  name: string;
  slug: string;
  unit: string | null;
  type: 'number' | 'string' | 'boolean' | 'enum';
  options: string[];
  isFilterable: boolean;
  isComparable: boolean;
}

// ─── User ─────────────────────────────────────────────────

export type UserRole = 'USER' | 'MODERATOR' | 'CONTENT_MANAGER' | 'SEO_MANAGER' | 'PRODUCT_MANAGER' | 'SUPER_ADMIN';

export interface User {
  id: string;
  email: string;
  name: string | null;
  avatar: string | null;
  role: UserRole;
  isVerified: boolean;
  reputationPoints: number;
  createdAt: string;
}

export interface UserProfile {
  favoriteBrands: string[];
  budgetMin: number | null;
  budgetMax: number | null;
  interests: string[];
  preferredCategories: string[];
  pushToken: string | null;
  telegramChatId: string | null;
  whatsappNumber: string | null;
}

// ─── AI Types ─────────────────────────────────────────────

export interface ChatMessage {
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp?: string;
}

export interface AiVerdict {
  winner: string;
  verdict: string;
  perCategory: Record<string, string>;
  recommendation: string;
}

export interface BuyPrediction {
  recommendation: 'buy_now' | 'wait' | 'good_deal';
  confidence: number;
  reasoning: string;
  predictedDrop?: string;
  bestTimeToBuy?: string;
}

export interface ProductSummary {
  summary: string;
  pros: string[];
  cons: string[];
  verdict: string;
  bestFor: string[];
  notFor: string[];
}

// ─── Review ───────────────────────────────────────────────

export interface Review {
  id: string;
  rating: number;
  title: string | null;
  body: string;
  pros: string[];
  cons: string[];
  images: string[];
  isVerifiedBuyer: boolean;
  helpfulCount: number;
  createdAt: string;
  user: { name: string | null; avatar: string | null; reputationPoints: number };
}

// ─── Alert ────────────────────────────────────────────────

export type AlertType = 'PRICE_DROP' | 'BACK_IN_STOCK' | 'DEAL' | 'LAUNCH' | 'CUSTOM';
export type NotificationChannel = 'PUSH' | 'EMAIL' | 'WHATSAPP' | 'TELEGRAM' | 'BROWSER';

export interface PriceAlert {
  id: string;
  productId: string;
  targetPrice: number | null;
  alertType: AlertType;
  channels: NotificationChannel[];
  isActive: boolean;
  triggeredAt: string | null;
  createdAt: string;
  product: { name: string; slug: string; thumbnail: string | null };
}

// ─── PC Builder ───────────────────────────────────────────

export interface PcBuild {
  id: string;
  name: string;
  description: string | null;
  components: {
    cpu?: string;
    gpu?: string;
    ram?: string;
    motherboard?: string;
    storage?: string;
    psu?: string;
    case?: string;
    cooler?: string;
    monitor?: string;
  };
  totalPrice: number | null;
  wattage: number | null;
  estimatedFps: Record<string, number> | null;
  isPublic: boolean;
  likes: number;
}

// ─── Helpers ──────────────────────────────────────────────

export function formatPrice(paise: number): string {
  return `₹${(paise / 100).toLocaleString('en-IN')}`;
}

export function formatPriceShort(paise: number): string {
  const rupees = paise / 100;
  if (rupees >= 100000) return `₹${(rupees / 100000).toFixed(1)}L`;
  if (rupees >= 1000) return `₹${(rupees / 1000).toFixed(1)}K`;
  return `₹${rupees}`;
}

export function scoreColor(score: number): string {
  if (score >= 85) return '#48bb78';
  if (score >= 70) return '#f6ad55';
  return '#fc8181';
}
