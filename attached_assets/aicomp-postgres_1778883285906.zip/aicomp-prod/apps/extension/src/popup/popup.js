const API_BASE = 'https://api.aicomp.in/api/v1';

async function init() {
  const app = document.getElementById('app');

  // Get current tab
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const url = tab.url || '';

  // Detect product from URL
  const productInfo = extractProductFromUrl(url);

  if (!productInfo) {
    app.innerHTML = `
      <div class="not-found">
        <div style="font-size:32px;margin-bottom:12px">🔍</div>
        <div style="font-weight:600;margin-bottom:6px">No product detected</div>
        <div style="font-size:11px;margin-bottom:16px">Browse to an Amazon, Flipkart, or Croma product page</div>
        <a href="https://aicomp.in" target="_blank">Search on AIComp →</a>
      </div>`;
    return;
  }

  // Search AIComp for this product
  try {
    const res = await fetch(`${API_BASE}/search/autocomplete?q=${encodeURIComponent(productInfo.name)}`);
    const data = await res.json();
    const product = data.results?.[0];

    if (!product) {
      app.innerHTML = `
        <div class="not-found">
          <div style="font-size:32px;margin-bottom:12px">📦</div>
          <div style="font-weight:600;margin-bottom:6px">${productInfo.name.slice(0, 40)}...</div>
          <div style="font-size:11px;margin-bottom:16px">Not yet in our database</div>
          <a href="https://aicomp.in/search?q=${encodeURIComponent(productInfo.name)}" target="_blank">Search on AIComp →</a>
        </div>`;
      return;
    }

    // Fetch full product data
    const productRes = await fetch(`${API_BASE}/products/${product.slug}`);
    const fullProduct = await productRes.json();

    // Render product
    renderProduct(app, fullProduct, productInfo);
  } catch (err) {
    app.innerHTML = `<div class="not-found">Error connecting to AIComp. <a href="https://aicomp.in" target="_blank">Visit site →</a></div>`;
  }
}

function renderProduct(app, product, detected) {
  const prices = product.prices || [];
  const bestPrice = prices[0];
  const aicomp_url = `https://aicomp.in/product/${product.slug}`;

  // Price dropped vs current site?
  const currentPagePrice = detected.price;
  const bestAicompPrice = bestPrice?.price / 100;
  const isCheaperElsewhere = bestAicompPrice && currentPagePrice && bestAicompPrice < currentPagePrice * 0.97;

  app.innerHTML = `
    <div class="product-section">
      <div class="section-title">Product Detected</div>
      <div class="product-card">
        <div class="product-name">${product.name}</div>
        <div class="product-meta">${product.brand?.name} · ${product.category?.name}</div>

        <div class="price-grid">
          ${prices.slice(0, 4).map((p, i) => `
            <div class="price-item">
              <div class="price-seller">${p.seller?.name}</div>
              <div class="price-value ${i === 0 ? 'best' : ''}">₹${(p.price/100).toLocaleString('en-IN')}</div>
              ${p.mrp ? `<div class="price-mrp">₹${(p.mrp/100).toLocaleString('en-IN')}</div>` : ''}
            </div>
          `).join('')}
        </div>

        ${isCheaperElsewhere ? `
          <div style="background:rgba(72,187,120,0.1);border:1px solid rgba(72,187,120,0.2);border-radius:8px;padding:8px 10px;font-size:11px;color:#48bb78;margin-bottom:10px;">
            💰 Cheaper on ${bestPrice.seller?.name} — save ₹${(currentPagePrice - bestAicompPrice).toFixed(0)}!
          </div>` : ''
        }

        <div class="btn-row">
          <a class="btn-primary" href="${aicomp_url}" target="_blank">Compare All Prices</a>
          <a class="btn-ghost" href="${aicomp_url}#ai-review" target="_blank">AI Review</a>
        </div>

        ${product.priceStats ? `
          <div class="history-bar">
            <span>All-time low: <strong style="color:#48bb78">₹${(product.priceStats.historicMin/100).toLocaleString('en-IN')}</strong></span>
            <span style="margin-left:auto">High: <strong style="color:#fc8181">₹${(product.priceStats.historicMax/100).toLocaleString('en-IN')}</strong></span>
          </div>` : ''
        }
      </div>
    </div>

    <div class="ai-section">
      <div class="ai-label">✦ AI Quick Take</div>
      <div class="ai-insight">
        ${product.aiSummary || `${product.name} — Overall Score: ${product.overallScore || 'N/A'}/100. ${product.aiPros?.[0] || ''}`}
      </div>
    </div>

    <div class="alert-section">
      <input class="alert-input" id="targetPrice" type="number" placeholder="Target price ₹" />
      <button class="alert-btn" id="setAlert">🔔 Alert Me</button>
    </div>
  `;

  // Alert button
  document.getElementById('setAlert')?.addEventListener('click', async () => {
    const target = parseFloat(document.getElementById('targetPrice').value);
    if (!target) return;

    // Store alert in extension storage (sync with aicomp.in if logged in)
    await chrome.storage.local.set({
      [`alert_${product.id}`]: { productId: product.id, targetPrice: target * 100, productName: product.name }
    });

    document.getElementById('setAlert').textContent = '✓ Set!';
    setTimeout(() => document.getElementById('setAlert').textContent = '🔔 Alert Me', 2000);
  });
}

function extractProductFromUrl(url) {
  // Amazon
  const amazonMatch = url.match(/amazon\.in\/.*\/dp\/([A-Z0-9]{10})/);
  if (amazonMatch) {
    const titleMatch = document.title?.match(/^(.+?)\s*[\|:]/);
    return { site: 'amazon', asin: amazonMatch[1], name: document.title || '', price: null };
  }

  // Flipkart
  if (url.includes('flipkart.com/') && url.includes('/p/')) {
    return { site: 'flipkart', name: document.title || '', price: null };
  }

  // Croma
  if (url.includes('croma.com/') && url.includes('-p-')) {
    return { site: 'croma', name: document.title || '', price: null };
  }

  return null;
}

init();
