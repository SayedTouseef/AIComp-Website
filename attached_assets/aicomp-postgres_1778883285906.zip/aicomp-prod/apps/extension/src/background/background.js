// AIComp Extension — Background Service Worker

const API_BASE = 'https://api.aicomp.in/api/v1';

// Check price alerts every hour
chrome.alarms.create('checkAlerts', { periodInMinutes: 60 });

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name !== 'checkAlerts') return;

  const storage = await chrome.storage.local.get(null);
  const alerts = Object.entries(storage)
    .filter(([key]) => key.startsWith('alert_'))
    .map(([, val]) => val);

  for (const alert of alerts) {
    try {
      const res = await fetch(`${API_BASE}/products/${alert.productId}`);
      const product = await res.json();
      const currentPrice = product.prices?.[0]?.price;

      if (currentPrice && alert.targetPrice && currentPrice <= alert.targetPrice) {
        chrome.notifications.create(`price_drop_${alert.productId}`, {
          type: 'basic',
          iconUrl: 'icons/icon128.png',
          title: `💰 Price Drop Alert — AIComp`,
          message: `${alert.productName} is now ₹${(currentPrice/100).toLocaleString('en-IN')}!`,
          buttons: [{ title: 'View Deal' }],
        });

        // Remove triggered alert
        await chrome.storage.local.remove(`alert_${alert.productId}`);
      }
    } catch {}
  }
});

// Handle notification click
chrome.notifications.onButtonClicked.addListener((notifId, btnIdx) => {
  const productId = notifId.replace('price_drop_', '');
  chrome.tabs.create({ url: `https://aicomp.in/product/${productId}` });
});
