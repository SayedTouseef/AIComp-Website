// AIComp Content Script — Injects price comparison widget on Amazon/Flipkart/Croma

const API_BASE = 'https://api.aicomp.in/api/v1';

async function injectWidget() {
  // Don't inject on non-product pages
  const url = window.location.href;
  const isProductPage = url.includes('/dp/') || url.includes('/p/') || url.includes('-p-');
  if (!isProductPage) return;

  // Extract product name from page
  const productName = (
    document.querySelector('#productTitle')?.textContent?.trim() ||
    document.querySelector('.B_NuCI')?.textContent?.trim() ||
    document.querySelector('.pdp-product-title')?.textContent?.trim() ||
    document.title
  )?.slice(0, 80);

  if (!productName) return;

  // Fetch AIComp data
  try {
    const res = await fetch(`${API_BASE}/search/autocomplete?q=${encodeURIComponent(productName)}`);
    const data = await res.json();
    const match = data.results?.[0];
    if (!match) return;

    const priceRes = await fetch(`${API_BASE}/products/${match.slug}`);
    const product = await priceRes.json();
    if (!product?.prices?.length) return;

    // Create widget
    const widget = document.createElement('div');
    widget.id = 'aicomp-widget';
    widget.innerHTML = createWidgetHTML(product);
    widget.style.cssText = `
      position: fixed;
      bottom: 20px;
      right: 20px;
      z-index: 99999;
      width: 320px;
      font-family: system-ui, sans-serif;
      transition: all 0.3s ease;
    `;

    document.body.appendChild(widget);

    // Toggle collapse
    widget.querySelector('#aicomp-toggle')?.addEventListener('click', () => {
      const body = widget.querySelector('#aicomp-body');
      body.style.display = body.style.display === 'none' ? 'block' : 'none';
    });

    // Close button
    widget.querySelector('#aicomp-close')?.addEventListener('click', () => {
      widget.remove();
    });

  } catch (err) {
    // Fail silently
  }
}

function createWidgetHTML(product) {
  const prices = product.prices?.slice(0, 3) || [];
  const best = prices[0];

  return `
    <div style="background:#050810;border:1px solid rgba(99,179,237,0.3);border-radius:16px;overflow:hidden;box-shadow:0 8px 32px rgba(0,0,0,0.5);">
      <div style="background:linear-gradient(135deg,rgba(99,179,237,0.15),rgba(159,122,234,0.15));padding:10px 14px;display:flex;align-items:center;justify-content:space-between;border-bottom:1px solid rgba(255,255,255,0.07);">
        <div style="display:flex;align-items:center;gap:8px;">
          <div style="width:22px;height:22px;border-radius:6px;background:linear-gradient(135deg,#63b3ed,#9f7aea);display:flex;align-items:center;justify-content:center;font-weight:900;font-size:8px;color:white;">AI</div>
          <span style="font-size:12px;font-weight:700;color:#e8edf8;">AIComp Price Watch</span>
        </div>
        <div style="display:flex;gap:4px;">
          <button id="aicomp-toggle" style="background:none;border:none;color:#6b7a9a;cursor:pointer;font-size:14px;padding:2px 6px;">−</button>
          <button id="aicomp-close" style="background:none;border:none;color:#6b7a9a;cursor:pointer;font-size:14px;padding:2px 6px;">×</button>
        </div>
      </div>
      <div id="aicomp-body" style="padding:12px 14px;">
        <div style="font-size:11px;font-weight:600;color:#e8edf8;margin-bottom:8px;line-height:1.3;">${product.name?.slice(0, 55)}...</div>
        <div style="display:flex;flex-direction:column;gap:6px;margin-bottom:10px;">
          ${prices.map((p, i) => `
            <div style="display:flex;align-items:center;justify-content:space-between;background:rgba(255,255,255,0.03);border:1px solid rgba(255,255,255,0.06);border-radius:8px;padding:7px 10px;">
              <span style="font-size:11px;color:#6b7a9a;">${p.seller?.name}</span>
              <span style="font-family:monospace;font-size:13px;font-weight:700;color:${i===0?'#48bb78':'#e8edf8'};">₹${(p.price/100).toLocaleString('en-IN')}</span>
            </div>
          `).join('')}
        </div>
        <a href="https://aicomp.in/product/${product.slug}" target="_blank"
           style="display:block;background:linear-gradient(135deg,#63b3ed,#9f7aea);color:white;text-decoration:none;text-align:center;padding:8px;border-radius:8px;font-size:11px;font-weight:600;">
          Compare All Prices + AI Review →
        </a>
        ${product.overallScore ? `<div style="text-align:center;font-size:10px;color:#6b7a9a;margin-top:6px;">AI Score: ${product.overallScore}/100</div>` : ''}
      </div>
    </div>
  `;
}

// Run after page loads
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', injectWidget);
} else {
  setTimeout(injectWidget, 2000);
}
