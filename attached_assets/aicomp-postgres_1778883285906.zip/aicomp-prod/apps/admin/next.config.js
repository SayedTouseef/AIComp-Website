/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  images: {
    remotePatterns: [
      { protocol: 'https', hostname: '**.amazon.com' },
      { protocol: 'https', hostname: '**.cloudinary.com' },
    ],
  },
  poweredByHeader: false,
};
module.exports = nextConfig;
