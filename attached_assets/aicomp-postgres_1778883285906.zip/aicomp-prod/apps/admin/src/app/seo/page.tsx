'use client';
import { Plus, Eye, Edit, Sparkles } from 'lucide-react';

const CONTENT = [
  { title: 'Best Smartphones Under ₹30,000', type: 'BUYING_GUIDE', views: 45230, status: 'published' },
  { title: 'iPhone 16 vs Samsung S24 Comparison', type: 'COMPARISON', views: 23400, status: 'published' },
  { title: 'Best Gaming Laptops India 2025', type: 'BUYING_GUIDE', views: 38900, status: 'published' },
  { title: 'AC Buying Guide India', type: 'BUYING_GUIDE', views: 29400, status: 'draft' },
];

export default function Page() {
  return (
    <div className="min-h-screen bg-[#050810] text-white p-6">
      <div className="max-w-5xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <h1 className="font-[Syne] font-extrabold text-3xl">SEO Content</h1>
          <div className="flex gap-3">
            <button className="flex items-center gap-2 bg-[#0d1526] border border-white/[0.07] text-slate-400 hover:text-white px-4 py-2 rounded-xl text-sm transition-colors"><Sparkles size={14} /> AI Generate</button>
            <button className="flex items-center gap-2 bg-gradient-to-r from-cyan-500 to-violet-500 text-white px-4 py-2 rounded-xl text-sm font-medium"><Plus size={14} /> New Article</button>
          </div>
        </div>
        <div className="space-y-3">
          {CONTENT.map((c, i) => (
            <div key={i} className="bg-[#0d1526] border border-white/[0.07] rounded-xl flex items-center gap-4 px-5 py-4">
              <div className="flex-1">
                <div className="text-sm font-medium text-white">{c.title}</div>
                <div className="text-xs text-slate-500 mt-0.5">{c.type.replace('_',' ')} · {c.views.toLocaleString()} views</div>
              </div>
              <span className={`text-xs px-2.5 py-1 rounded-lg border ${c.status === 'published' ? 'text-emerald-400 border-emerald-400/20' : 'text-amber-400 border-amber-400/20'}`}>{c.status}</span>
              <div className="flex gap-1.5">
                <button className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-white/[0.05]"><Eye size={13} /></button>
                <button className="p-1.5 text-slate-400 hover:text-cyan-400 rounded-lg hover:bg-cyan-400/10"><Edit size={13} /></button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
