'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import { Search, Plus, Filter, CheckCircle, XCircle, Clock, Eye, Edit, Trash2, Download, Upload, RefreshCw } from 'lucide-react';

const STATUS_COLORS: Record<string, string> = {
  APPROVED: 'text-emerald-400 bg-emerald-400/10 border-emerald-400/20',
  PENDING: 'text-amber-400 bg-amber-400/10 border-amber-400/20',
  REJECTED: 'text-red-400 bg-red-400/10 border-red-400/20',
  DRAFT: 'text-slate-400 bg-slate-400/10 border-slate-400/20',
};

const MOCK_PRODUCTS = [
  { id: '1', name: 'Samsung Galaxy S25 Ultra', brand: 'Samsung', category: 'Smartphones', status: 'PENDING', views: 0, price: '₹1,29,999', createdAt: '2 min ago', source: 'Crawler' },
  { id: '2', name: 'MacBook Air M4', brand: 'Apple', category: 'Laptops', status: 'APPROVED', views: 12450, price: '₹1,29,900', createdAt: '1 hour ago', source: 'Manual' },
  { id: '3', name: 'ASUS ROG Zephyrus G14', brand: 'ASUS', category: 'Laptops', status: 'APPROVED', views: 8930, price: '₹1,59,990', createdAt: '3 hours ago', source: 'Crawler' },
  { id: '4', name: 'Sony Bravia XR 77"', brand: 'Sony', category: 'TVs', status: 'PENDING', views: 0, price: '₹2,89,990', createdAt: '5 hours ago', source: 'Crawler' },
  { id: '5', name: 'OnePlus 13R', brand: 'OnePlus', category: 'Smartphones', status: 'REJECTED', views: 0, price: '₹42,999', createdAt: '1 day ago', source: 'Manual' },
  { id: '6', name: 'Daikin 2T Inverter AC', brand: 'Daikin', category: 'Air Conditioners', status: 'APPROVED', views: 5670, price: '₹58,990', createdAt: '2 days ago', source: 'Crawler' },
];

export default function AdminProductsPage() {
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [selected, setSelected] = useState<string[]>([]);

  const filtered = MOCK_PRODUCTS.filter(p =>
    (statusFilter === 'ALL' || p.status === statusFilter) &&
    p.name.toLowerCase().includes(search.toLowerCase())
  );

  const toggleSelect = (id: string) =>
    setSelected(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]);

  return (
    <div className="min-h-screen bg-[#050810] text-white p-6">
      <div className="max-w-[1400px] mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="font-['Syne'] font-extrabold text-3xl tracking-tight">Products</h1>
            <p className="text-slate-400 text-sm mt-1">{MOCK_PRODUCTS.length} total products</p>
          </div>
          <div className="flex gap-3">
            <button className="flex items-center gap-2 bg-[#0d1526] border border-white/[0.07] text-slate-400 hover:text-white px-4 py-2 rounded-xl text-sm transition-colors">
              <Download size={14} /> Export
            </button>
            <button className="flex items-center gap-2 bg-[#0d1526] border border-white/[0.07] text-slate-400 hover:text-white px-4 py-2 rounded-xl text-sm transition-colors">
              <Upload size={14} /> Bulk Import
            </button>
            <button className="flex items-center gap-2 bg-gradient-to-r from-cyan-500 to-violet-500 text-white px-4 py-2 rounded-xl text-sm font-medium">
              <Plus size={14} /> Add Product
            </button>
          </div>
        </div>

        {/* Filters */}
        <div className="flex items-center gap-4 mb-6">
          <div className="flex-1 relative">
            <Search size={15} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500" />
            <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search products..."
              className="w-full bg-[#0d1526] border border-white/[0.07] rounded-xl pl-10 pr-4 py-2.5 text-sm text-white outline-none focus:border-white/[0.15] transition-colors" />
          </div>
          <div className="flex gap-2">
            {['ALL', 'APPROVED', 'PENDING', 'REJECTED', 'DRAFT'].map(s => (
              <button key={s} onClick={() => setStatusFilter(s)}
                className={`px-3 py-2 rounded-xl text-xs font-medium transition-all ${statusFilter === s ? 'bg-white/10 text-white' : 'text-slate-400 hover:text-white'}`}>
                {s}
              </button>
            ))}
          </div>
        </div>

        {/* Bulk actions */}
        {selected.length > 0 && (
          <div className="flex items-center gap-3 mb-4 p-3 bg-cyan-500/10 border border-cyan-500/20 rounded-xl">
            <span className="text-sm text-cyan-400">{selected.length} selected</span>
            <button className="text-xs text-emerald-400 hover:underline flex items-center gap-1"><CheckCircle size={12} /> Approve All</button>
            <button className="text-xs text-red-400 hover:underline flex items-center gap-1"><XCircle size={12} /> Reject All</button>
            <button className="text-xs text-slate-400 hover:underline ml-auto" onClick={() => setSelected([])}>Deselect</button>
          </div>
        )}

        {/* Table */}
        <div className="bg-[#0d1526] border border-white/[0.07] rounded-2xl overflow-hidden">
          <div className="grid grid-cols-[32px_1fr_120px_120px_100px_80px_100px_120px] px-5 py-3 border-b border-white/[0.05] text-xs text-slate-500 uppercase tracking-wider">
            <div />
            <div>Product</div>
            <div>Category</div>
            <div>Price</div>
            <div>Status</div>
            <div>Views</div>
            <div>Source</div>
            <div>Actions</div>
          </div>
          <div className="divide-y divide-white/[0.04]">
            {filtered.map((p, i) => (
              <motion.div key={p.id} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: i * 0.03 }}
                className="grid grid-cols-[32px_1fr_120px_120px_100px_80px_100px_120px] px-5 py-4 items-center hover:bg-white/[0.02] transition-colors">
                <input type="checkbox" checked={selected.includes(p.id)} onChange={() => toggleSelect(p.id)}
                  className="rounded accent-cyan-400" />
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-9 h-9 rounded-xl bg-white/[0.05] border border-white/[0.07] flex items-center justify-center text-lg flex-shrink-0">
                    {p.category === 'Smartphones' ? '📱' : p.category === 'Laptops' ? '💻' : p.category === 'TVs' ? '📺' : '❄️'}
                  </div>
                  <div className="min-w-0">
                    <div className="text-sm font-medium text-white truncate">{p.name}</div>
                    <div className="text-xs text-slate-500">{p.brand} · {p.createdAt}</div>
                  </div>
                </div>
                <div className="text-xs text-slate-400">{p.category}</div>
                <div className="text-sm font-mono text-white">{p.price}</div>
                <div>
                  <span className={`inline-flex items-center px-2.5 py-1 rounded-lg text-xs font-medium border ${STATUS_COLORS[p.status]}`}>
                    {p.status}
                  </span>
                </div>
                <div className="text-sm font-mono text-slate-400">{p.views.toLocaleString()}</div>
                <div className="text-xs text-slate-400">{p.source}</div>
                <div className="flex items-center gap-1">
                  {p.status === 'PENDING' && (
                    <>
                      <button className="p-1.5 text-emerald-400 hover:bg-emerald-400/10 rounded-lg transition-colors"><CheckCircle size={14} /></button>
                      <button className="p-1.5 text-red-400 hover:bg-red-400/10 rounded-lg transition-colors"><XCircle size={14} /></button>
                    </>
                  )}
                  <button className="p-1.5 text-slate-400 hover:text-white hover:bg-white/[0.05] rounded-lg transition-colors"><Eye size={14} /></button>
                  <button className="p-1.5 text-slate-400 hover:text-white hover:bg-white/[0.05] rounded-lg transition-colors"><Edit size={14} /></button>
                  <button className="p-1.5 text-slate-400 hover:text-red-400 hover:bg-red-400/10 rounded-lg transition-colors"><Trash2 size={14} /></button>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
