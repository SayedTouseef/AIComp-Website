'use client';

import { useState } from 'react';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

const trafficData = Array.from({ length: 30 }, (_, i) => ({
  date: `May ${i + 1}`,
  views: Math.floor(80000 + Math.random() * 60000),
  revenue: Math.floor(15000 + Math.random() * 25000),
  clicks: Math.floor(3000 + Math.random() * 3000),
  users: Math.floor(8000 + Math.random() * 5000),
}));

const topSearches = [
  { query: 'iPhone 16 Pro', count: 12340, change: '+23%' },
  { query: 'MacBook Air M4', count: 9821, change: '+45%' },
  { query: 'Samsung S24 Ultra', count: 8934, change: '+12%' },
  { query: 'gaming laptop under 1 lakh', count: 7821, change: '+67%' },
  { query: 'best AC for 150 sqft', count: 6534, change: '+89%' },
  { query: 'RTX 4070 price', count: 5234, change: '+34%' },
  { query: 'Daikin vs Voltas AC', count: 4891, change: '+156%' },
  { query: 'best earbuds under 5000', count: 4234, change: '+28%' },
];

const affiliateData = [
  { seller: 'Amazon', clicks: 45230, revenue: 89400, ctr: '12.3%', color: '#f6ad55' },
  { seller: 'Flipkart', clicks: 32100, revenue: 61200, ctr: '9.8%', color: '#63b3ed' },
  { seller: 'Croma', clicks: 12400, revenue: 28900, ctr: '7.2%', color: '#48bb78' },
  { seller: 'Reliance Digital', clicks: 8900, revenue: 18200, ctr: '5.4%', color: '#9f7aea' },
];

export default function AdminAnalyticsPage() {
  const [range, setRange] = useState('30d');

  return (
    <div className="min-h-screen bg-[#050810] text-white p-6">
      <div className="max-w-[1400px] mx-auto">
        <div className="flex items-center justify-between mb-6">
          <h1 className="font-['Syne'] font-extrabold text-3xl tracking-tight">Analytics</h1>
          <div className="flex bg-[#0d1526] border border-white/[0.07] rounded-xl p-1 gap-1">
            {['7d', '30d', '90d', '1y'].map(r => (
              <button key={r} onClick={() => setRange(r)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${range === r ? 'bg-white/10 text-white' : 'text-slate-400 hover:text-white'}`}>
                {r}
              </button>
            ))}
          </div>
        </div>

        {/* Traffic chart */}
        <div className="bg-[#0d1526] border border-white/[0.07] rounded-2xl p-6 mb-5">
          <h2 className="font-semibold text-white mb-4">Traffic Overview</h2>
          <ResponsiveContainer width="100%" height={260}>
            <LineChart data={trafficData}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
              <XAxis dataKey="date" tick={{ fill: '#6b7a9a', fontSize: 10 }} axisLine={false} tickLine={false} interval={4} />
              <YAxis tick={{ fill: '#6b7a9a', fontSize: 10 }} axisLine={false} tickLine={false} />
              <Tooltip contentStyle={{ background: '#0d1526', border: '1px solid rgba(255,255,255,0.07)', borderRadius: '10px', fontSize: '11px' }} />
              <Line type="monotone" dataKey="views" stroke="#63b3ed" strokeWidth={2} dot={false} />
              <Line type="monotone" dataKey="users" stroke="#9f7aea" strokeWidth={2} dot={false} />
              <Line type="monotone" dataKey="clicks" stroke="#48bb78" strokeWidth={2} dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </div>

        <div className="grid grid-cols-2 gap-5 mb-5">
          {/* Top searches */}
          <div className="bg-[#0d1526] border border-white/[0.07] rounded-2xl overflow-hidden">
            <div className="px-5 py-4 border-b border-white/[0.07]">
              <h2 className="font-semibold text-white">Top Search Queries</h2>
            </div>
            <div className="divide-y divide-white/[0.04]">
              {topSearches.map((s, i) => (
                <div key={i} className="px-5 py-3 flex items-center gap-3">
                  <div className="w-5 text-slate-600 text-sm font-mono text-center">{i+1}</div>
                  <div className="flex-1 text-sm text-white">{s.query}</div>
                  <div className="text-xs font-mono text-slate-400">{s.count.toLocaleString()}</div>
                  <div className="text-xs font-mono text-emerald-400">{s.change}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Affiliate breakdown */}
          <div className="bg-[#0d1526] border border-white/[0.07] rounded-2xl overflow-hidden">
            <div className="px-5 py-4 border-b border-white/[0.07]">
              <h2 className="font-semibold text-white">Affiliate Revenue Breakdown</h2>
            </div>
            <div className="p-5">
              <div className="space-y-4">
                {affiliateData.map((a, i) => (
                  <div key={i}>
                    <div className="flex justify-between text-xs mb-1.5">
                      <span className="text-slate-300 font-medium">{a.seller}</span>
                      <div className="flex gap-4">
                        <span className="text-slate-500">{a.clicks.toLocaleString()} clicks</span>
                        <span className="font-mono" style={{ color: a.color }}>₹{a.revenue.toLocaleString()}</span>
                      </div>
                    </div>
                    <div className="h-2 bg-white/[0.05] rounded-full overflow-hidden">
                      <div className="h-full rounded-full" style={{ width: `${(a.revenue / 89400) * 100}%`, background: a.color }} />
                    </div>
                  </div>
                ))}
              </div>
              <div className="mt-5 pt-4 border-t border-white/[0.07] flex justify-between">
                <span className="text-sm text-slate-400">Total this month</span>
                <span className="font-mono font-bold text-emerald-400">₹{(89400+61200+28900+18200).toLocaleString()}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Revenue chart */}
        <div className="bg-[#0d1526] border border-white/[0.07] rounded-2xl p-6">
          <h2 className="font-semibold text-white mb-4">Daily Affiliate Revenue (₹)</h2>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={trafficData}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
              <XAxis dataKey="date" tick={{ fill: '#6b7a9a', fontSize: 10 }} axisLine={false} tickLine={false} interval={4} />
              <YAxis tick={{ fill: '#6b7a9a', fontSize: 10 }} axisLine={false} tickLine={false} />
              <Tooltip formatter={(v: any) => `₹${v.toLocaleString()}`} contentStyle={{ background: '#0d1526', border: '1px solid rgba(255,255,255,0.07)', borderRadius: '10px', fontSize: '11px' }} />
              <Bar dataKey="revenue" fill="#63b3ed" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}
