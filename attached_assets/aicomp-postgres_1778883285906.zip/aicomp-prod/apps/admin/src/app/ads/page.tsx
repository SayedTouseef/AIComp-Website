'use client';
import { Plus, TrendingUp } from 'lucide-react';

const ADS = [
  { name: 'Flipkart Summer Sale', placement: 'Homepage Hero', ctr: '3.2%', revenue: 45000, status: 'active' },
  { name: 'Amazon Laptops Sidebar', placement: 'Laptop Category', ctr: '2.8%', revenue: 32000, status: 'active' },
  { name: 'Samsung Galaxy Launch', placement: 'Product Compare', ctr: '5.3%', revenue: 18000, status: 'paused' },
];

export default function Page() {
  return (
    <div className="min-h-screen bg-[#050810] text-white p-6">
      <div className="max-w-5xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <h1 className="font-[Syne] font-extrabold text-3xl">Ad Management</h1>
          <button className="flex items-center gap-2 bg-gradient-to-r from-cyan-500 to-violet-500 text-white px-4 py-2 rounded-xl text-sm font-medium"><Plus size={14} /> New Ad</button>
        </div>
        <div className="bg-[#0d1526] border border-white/[0.07] rounded-2xl overflow-hidden">
          <div className="divide-y divide-white/[0.04]">
            {ADS.map((ad, i) => (
              <div key={i} className="flex items-center gap-4 px-5 py-4 hover:bg-white/[0.02]">
                <div className="flex-1"><div className="text-sm font-medium text-white">{ad.name}</div><div className="text-xs text-slate-500">{ad.placement}</div></div>
                <div className="text-sm font-mono text-cyan-400">{ad.ctr}</div>
                <div className="text-sm font-mono text-emerald-400">₹{ad.revenue.toLocaleString()}</div>
                <span className={`text-xs px-2.5 py-1 rounded-lg border ${ad.status === 'active' ? 'text-emerald-400 border-emerald-400/20' : 'text-amber-400 border-amber-400/20'}`}>{ad.status}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
