import type { Metadata } from 'next';
import { ThemeProvider } from 'next-themes';
import { AdminShell } from '@/components/AdminShell';
import './globals.css';

export const metadata: Metadata = {
  title: { default: 'AIComp Admin', template: '%s — AIComp Admin' },
  description: 'AIComp Admin Dashboard',
  robots: { index: false, follow: false },
};

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body suppressHydrationWarning>
        <ThemeProvider attribute="class" defaultTheme="dark" enableSystem storageKey="aicomp-admin-theme">
          <AdminShell>
            {children}
          </AdminShell>
        </ThemeProvider>
      </body>
    </html>
  );
}
