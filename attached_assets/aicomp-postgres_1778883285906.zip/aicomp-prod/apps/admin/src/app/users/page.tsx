'use client';
import { useState } from 'react';
import { Search, Shield, Ban, Eye } from 'lucide-react';

const USERS = [
  { name: 'Rohan Sharma', email: 'rohan@gmail.com', role: 'USER', reviews: 12, alerts: 5, joined: 'Jan 15, 2025', isBanned: false },
  { name: 'Priya Patel', email: 'priya@outlook.com', role: 'USER', reviews: 8, alerts: 12, joined: 'Feb 3, 2025', isBanned: false },
  { name: 'Content Admin', email: 'content@aicomp.in', role: 'CONTENT_MANAGER', reviews: 0, alerts: 0, joined: 'Dec 1, 2024', isBanned: false },
];

export default function Page() {
  const [search, setSearch] = useState('');
  const filtered = USERS.filter(u => u.email.includes(search) || u.name.toLowerCase().includes(search.toLowerCase()));
  return (
    <div className="min-h-screen bg-[#050810] text-white p-6">
      <div className="max-w-5xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <h1 className="font-[Syne] font-extrabold text-3xl">Users</h1>
          <div className="relative">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
            <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search users..." className="bg-[#0d1526] border border-white/[0.07] rounded-xl pl-9 pr-4 py-2.5 text-sm text-white outline-none w-64" />
          </div>
        </div>
        <div className="bg-[#0d1526] border border-white/[0.07] rounded-2xl overflow-hidden">
          <div className="divide-y divide-white/[0.04]">
            {filtered.map((u, i) => (
              <div key={i} className="flex items-center gap-4 px-5 py-4 hover:bg-white/[0.02]">
                <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-cyan-500 to-violet-500 flex items-center justify-center font-bold text-sm text-white flex-shrink-0">{u.name[0]}</div>
                <div className="flex-1">
                  <div className="text-sm font-medium text-white">{u.name}</div>
                  <div className="text-xs text-slate-500">{u.email} · Joined {u.joined}</div>
                </div>
                <span className="text-xs px-2 py-0.5 rounded-lg border text-cyan-400 border-cyan-400/20">{u.role.replace('_',' ')}</span>
                <div className="flex gap-1.5">
                  <button className="p-1.5 text-slate-400 hover:text-white rounded-lg"><Eye size={13} /></button>
                  <button className="p-1.5 text-slate-400 hover:text-cyan-400 rounded-lg"><Shield size={13} /></button>
                  <button className="p-1.5 text-red-400 hover:bg-red-400/10 rounded-lg"><Ban size={13} /></button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
