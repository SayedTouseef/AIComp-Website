'use client';
import { useState } from 'react';
import { Plus, Edit, Trash2, ChevronRight } from 'lucide-react';

const CATS = [
  { name: 'Smartphones', slug: 'smartphones', emoji: '📱', products: 4231, children: 3, isActive: true },
  { name: 'Laptops', slug: 'laptops', emoji: '💻', products: 1834, children: 4, isActive: true },
  { name: 'TVs', slug: 'tvs', emoji: '📺', products: 923, children: 2, isActive: true },
  { name: 'Air Conditioners', slug: 'air-conditioners', emoji: '❄️', products: 654, children: 3, isActive: true },
  { name: 'Gaming PCs', slug: 'gaming-pcs', emoji: '🎮', products: 387, children: 0, isActive: true },
];

export default function Page() {
  return (
    <div className="min-h-screen bg-[#050810] text-white p-6">
      <div className="max-w-5xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <h1 className="font-[Syne] font-extrabold text-3xl">Categories</h1>
          <button className="flex items-center gap-2 bg-gradient-to-r from-cyan-500 to-violet-500 text-white px-4 py-2 rounded-xl text-sm font-medium">
            <Plus size={14} /> Add Category
          </button>
        </div>
        <div className="bg-[#0d1526] border border-white/[0.07] rounded-2xl overflow-hidden">
          <div className="grid grid-cols-[2fr_1fr_1fr_80px_100px] px-5 py-3 border-b border-white/[0.05] text-xs text-slate-500 uppercase tracking-wider">
            <div>Category</div><div>Products</div><div>Sub</div><div>Status</div><div>Actions</div>
          </div>
          <div className="divide-y divide-white/[0.04]">
            {CATS.map((c, i) => (
              <div key={i} className="grid grid-cols-[2fr_1fr_1fr_80px_100px] px-5 py-4 items-center hover:bg-white/[0.02]">
                <div className="flex items-center gap-3">
                  <span className="text-2xl">{c.emoji}</span>
                  <div><div className="text-sm font-medium text-white">{c.name}</div><div className="text-xs text-slate-500">{c.slug}</div></div>
                </div>
                <div className="text-sm text-slate-400">{c.products.toLocaleString()}</div>
                <div className="text-sm text-slate-400">{c.children}</div>
                <span className="text-xs px-2.5 py-1 rounded-lg border text-emerald-400 border-emerald-400/20 inline-block">{c.isActive ? 'Active' : 'Hidden'}</span>
                <div className="flex gap-1.5">
                  <button className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-white/[0.05]"><Edit size={13} /></button>
                  <button className="p-1.5 text-slate-400 hover:text-red-400 rounded-lg hover:bg-red-400/10"><Trash2 size={13} /></button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
