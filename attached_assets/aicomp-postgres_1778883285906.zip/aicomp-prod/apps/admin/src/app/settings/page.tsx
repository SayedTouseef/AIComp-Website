'use client';
import { useState } from 'react';
import { Save, AlertTriangle } from 'lucide-react';

export default function Page() {
  const [maintenance, setMaintenance] = useState(false);
  const [crawlInterval, setCrawlInterval] = useState('240');
  return (
    <div className="min-h-screen bg-[#050810] text-white p-6">
      <div className="max-w-3xl mx-auto">
        <h1 className="font-[Syne] font-extrabold text-3xl mb-6">Settings</h1>
        <div className="space-y-5">
          <div className="bg-[#0d1526] border border-white/[0.07] rounded-2xl p-6">
            <h2 className="font-semibold text-lg mb-4">Crawler Settings</h2>
            <div><label className="text-xs text-slate-500 block mb-1.5">Price Update Interval (minutes)</label><input type="number" value={crawlInterval} onChange={e => setCrawlInterval(e.target.value)} className="w-full bg-[#070d1a] border border-white/[0.07] rounded-xl px-4 py-3 text-sm text-white outline-none" /></div>
          </div>
          <div className="bg-[#0d1526] border border-white/[0.07] rounded-2xl p-6">
            <h2 className="font-semibold text-lg mb-4 text-amber-400 flex items-center gap-2"><AlertTriangle size={18} /> Danger Zone</h2>
            <div className="flex items-center justify-between">
              <div><div className="text-sm text-white">Maintenance Mode</div><div className="text-xs text-slate-500 mt-0.5">Show maintenance page</div></div>
              <button onClick={() => setMaintenance(!maintenance)} className={`relative w-11 h-6 rounded-full transition-colors ${maintenance ? 'bg-red-500' : 'bg-white/10'}`}>
                <div className={`absolute top-1 w-4 h-4 bg-white rounded-full shadow transition-transform ${maintenance ? 'translate-x-6' : 'translate-x-1'}`} />
              </button>
            </div>
          </div>
          <button className="flex items-center gap-2 bg-gradient-to-r from-cyan-500 to-violet-500 text-white px-6 py-3 rounded-xl text-sm font-medium"><Save size={14} /> Save Settings</button>
        </div>
      </div>
    </div>
  );
}
