'use client';
import { useState } from 'react';
import { Move, Edit, Plus, Save } from 'lucide-react';

const SECTIONS = [
  { type: 'hero', title: 'Hero Banner', isVisible: true, order: 1 },
  { type: 'featured', title: 'Featured Products', isVisible: true, order: 2 },
  { type: 'trending', title: 'Trending Now', isVisible: true, order: 3 },
  { type: 'deals', title: "Today's Deals", isVisible: true, order: 4 },
  { type: 'launches', title: 'New Launches', isVisible: false, order: 5 },
  { type: 'ad_banner', title: 'Ad Banner', isVisible: true, order: 6 },
];

export default function Page() {
  const [sections, setSections] = useState(SECTIONS);
  const toggle = (i: number) => setSections(p => p.map((s, j) => j === i ? {...s, isVisible: !s.isVisible} : s));
  return (
    <div className="min-h-screen bg-[#050810] text-white p-6">
      <div className="max-w-3xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <h1 className="font-[Syne] font-extrabold text-3xl">Homepage CMS</h1>
          <button className="flex items-center gap-2 bg-gradient-to-r from-cyan-500 to-violet-500 text-white px-4 py-2 rounded-xl text-sm font-medium"><Plus size={14} /> Add Section</button>
        </div>
        <p className="text-slate-400 text-sm mb-5">Toggle sections on/off and reorder the homepage.</p>
        <div className="space-y-3">
          {sections.map((s, i) => (
            <div key={i} className="bg-[#0d1526] border border-white/[0.07] rounded-xl flex items-center gap-4 px-4 py-3.5">
              <button className="text-slate-600 hover:text-slate-400 cursor-grab"><Move size={16} /></button>
              <div className="w-6 h-6 rounded-md bg-white/[0.05] flex items-center justify-center text-xs text-slate-500 flex-shrink-0">{s.order}</div>
              <div className="flex-1"><div className="text-sm font-medium text-white">{s.title}</div><div className="text-xs text-slate-500 capitalize">{s.type.replace('_',' ')}</div></div>
              <button onClick={() => toggle(i)} className={`relative w-9 h-5 rounded-full transition-colors flex-shrink-0 ${s.isVisible ? 'bg-cyan-500' : 'bg-white/10'}`}>
                <div className={`absolute top-0.5 w-4 h-4 bg-white rounded-full shadow transition-transform ${s.isVisible ? 'translate-x-4' : 'translate-x-0.5'}`} />
              </button>
              <button className="p-1.5 text-slate-400 hover:text-white hover:bg-white/[0.05] rounded-lg"><Edit size={13} /></button>
            </div>
          ))}
        </div>
        <button className="mt-6 flex items-center gap-2 bg-gradient-to-r from-cyan-500 to-violet-500 text-white px-5 py-2.5 rounded-xl text-sm font-medium"><Save size={14} /> Save Layout</button>
      </div>
    </div>
  );
}
