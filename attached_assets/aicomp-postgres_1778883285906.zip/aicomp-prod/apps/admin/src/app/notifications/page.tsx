'use client';
import { useState } from 'react';
import { Send, Users } from 'lucide-react';

export default function Page() {
  const [title, setTitle] = useState('');
  const [body, setBody] = useState('');
  return (
    <div className="min-h-screen bg-[#050810] text-white p-6">
      <div className="max-w-4xl mx-auto">
        <h1 className="font-[Syne] font-extrabold text-3xl mb-6">Notifications</h1>
        <div className="grid md:grid-cols-2 gap-6">
          <div className="bg-[#0d1526] border border-white/[0.07] rounded-2xl p-6">
            <h2 className="font-semibold text-lg mb-4">Broadcast Message</h2>
            <div className="space-y-4">
              <div><label className="text-xs text-slate-500 block mb-1.5">Title</label><input value={title} onChange={e => setTitle(e.target.value)} placeholder="Flash Sale!" className="w-full bg-[#070d1a] border border-white/[0.07] rounded-xl px-4 py-3 text-sm text-white outline-none" /></div>
              <div><label className="text-xs text-slate-500 block mb-1.5">Message</label><textarea value={body} onChange={e => setBody(e.target.value)} rows={4} className="w-full bg-[#070d1a] border border-white/[0.07] rounded-xl px-4 py-3 text-sm text-white outline-none resize-none" /></div>
              <button className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-cyan-500 to-violet-500 text-white py-3 rounded-xl text-sm font-medium"><Send size={14} /> Send to All Users</button>
            </div>
          </div>
          <div className="bg-[#0d1526] border border-white/[0.07] rounded-2xl p-5">
            <h3 className="font-semibold mb-4 flex items-center gap-2"><Users size={16} className="text-violet-400" /> Audience</h3>
            {[['Total Users','48,234'],['Push Subscribers','23,100'],['Email Subscribers','41,890'],['WhatsApp Users','8,234']].map(([l,v]) => (
              <div key={l} className="flex justify-between py-2.5 border-b border-white/[0.04] last:border-0 text-sm"><span className="text-slate-400">{l}</span><span className="font-mono text-white">{v}</span></div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
