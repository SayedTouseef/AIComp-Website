'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import {
  LineChart, Line, BarChart, Bar, AreaChart, Area,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell
} from 'recharts';
import {
  Package, TrendingUp, DollarSign, Users, Eye, Search,
  Bell, ShoppingCart, Activity, Zap, AlertCircle, CheckCircle, Clock,
  ArrowUp, ArrowDown, MoreHorizontal, RefreshCw, Bot, Globe, Cpu
} from 'lucide-react';

// ─── Stat card ─────────────────────────────────────────────

function StatCard({ title, value, change, icon: Icon, color, suffix = '' }: any) {
  const isPositive = change >= 0;
  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-[#0d1526] border border-white/[0.07] rounded-2xl p-5 hover:border-white/[0.12] transition-colors"
    >
      <div className="flex items-start justify-between mb-4">
        <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${color}`}>
          <Icon size={18} />
        </div>
        <div className={`flex items-center gap-1 text-xs font-mono font-bold ${isPositive ? 'text-emerald-400' : 'text-red-400'}`}>
          {isPositive ? <ArrowUp size={11} /> : <ArrowDown size={11} />}
          {Math.abs(change)}%
        </div>
      </div>
      <div className="text-2xl font-bold text-white tracking-tight mb-1">
        {value}{suffix}
      </div>
      <div className="text-xs text-slate-500">{title}</div>
    </motion.div>
  );
}

// ─── Product approval queue ────────────────────────────────

function ApprovalQueue({ items }: { items: any[] }) {
  return (
    <div className="bg-[#0d1526] border border-white/[0.07] rounded-2xl overflow-hidden">
      <div className="px-5 py-4 border-b border-white/[0.07] flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Clock size={16} className="text-amber-400" />
          <span className="font-semibold text-white">Pending Approval</span>
          <span className="bg-amber-400/10 text-amber-400 text-xs font-mono px-2 py-0.5 rounded-full">{items.length}</span>
        </div>
        <button className="text-xs text-slate-400 hover:text-white transition-colors">View all →</button>
      </div>
      <div className="divide-y divide-white/[0.04]">
        {items.slice(0, 5).map((item, i) => (
          <div key={i} className="px-5 py-3.5 flex items-center justify-between hover:bg-white/[0.02] transition-colors">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-white/[0.05] border border-white/[0.07] flex items-center justify-center text-sm">
                {item.emoji}
              </div>
              <div>
                <div className="text-sm font-medium text-white">{item.name}</div>
                <div className="text-xs text-slate-500">{item.source} · {item.time}</div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <button className="px-3 py-1.5 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs rounded-lg hover:bg-emerald-500/20 transition-colors">
                ✓ Approve
              </button>
              <button className="px-3 py-1.5 bg-red-500/10 border border-red-500/20 text-red-400 text-xs rounded-lg hover:bg-red-500/20 transition-colors">
                ✗ Reject
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Recent activity feed ──────────────────────────────────

function ActivityFeed({ events }: { events: any[] }) {
  const icons: any = {
    product: <Package size={14} />,
    price: <DollarSign size={14} />,
    user: <Users size={14} />,
    alert: <Bell size={14} />,
    crawler: <Activity size={14} />,
  };
  const colors: any = {
    product: 'text-cyan-400 bg-cyan-400/10',
    price: 'text-emerald-400 bg-emerald-400/10',
    user: 'text-violet-400 bg-violet-400/10',
    alert: 'text-amber-400 bg-amber-400/10',
    crawler: 'text-blue-400 bg-blue-400/10',
  };

  return (
    <div className="bg-[#0d1526] border border-white/[0.07] rounded-2xl overflow-hidden">
      <div className="px-5 py-4 border-b border-white/[0.07] flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Activity size={16} className="text-cyan-400" />
          <span className="font-semibold text-white">Live Activity</span>
          <span className="flex items-center gap-1 text-xs text-emerald-400">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
            Live
          </span>
        </div>
      </div>
      <div className="divide-y divide-white/[0.04] max-h-72 overflow-y-auto">
        {events.map((event, i) => (
          <div key={i} className="px-5 py-3 flex items-start gap-3">
            <div className={`w-6 h-6 rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5 ${colors[event.type]}`}>
              {icons[event.type]}
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-sm text-white">{event.message}</div>
              <div className="text-xs text-slate-500 mt-0.5">{event.time}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Main Dashboard ────────────────────────────────────────

export default function AdminDashboard() {
  const [timeRange, setTimeRange] = useState('7d');
  const [refreshing, setRefreshing] = useState(false);

  // Mock data — replace with API calls
  const stats = [
    { title: 'Total Products', value: '12,847', change: 8.3, icon: Package, color: 'bg-cyan-400/10 text-cyan-400', suffix: '' },
    { title: 'Monthly Revenue', value: '₹2.4L', change: 23.1, icon: DollarSign, color: 'bg-emerald-400/10 text-emerald-400', suffix: '' },
    { title: 'Affiliate Clicks', value: '89,234', change: 15.7, icon: ShoppingCart, color: 'bg-violet-400/10 text-violet-400', suffix: '' },
    { title: 'Total Users', value: '48,291', change: 31.2, icon: Users, color: 'bg-amber-400/10 text-amber-400', suffix: '' },
    { title: 'Page Views', value: '1.2M', change: 18.4, icon: Eye, color: 'bg-blue-400/10 text-blue-400', suffix: '' },
    { title: 'Searches Today', value: '23,471', change: 9.2, icon: Search, color: 'bg-pink-400/10 text-pink-400', suffix: '' },
    { title: 'Price Alerts', value: '8,934', change: 44.1, icon: Bell, color: 'bg-orange-400/10 text-orange-400', suffix: '' },
    { title: 'AI Chats Today', value: '3,281', change: 52.8, icon: Bot, color: 'bg-indigo-400/10 text-indigo-400', suffix: '' },
  ];

  const trafficData = [
    { date: 'Mon', views: 82000, clicks: 3200, revenue: 18400 },
    { date: 'Tue', views: 94000, clicks: 3800, revenue: 21200 },
    { date: 'Wed', views: 88000, clicks: 3500, revenue: 19800 },
    { date: 'Thu', views: 102000, clicks: 4200, revenue: 24100 },
    { date: 'Fri', views: 118000, clicks: 4900, revenue: 28300 },
    { date: 'Sat', views: 134000, clicks: 5600, revenue: 32100 },
    { date: 'Sun', views: 121000, clicks: 5100, revenue: 29400 },
  ];

  const categoryData = [
    { name: 'Smartphones', value: 38, color: '#63b3ed' },
    { name: 'Laptops', value: 22, color: '#9f7aea' },
    { name: 'TVs', value: 14, color: '#48bb78' },
    { name: 'ACs', value: 10, color: '#f6ad55' },
    { name: 'Gaming', value: 9, color: '#fc8181' },
    { name: 'Others', value: 7, color: '#6b7a9a' },
  ];

  const pendingProducts = [
    { name: 'Samsung Galaxy S25 Ultra', emoji: '📱', source: 'Amazon Crawler', time: '2 min ago' },
    { name: 'MacBook Air M4', emoji: '💻', source: 'Manual Import', time: '8 min ago' },
    { name: 'Sony Bravia XR A95L', emoji: '📺', source: 'Flipkart Crawler', time: '15 min ago' },
    { name: 'Daikin 2T Inverter AC', emoji: '❄️', source: 'Croma Crawler', time: '22 min ago' },
    { name: 'ASUS ROG Strix G18', emoji: '💻', source: 'Amazon Crawler', time: '31 min ago' },
  ];

  const recentActivity = [
    { type: 'product', message: 'New product discovered: OnePlus 13R', time: '1 min ago' },
    { type: 'price', message: 'Price drop: iPhone 16 Pro ₹5,000 ↓ on Amazon', time: '3 min ago' },
    { type: 'alert', message: '142 price alerts triggered (Diwali sale)', time: '5 min ago' },
    { type: 'user', message: 'New verified buyer review: Samsung S24', time: '8 min ago' },
    { type: 'crawler', message: 'Flipkart crawler: 2,341 prices updated', time: '12 min ago' },
    { type: 'product', message: 'Product approved: LG OLED C4', time: '18 min ago' },
    { type: 'price', message: 'Price drop: MacBook M3 ₹8,000 ↓ on Flipkart', time: '24 min ago' },
    { type: 'user', message: '89 new user registrations today', time: '1 hour ago' },
  ];

  const topProducts = [
    { name: 'iPhone 16 Pro', views: 124530, affiliate: '₹12,340', category: 'Smartphones', trend: 12 },
    { name: 'Samsung S24 Ultra', views: 98234, affiliate: '₹9,870', category: 'Smartphones', trend: -3 },
    { name: 'MacBook Air M3', views: 76120, affiliate: '₹8,230', category: 'Laptops', trend: 8 },
    { name: 'ASUS ROG Strix G16', views: 64891, affiliate: '₹7,410', category: 'Laptops', trend: 24 },
    { name: 'Sony Bravia XR 65"', views: 54320, affiliate: '₹6,180', category: 'TVs', trend: 5 },
  ];

  const systemStatus = [
    { name: 'Amazon Crawler', status: 'running', lastRun: '2 min ago', color: 'text-emerald-400' },
    { name: 'Flipkart Crawler', status: 'running', lastRun: '5 min ago', color: 'text-emerald-400' },
    { name: 'Croma Crawler', status: 'idle', lastRun: '2 hours ago', color: 'text-amber-400' },
    { name: 'AI Content Engine', status: 'running', lastRun: 'Continuous', color: 'text-emerald-400' },
    { name: 'Email Worker', status: 'running', lastRun: 'Continuous', color: 'text-emerald-400' },
    { name: 'Price Alert Worker', status: 'running', lastRun: 'Continuous', color: 'text-emerald-400' },
  ];

  const handleRefresh = async () => {
    setRefreshing(true);
    await new Promise(r => setTimeout(r, 1500));
    setRefreshing(false);
  };

  return (
    <div className="min-h-screen bg-[#050810] text-white">
      <div className="max-w-[1600px] mx-auto px-6 py-8">

        {/* Page header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="font-['Syne'] font-extrabold text-3xl tracking-tight mb-1">Dashboard</h1>
            <p className="text-sm text-slate-400">AIComp Admin · Thursday, 14 May 2026</p>
          </div>
          <div className="flex items-center gap-3">
            {/* Time range */}
            <div className="flex bg-[#0d1526] border border-white/[0.07] rounded-xl p-1 gap-1">
              {['24h', '7d', '30d', '90d'].map(t => (
                <button
                  key={t}
                  onClick={() => setTimeRange(t)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                    timeRange === t ? 'bg-white/10 text-white' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {t}
                </button>
              ))}
            </div>
            <button
              onClick={handleRefresh}
              className="flex items-center gap-2 bg-[#0d1526] border border-white/[0.07] text-slate-400 hover:text-white px-4 py-2 rounded-xl text-sm transition-colors"
            >
              <RefreshCw size={14} className={refreshing ? 'animate-spin' : ''} />
              Refresh
            </button>
            <button className="flex items-center gap-2 bg-gradient-to-r from-cyan-500 to-violet-500 text-white px-4 py-2 rounded-xl text-sm font-medium">
              <Zap size={14} />
              Run Crawler
            </button>
          </div>
        </div>

        {/* Stats grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          {stats.map((stat, i) => <StatCard key={i} {...stat} />)}
        </div>

        {/* Charts row */}
        <div className="grid grid-cols-12 gap-5 mb-8">

          {/* Traffic chart */}
          <div className="col-span-12 lg:col-span-8 bg-[#0d1526] border border-white/[0.07] rounded-2xl p-5">
            <div className="flex items-center justify-between mb-5">
              <div>
                <div className="font-semibold text-white">Traffic & Revenue</div>
                <div className="text-xs text-slate-500">Last 7 days</div>
              </div>
              <div className="flex items-center gap-4 text-xs">
                <div className="flex items-center gap-1.5"><span className="w-3 h-0.5 bg-cyan-400 inline-block rounded" /> Page Views</div>
                <div className="flex items-center gap-1.5"><span className="w-3 h-0.5 bg-violet-400 inline-block rounded" /> Revenue</div>
              </div>
            </div>
            <ResponsiveContainer width="100%" height={220}>
              <AreaChart data={trafficData} margin={{ top: 0, right: 0, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="cyan" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#63b3ed" stopOpacity={0.15} />
                    <stop offset="95%" stopColor="#63b3ed" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="violet" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#9f7aea" stopOpacity={0.15} />
                    <stop offset="95%" stopColor="#9f7aea" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
                <XAxis dataKey="date" tick={{ fill: '#6b7a9a', fontSize: 11 }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fill: '#6b7a9a', fontSize: 11 }} axisLine={false} tickLine={false} />
                <Tooltip contentStyle={{ background: '#0d1526', border: '1px solid rgba(255,255,255,0.07)', borderRadius: '12px', fontSize: '12px' }} />
                <Area type="monotone" dataKey="views" stroke="#63b3ed" strokeWidth={2} fill="url(#cyan)" />
                <Area type="monotone" dataKey="revenue" stroke="#9f7aea" strokeWidth={2} fill="url(#violet)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>

          {/* Category pie */}
          <div className="col-span-12 lg:col-span-4 bg-[#0d1526] border border-white/[0.07] rounded-2xl p-5">
            <div className="font-semibold text-white mb-1">Traffic by Category</div>
            <div className="text-xs text-slate-500 mb-4">Last 7 days</div>
            <ResponsiveContainer width="100%" height={160}>
              <PieChart>
                <Pie data={categoryData} cx="50%" cy="50%" innerRadius={50} outerRadius={75} paddingAngle={3} dataKey="value">
                  {categoryData.map((entry, index) => (
                    <Cell key={index} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip formatter={(v: any) => `${v}%`} contentStyle={{ background: '#0d1526', border: '1px solid rgba(255,255,255,0.07)', borderRadius: '12px', fontSize: '12px' }} />
              </PieChart>
            </ResponsiveContainer>
            <div className="space-y-2">
              {categoryData.map((c, i) => (
                <div key={i} className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full" style={{ background: c.color }} />
                    <span className="text-slate-400">{c.name}</span>
                  </div>
                  <span className="text-white font-mono">{c.value}%</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Second row */}
        <div className="grid grid-cols-12 gap-5 mb-8">

          {/* Pending approvals */}
          <div className="col-span-12 lg:col-span-6">
            <ApprovalQueue items={pendingProducts} />
          </div>

          {/* Activity feed */}
          <div className="col-span-12 lg:col-span-6">
            <ActivityFeed events={recentActivity} />
          </div>
        </div>

        {/* Third row */}
        <div className="grid grid-cols-12 gap-5">

          {/* Top products */}
          <div className="col-span-12 lg:col-span-8 bg-[#0d1526] border border-white/[0.07] rounded-2xl overflow-hidden">
            <div className="px-5 py-4 border-b border-white/[0.07] flex items-center justify-between">
              <div className="flex items-center gap-2">
                <TrendingUp size={16} className="text-emerald-400" />
                <span className="font-semibold text-white">Top Performing Products</span>
              </div>
              <button className="text-xs text-slate-400 hover:text-white">View all →</button>
            </div>
            <div className="divide-y divide-white/[0.04]">
              {topProducts.map((p, i) => (
                <div key={i} className="px-5 py-3.5 flex items-center gap-4 hover:bg-white/[0.02] transition-colors">
                  <div className="w-6 text-slate-500 text-sm font-mono text-center">{i + 1}</div>
                  <div className="flex-1">
                    <div className="text-sm font-medium text-white">{p.name}</div>
                    <div className="text-xs text-slate-500">{p.category}</div>
                  </div>
                  <div className="text-right">
                    <div className="text-xs text-slate-400 font-mono">{p.views.toLocaleString()} views</div>
                  </div>
                  <div className="text-right w-20">
                    <div className="text-sm font-mono text-emerald-400">{p.affiliate}</div>
                    <div className="text-xs text-slate-500">revenue</div>
                  </div>
                  <div className={`flex items-center gap-0.5 text-xs font-mono ${p.trend >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                    {p.trend >= 0 ? <ArrowUp size={11} /> : <ArrowDown size={11} />}
                    {Math.abs(p.trend)}%
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* System status */}
          <div className="col-span-12 lg:col-span-4 bg-[#0d1526] border border-white/[0.07] rounded-2xl overflow-hidden">
            <div className="px-5 py-4 border-b border-white/[0.07] flex items-center gap-2">
              <Cpu size={16} className="text-cyan-400" />
              <span className="font-semibold text-white">System Status</span>
            </div>
            <div className="divide-y divide-white/[0.04]">
              {systemStatus.map((s, i) => (
                <div key={i} className="px-5 py-3 flex items-center justify-between">
                  <div>
                    <div className="text-sm text-white">{s.name}</div>
                    <div className="text-xs text-slate-500">{s.lastRun}</div>
                  </div>
                  <div className={`flex items-center gap-1.5 text-xs font-mono ${s.color}`}>
                    <div className={`w-1.5 h-1.5 rounded-full ${s.status === 'running' ? 'bg-emerald-400 animate-pulse' : 'bg-amber-400'}`} />
                    {s.status}
                  </div>
                </div>
              ))}
            </div>
            <div className="px-5 py-4 border-t border-white/[0.07]">
              <button className="w-full py-2.5 bg-white/[0.04] border border-white/[0.07] rounded-xl text-sm text-slate-400 hover:text-white hover:bg-white/[0.07] transition-colors">
                View All Workers →
              </button>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
}
