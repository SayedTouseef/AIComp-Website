'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useTheme } from 'next-themes';
import { useState, useEffect } from 'react';
import {
  LayoutDashboard, Package, Tags, Users, BarChart3,
  FileText, Settings, Bell, Globe, Sun, Moon, Monitor,
  Menu, X, ExternalLink
} from 'lucide-react';

const NAV = [
  { label: 'Dashboard',   href: '/dashboard',   icon: LayoutDashboard },
  { label: 'Products',    href: '/products',     icon: Package },
  { label: 'Categories',  href: '/categories',   icon: Tags },
  { label: 'Users',       href: '/users',        icon: Users },
  { label: 'Analytics',   href: '/analytics',    icon: BarChart3 },
  { label: 'Content/CMS', href: '/cms',          icon: FileText },
  { label: 'SEO',         href: '/seo',          icon: Globe },
  { label: 'Notifications',href: '/notifications',icon: Bell },
  { label: 'Settings',    href: '/settings',     icon: Settings },
];

function ThemeBtn() {
  const { theme, setTheme } = useTheme();
  const [m, setM] = useState(false);
  useEffect(() => setM(true), []);
  if (!m) return null;
  const next = theme === 'dark' ? 'light' : 'dark';
  const Icon = theme === 'dark' ? Sun : Moon;
  return (
    <button onClick={() => setTheme(next)} title={`Switch to ${next}`}
      style={{ background:'transparent', border:'1px solid rgba(255,255,255,0.12)', borderRadius:6, padding:'6px 10px', cursor:'pointer', color:'rgba(255,255,255,0.7)', display:'flex', alignItems:'center', gap:6, fontSize:12 }}>
      <Icon size={14} /> {next.charAt(0).toUpperCase()+next.slice(1)} mode
    </button>
  );
}

export function AdminShell({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const [sidebarOpen, setSidebarOpen] = useState(true);

  return (
    <div style={{ display:'flex', minHeight:'100vh', background:'var(--bg)' }}>
      {/* Sidebar */}
      <aside style={{
        width: sidebarOpen ? 220 : 52, flexShrink:0, transition:'width 0.2s ease',
        background:'#0d1117', borderRight:'1px solid rgba(255,255,255,0.07)',
        display:'flex', flexDirection:'column',
      }}>
        {/* Logo */}
        <div style={{ height:56, display:'flex', alignItems:'center', gap:10, padding:'0 14px', borderBottom:'1px solid rgba(255,255,255,0.06)' }}>
          <div style={{ width:28, height:28, background:'#1a6bc7', borderRadius:5, display:'flex', alignItems:'center', justifyContent:'center', fontWeight:800, fontSize:11, color:'#fff', flexShrink:0 }}>AI</div>
          {sidebarOpen && <span style={{ fontWeight:700, fontSize:15, color:'#fff' }}>AIComp Admin</span>}
          <button onClick={() => setSidebarOpen(!sidebarOpen)} style={{ marginLeft:'auto', background:'transparent', border:'none', cursor:'pointer', color:'rgba(255,255,255,0.4)', padding:4 }}>
            {sidebarOpen ? <X size={16}/> : <Menu size={16}/>}
          </button>
        </div>

        {/* Nav */}
        <nav style={{ flex:1, overflowY:'auto', padding:'10px 8px' }}>
          {NAV.map(({ label, href, icon: Icon }) => {
            const active = pathname === href || pathname.startsWith(href+'/');
            return (
              <Link key={href} href={href} title={!sidebarOpen ? label : undefined}
                style={{
                  display:'flex', alignItems:'center', gap:10,
                  padding: sidebarOpen ? '8px 10px' : '10px', marginBottom:2,
                  borderRadius:6, textDecoration:'none',
                  background: active ? 'rgba(26,107,199,0.25)' : 'transparent',
                  color: active ? '#60a5fa' : 'rgba(255,255,255,0.55)',
                  fontSize:13, fontWeight: active ? 600 : 400,
                  transition:'all 0.12s', justifyContent: sidebarOpen ? 'flex-start' : 'center',
                }}
                onMouseEnter={e => { if (!active) e.currentTarget.style.background = 'rgba(255,255,255,0.06)'; }}
                onMouseLeave={e => { if (!active) e.currentTarget.style.background = 'transparent'; }}
              >
                <Icon size={16} style={{ flexShrink:0 }} />
                {sidebarOpen && label}
              </Link>
            );
          })}
        </nav>

        {/* Bottom */}
        <div style={{ padding:'10px 8px', borderTop:'1px solid rgba(255,255,255,0.06)' }}>
          {sidebarOpen && <ThemeBtn />}
          {sidebarOpen && (
            <a href="http://localhost:3000" target="_blank" rel="noreferrer"
              style={{ display:'flex', alignItems:'center', gap:6, marginTop:8, fontSize:12, color:'rgba(255,255,255,0.4)', textDecoration:'none' }}>
              <ExternalLink size={12}/> View Site
            </a>
          )}
        </div>
      </aside>

      {/* Main content */}
      <div style={{ flex:1, display:'flex', flexDirection:'column', minWidth:0 }}>
        {/* Top bar */}
        <header style={{ height:56, background:'#0d1117', borderBottom:'1px solid rgba(255,255,255,0.06)', display:'flex', alignItems:'center', padding:'0 24px', gap:16, flexShrink:0 }}>
          <div style={{ flex:1 }} />
          <a href="http://localhost:4000/health" target="_blank" rel="noreferrer"
            style={{ fontSize:12, color:'rgba(255,255,255,0.4)', display:'flex', alignItems:'center', gap:5 }}>
            <span style={{ width:7, height:7, borderRadius:'50%', background:'#22c55e', display:'inline-block' }} />
            API Online
          </a>
          <span style={{ fontSize:12, color:'rgba(255,255,255,0.3)' }}>admin@aicomp.in</span>
        </header>

        {/* Page content */}
        <main style={{ flex:1, overflow:'auto' }}>
          {children}
        </main>
      </div>
    </div>
  );
}
