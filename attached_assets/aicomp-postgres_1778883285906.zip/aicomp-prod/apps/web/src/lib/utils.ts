import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

export function cn(...inputs: ClassValue[]) { return twMerge(clsx(inputs)); }

export function formatPrice(paise: number): string {
  return `₹${(paise / 100).toLocaleString('en-IN')}`;
}
export function formatPriceShort(paise: number): string {
  const r = paise / 100;
  if (r >= 100000) return `₹${(r/100000).toFixed(1)}L`;
  if (r >= 1000) return `₹${(r/1000).toFixed(0)}K`;
  return `₹${r}`;
}
export function discountPct(price: number, mrp: number): number {
  return Math.round((1 - price/mrp) * 100);
}
export function timeAgo(date: string | Date): string {
  const s = Math.floor((Date.now() - new Date(date).getTime()) / 1000);
  if (s < 60) return 'just now';
  if (s < 3600) return `${Math.floor(s/60)}m ago`;
  if (s < 86400) return `${Math.floor(s/3600)}h ago`;
  return `${Math.floor(s/86400)}d ago`;
}
export function scoreColor(score: number): string {
  if (score >= 85) return '#48bb78';
  if (score >= 70) return '#f6ad55';
  return '#fc8181';
}
export function scoreLabel(score: number): string {
  if (score >= 90) return 'Excellent';
  if (score >= 80) return 'Very Good';
  if (score >= 70) return 'Good';
  if (score >= 60) return 'Average';
  return 'Below Average';
}
export function slugify(text: string): string {
  return text.toLowerCase().trim().replace(/[^\w\s-]/g,'').replace(/[\s_-]+/g,'-').replace(/^-+|-+$/g,'');
}
export function truncate(text: string, length: number): string {
  return text.length <= length ? text : text.slice(0, length).trim() + '…';
}
export function sleep(ms: number) { return new Promise(r => setTimeout(r, ms)); }
export function debounce<T extends (...args: any[]) => any>(fn: T, delay: number) {
  let timer: ReturnType<typeof setTimeout>;
  return (...args: Parameters<T>) => { clearTimeout(timer); timer = setTimeout(() => fn(...args), delay); };
}
