import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';

const API_BASE = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:4000/api/v1';

async function apiFetch(path: string, options?: RequestInit) {
  const token = typeof window !== 'undefined' ? localStorage.getItem('token') : null;
  const res = await fetch(`${API_BASE}${path}`, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...options?.headers,
    },
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: 'Request failed' }));
    throw new Error(err.error || `HTTP ${res.status}`);
  }
  return res.json();
}

export const api = {
  get: (path: string) => apiFetch(path),
  post: (path: string, body: object) => apiFetch(path, { method: 'POST', body: JSON.stringify(body) }),
  put: (path: string, body: object) => apiFetch(path, { method: 'PUT', body: JSON.stringify(body) }),
  delete: (path: string) => apiFetch(path, { method: 'DELETE' }),
};

// Product hooks
export function useProduct(slug: string) {
  return useQuery({ queryKey: ['product', slug], queryFn: () => api.get(`/products/${slug}`), enabled: !!slug });
}

export function useProducts(params: Record<string, any> = {}) {
  const qs = new URLSearchParams(params).toString();
  return useQuery({ queryKey: ['products', params], queryFn: () => api.get(`/products?${qs}`) });
}

export function useSimilarProducts(slug: string) {
  return useQuery({ queryKey: ['similar', slug], queryFn: () => api.get(`/products/${slug}/similar`), enabled: !!slug });
}

export function useProductAiSummary(slug: string) {
  return useQuery({ queryKey: ['ai-summary', slug], queryFn: () => api.get(`/products/${slug}/ai-summary`), enabled: !!slug, staleTime: 86400000 });
}

// Category hooks
export function useCategories() {
  return useQuery({ queryKey: ['categories'], queryFn: () => api.get('/categories'), staleTime: 3600000 });
}

export function useCategory(slug: string) {
  return useQuery({ queryKey: ['category', slug], queryFn: () => api.get(`/categories/${slug}`), enabled: !!slug });
}

// Prices
export function usePrices(productId: string) {
  return useQuery({ queryKey: ['prices', productId], queryFn: () => api.get(`/prices/${productId}`), enabled: !!productId, refetchInterval: 300000 });
}

export function useBuyPrediction(productId: string) {
  return useQuery({ queryKey: ['buy-prediction', productId], queryFn: () => api.get(`/ai/should-i-buy/${productId}`), enabled: !!productId, staleTime: 21600000 });
}

// Search
export function useSearch(query: string, params: Record<string, any> = {}) {
  const qs = new URLSearchParams({ q: query, ...params }).toString();
  return useQuery({ queryKey: ['search', query, params], queryFn: () => api.get(`/search?${qs}`), enabled: query.length > 1 });
}

// Deals
export function useDeals() {
  return useQuery({ queryKey: ['deals'], queryFn: () => api.get('/deals'), staleTime: 1800000 });
}

export function useFlashDeals() {
  return useQuery({ queryKey: ['flash-deals'], queryFn: () => api.get('/deals/flash'), refetchInterval: 60000 });
}

// AI Chat
export function useAiChat() {
  return useMutation({
    mutationFn: ({ messages, context }: any) => api.post('/ai/chat', { messages, context }),
  });
}

// Alerts
export function useAlerts() {
  return useQuery({ queryKey: ['alerts'], queryFn: () => api.get('/alerts') });
}

export function useCreateAlert() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (data: any) => api.post('/alerts', data),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['alerts'] }),
  });
}

// Wishlist
export function useWishlist() {
  return useQuery({ queryKey: ['wishlist'], queryFn: () => api.get('/users/wishlist') });
}

export function useToggleWishlist() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ productId, inWishlist }: { productId: string; inWishlist: boolean }) =>
      inWishlist ? api.delete(`/users/wishlist/${productId}`) : api.post('/users/wishlist', { productId }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['wishlist'] }),
  });
}

// Notifications
export function useNotifications() {
  return useQuery({ queryKey: ['notifications'], queryFn: () => api.get('/notifications'), refetchInterval: 30000 });
}

// PC Builder
export function usePublicBuilds() {
  return useQuery({ queryKey: ['pc-builds-public'], queryFn: () => api.get('/pc-builder/builds/public') });
}

// Trending insights
export function useTrendingInsights() {
  return useQuery({ queryKey: ['trending'], queryFn: () => api.get('/ai/trending-insights'), staleTime: 1800000 });
}
