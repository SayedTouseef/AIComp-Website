import type { Metadata } from 'next';
export const metadata: Metadata = { title:'Trending Electronics in India — AIComp' };
export default function TrendingPage() {
  return (
    <div className="max-w-container mx-auto px-6 py-8">
      <div className="section-label">📈 Live Data</div>
      <h1 className="font-display font-extrabold text-4xl tracking-tight mb-4" style={{ color:'var(--text)' }}>Trending Right Now</h1>
      <p style={{ color:'var(--text-muted)' }}>Most searched and compared products in the last 24 hours.</p>
    </div>
  );
}
