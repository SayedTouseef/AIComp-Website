'use client';

import Link from 'next/link';
import { useState, useEffect } from 'react';
import { AdLeaderboard, AdRectangle } from '@/components/ads/AdRail';
import { TrendingUp, Zap, Star, ArrowRight, ChevronRight } from 'lucide-react';

const API = process.env.NEXT_PUBLIC_API_URL ?? 'http://localhost:4000';

const QUICK_CATS = [
  { name: 'Smartphones',     slug: 'smartphones',     emoji: '📱', desc: '4,200+ phones' },
  { name: 'Laptops',         slug: 'laptops',         emoji: '💻', desc: '1,800+ models' },
  { name: 'Smart TVs',       slug: 'tvs',             emoji: '📺', desc: '900+ TVs' },
  { name: 'Air Conditioners',slug: 'air-conditioners',emoji: '❄️', desc: '650+ ACs' },
  { name: 'Gaming PCs',      slug: 'gaming-pcs',      emoji: '🎮', desc: '380+ rigs' },
  { name: 'Cameras',         slug: 'cameras',         emoji: '📷', desc: '540+ cameras' },
  { name: 'Monitors',        slug: 'monitors',        emoji: '🖥️', desc: '720+ screens' },
  { name: 'Headphones',      slug: 'headphones',      emoji: '🎧', desc: '1,100+ pairs' },
];

const TRENDING_NOW = [
  { name:'iPhone 16 Pro 256GB', brand:'Apple', cat:'Smartphones', price:'₹1,19,900', score:96, trend:'+234%' },
  { name:'Samsung Galaxy S25 Ultra', brand:'Samsung', cat:'Smartphones', price:'₹1,24,999', score:91, trend:'+189%' },
  { name:'MacBook Air M4', brand:'Apple', cat:'Laptops', price:'₹1,09,900', score:94, trend:'+156%' },
  { name:'ASUS ROG Strix G16', brand:'ASUS', cat:'Laptops', price:'₹1,12,990', score:92, trend:'+98%' },
  { name:'Sony Bravia 55" OLED', brand:'Sony', cat:'TVs', price:'₹1,49,990', score:89, trend:'+76%' },
  { name:'Daikin 1.5T 5-Star', brand:'Daikin', cat:'ACs', price:'₹48,990', score:88, trend:'+71%' },
  { name:'OnePlus 13', brand:'OnePlus', cat:'Smartphones', price:'₹69,999', score:87, trend:'+65%' },
  { name:'Dell XPS 15 (2025)', brand:'Dell', cat:'Laptops', price:'₹1,64,990', score:90, trend:'+52%' },
];

const RECENT_LAUNCHES = [
  { name:'Samsung Galaxy S25 Ultra', date:'Jan 22, 2025', price:'₹1,29,999', status:'available', emoji:'📱' },
  { name:'Apple MacBook Air M4',     date:'Mar 12, 2025', price:'₹1,09,900', status:'available', emoji:'💻' },
  { name:'Nothing Phone (3)',         date:'Apr 1, 2025',  price:'₹44,999',  status:'available', emoji:'📱' },
  { name:'iPhone 17 Pro',            date:'Sep 2025',      price:'~₹1,35,000',status:'rumoured', emoji:'📱' },
  { name:'RTX 5080',                 date:'Q2 2025',       price:'~₹1,10,000',status:'rumoured', emoji:'🖥️' },
  { name:'MacBook Air M5',           date:'Mid 2025',      price:'~₹1,20,000',status:'expected', emoji:'💻' },
];

const TOP_GUIDES = [
  { title:'Best Phones Under ₹30,000 (2025)', cat:'📱 Smartphones', views:'45K', slug:'best-phones-under-30000' },
  { title:'Best Gaming Laptops Under ₹1 Lakh', cat:'💻 Laptops', views:'39K', slug:'best-gaming-laptops-1-lakh' },
  { title:'Best 1.5 Ton Inverter AC India', cat:'❄️ ACs', views:'29K', slug:'best-inverter-ac-india' },
  { title:'RTX 4070 vs RX 7800 XT India', cat:'🖥️ GPUs', views:'17K', slug:'rtx-4070-vs-rx-7800' },
  { title:'Best 4K TV Under ₹50,000', cat:'📺 TVs', views:'19K', slug:'best-4k-tv-50000' },
];

function SectionHead({ title, href, label = 'See all' }: { title: string; href?: string; label?: string }) {
  return (
    <div className="section-head">
      <span>{title}</span>
      {href && <Link href={href}>{label} →</Link>}
    </div>
  );
}

function ProductMiniCard({ p, rank }: { p: typeof TRENDING_NOW[0]; rank: number }) {
  return (
    <a href={`/search?q=${encodeURIComponent(p.name)}`}
      style={{ display:'flex', alignItems:'center', gap:10, padding:'8px 12px', borderBottom:'1px solid var(--divider)', textDecoration:'none', transition:'background 0.1s' }}
      onMouseEnter={e => (e.currentTarget.style.background = 'var(--surface2)')}
      onMouseLeave={e => (e.currentTarget.style.background = '')}
    >
      <span style={{ fontSize:11, fontWeight:700, color:'var(--text-dim)', width:18, textAlign:'right', flexShrink:0 }}>{rank}</span>
      <div style={{ width:40, height:40, background:'var(--surface2)', borderRadius:4, display:'flex', alignItems:'center', justifyContent:'center', fontSize:20, flexShrink:0 }}>📱</div>
      <div style={{ flex:1, minWidth:0 }}>
        <div style={{ fontSize:12, fontWeight:600, color:'var(--text)', overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{p.name}</div>
        <div style={{ fontSize:11, color:'var(--text-muted)' }}>{p.brand} · {p.cat}</div>
      </div>
      <div style={{ textAlign:'right', flexShrink:0 }}>
        <div style={{ fontSize:12, fontWeight:700, color:'var(--green)' }}>{p.price}</div>
        <div style={{ fontSize:10, color:'var(--green)', opacity:0.8 }}>{p.trend}</div>
      </div>
    </a>
  );
}

export default function HomePage() {
  const [deals, setDeals] = useState<any[]>([]);

  useEffect(() => {
    fetch(`${API}/api/v1/deals/flash`).then(r => r.json()).then(d => setDeals(d.deals ?? [])).catch(() => {});
  }, []);

  return (
    <div style={{ padding: '0' }}>

      {/* Leaderboard ad — top of content */}
      <div style={{ padding: '0 16px' }}>
        <AdLeaderboard />
      </div>

      {/* ── Hero strip ── */}
      <div style={{ background:'var(--blue)', padding:'14px 16px', display:'flex', alignItems:'center', justifyContent:'space-between', flexWrap:'wrap', gap:10 }}>
        <div>
          <div style={{ fontFamily:'"Roboto Condensed",sans-serif', fontWeight:700, fontSize:22, color:'#fff', lineHeight:1.2 }}>
            AI-Powered Electronics Comparison
          </div>
          <div style={{ fontSize:12, color:'rgba(255,255,255,0.75)', marginTop:4 }}>
            4,200+ products · Live prices from 50+ sellers · AI buying advice
          </div>
        </div>
        <div style={{ display:'flex', gap:8 }}>
          <a href="/compare" style={{ background:'#fff', color:'var(--blue-dark)', padding:'7px 16px', borderRadius:4, fontSize:13, fontWeight:700, textDecoration:'none', display:'flex', alignItems:'center', gap:6 }}>
            ⚖️ Compare
          </a>
          <a href="/ai-assistant" style={{ background:'rgba(255,255,255,0.15)', color:'#fff', padding:'7px 16px', borderRadius:4, fontSize:13, fontWeight:600, textDecoration:'none', border:'1px solid rgba(255,255,255,0.3)', display:'flex', alignItems:'center', gap:6 }}>
            ✦ Ask AI
          </a>
        </div>
      </div>

      {/* ── Category quick-access ── */}
      <div style={{ padding:'14px 16px', borderBottom:'1px solid var(--border)' }}>
        <div style={{ display:'grid', gridTemplateColumns:'repeat(8, 1fr)', gap:6 }}>
          {QUICK_CATS.map(c => (
            <a key={c.slug} href={`/category/${c.slug}`}
              style={{ display:'flex', flexDirection:'column', alignItems:'center', gap:4, padding:'10px 6px', background:'var(--card)', border:'1px solid var(--border)', borderRadius:5, textDecoration:'none', transition:'all 0.12s', cursor:'pointer' }}
              onMouseEnter={e => { e.currentTarget.style.borderColor = 'var(--blue)'; e.currentTarget.style.background = 'var(--blue-bg)'; }}
              onMouseLeave={e => { e.currentTarget.style.borderColor = 'var(--border)'; e.currentTarget.style.background = 'var(--card)'; }}
            >
              <span style={{ fontSize:24 }}>{c.emoji}</span>
              <span style={{ fontSize:11, fontWeight:600, color:'var(--text)', textAlign:'center', lineHeight:1.2 }}>{c.name}</span>
              <span style={{ fontSize:10, color:'var(--text-dim)' }}>{c.desc}</span>
            </a>
          ))}
        </div>
      </div>

      {/* ── Main 2-col content grid ── */}
      <div style={{ display:'grid', gridTemplateColumns:'1fr 300px', gap:0, padding:'14px 16px 0', alignItems:'start' }}>

        {/* Left column — main content */}
        <div style={{ paddingRight:14, borderRight:'1px solid var(--border)' }}>

          {/* Trending products */}
          <div style={{ marginBottom:16 }}>
            <SectionHead title="🔥 Trending Right Now" href="/trending" />
            <div className="section-body">
              {TRENDING_NOW.map((p, i) => <ProductMiniCard key={i} p={p} rank={i+1} />)}
            </div>
          </div>

          {/* Leaderboard ad mid-content */}
          <AdLeaderboard />

          {/* New launches */}
          <div style={{ marginBottom:16 }}>
            <SectionHead title="🚀 Recent & Upcoming Launches" href="/launches" />
            <div className="section-body" style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:0 }}>
              {RECENT_LAUNCHES.map((l, i) => (
                <a key={i} href={`/search?q=${encodeURIComponent(l.name)}`}
                  style={{ display:'flex', alignItems:'center', gap:10, padding:'9px 12px', borderBottom:i < 4 ? '1px solid var(--divider)' : undefined, borderRight:i%2===0?'1px solid var(--divider)':undefined, textDecoration:'none' }}
                  onMouseEnter={e => (e.currentTarget.style.background = 'var(--surface2)')}
                  onMouseLeave={e => (e.currentTarget.style.background = '')}
                >
                  <span style={{ fontSize:20, flexShrink:0 }}>{l.emoji}</span>
                  <div style={{ flex:1, minWidth:0 }}>
                    <div style={{ fontSize:12, fontWeight:600, color:'var(--text)', overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{l.name}</div>
                    <div style={{ display:'flex', gap:8, marginTop:2, alignItems:'center' }}>
                      <span style={{ fontSize:11, color:'var(--green)', fontWeight:700 }}>{l.price}</span>
                      <span style={{
                        fontSize:10, padding:'1px 5px', borderRadius:3, fontWeight:600,
                        background: l.status==='available'?'var(--green-bg)': l.status==='expected'?'var(--blue-bg)':'var(--orange-bg)',
                        color: l.status==='available'?'var(--green)': l.status==='expected'?'var(--blue)':'var(--orange)',
                      }}>
                        {l.status}
                      </span>
                    </div>
                    <div style={{ fontSize:10, color:'var(--text-dim)', marginTop:1 }}>{l.date}</div>
                  </div>
                </a>
              ))}
            </div>
          </div>

          {/* Features strip */}
          <div style={{ marginBottom:16 }}>
            <SectionHead title="✦ Platform Features" />
            <div className="section-body" style={{ display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:0 }}>
              {[
                { icon:'🤖', title:'AI Shopping Assistant', desc:'Ask in plain English. Get expert buying advice for India.', href:'/ai-assistant' },
                { icon:'🔔', title:'Price Drop Alerts', desc:'Set target price. Get notified via WhatsApp, Telegram or email.', href:'/alerts' },
                { icon:'⚖️', title:'Side-by-Side Compare', desc:'Compare up to 4 products with AI verdict and spec highlighting.', href:'/compare' },
                { icon:'🎮', title:'Gaming FPS Database', desc:'Tested FPS data for 200+ games across 50+ GPUs.', href:'/gaming' },
                { icon:'🖥️', title:'PC Builder Tool', desc:'Build your perfect PC with FPS estimates and compatibility checks.', href:'/pc-builder' },
                { icon:'📊', title:'AI Score System', desc:'Every product scored across 8 dimensions: battery, camera, value...', href:'/compare' },
              ].map((f, i) => (
                <a key={i} href={f.href}
                  style={{ display:'flex', gap:10, padding:'11px 12px', borderRight:i%3<2?'1px solid var(--divider)':undefined, borderBottom:i<3?'1px solid var(--divider)':undefined, textDecoration:'none' }}
                  onMouseEnter={e => (e.currentTarget.style.background = 'var(--surface2)')}
                  onMouseLeave={e => (e.currentTarget.style.background = '')}
                >
                  <span style={{ fontSize:22, flexShrink:0, marginTop:2 }}>{f.icon}</span>
                  <div>
                    <div style={{ fontSize:12, fontWeight:700, color:'var(--blue)' }}>{f.title}</div>
                    <div style={{ fontSize:11, color:'var(--text-muted)', lineHeight:1.5, marginTop:2 }}>{f.desc}</div>
                  </div>
                </a>
              ))}
            </div>
          </div>

        </div>

        {/* Right sidebar */}
        <div style={{ paddingLeft:14 }}>

          {/* Ad rectangle */}
          <div style={{ marginBottom:14, display:'flex', justifyContent:'center' }}>
            <AdRectangle />
          </div>

          {/* Buying guides */}
          <div style={{ marginBottom:14 }}>
            <SectionHead title="📖 Buying Guides" href="/guides" label="More" />
            <div className="section-body">
              {TOP_GUIDES.map((g, i) => (
                <a key={i} href={`/guides/${g.slug}`}
                  style={{ display:'flex', gap:10, padding:'9px 12px', borderBottom:i<TOP_GUIDES.length-1?'1px solid var(--divider)':undefined, alignItems:'flex-start', textDecoration:'none' }}
                  onMouseEnter={e => (e.currentTarget.style.background = 'var(--surface2)')}
                  onMouseLeave={e => (e.currentTarget.style.background = '')}
                >
                  <ChevronRight size={13} style={{ color:'var(--blue)', flexShrink:0, marginTop:2 }} />
                  <div>
                    <div style={{ fontSize:12, fontWeight:600, color:'var(--text)', lineHeight:1.4 }}>{g.title}</div>
                    <div style={{ display:'flex', gap:8, marginTop:3 }}>
                      <span style={{ fontSize:10, color:'var(--text-muted)' }}>{g.cat}</span>
                      <span style={{ fontSize:10, color:'var(--text-dim)' }}>👁 {g.views}</span>
                    </div>
                  </div>
                </a>
              ))}
            </div>
          </div>

          {/* AI assistant teaser */}
          <div style={{ marginBottom:14 }}>
            <SectionHead title="✦ Ask AI" href="/ai-assistant" label="Open" />
            <div className="section-body" style={{ padding:12 }}>
              <div style={{ fontSize:12, color:'var(--text-muted)', marginBottom:10, lineHeight:1.6 }}>
                Ask our AI anything about electronics. Budget-based recommendations, spec comparisons, buying advice for India.
              </div>
              {[
                'Best phone under ₹30,000?',
                'Best gaming laptop for streaming?',
                'Which AC for 200 sq ft room?',
              ].map((q,i) => (
                <a key={i} href={`/ai-assistant`}
                  style={{ display:'flex', alignItems:'center', gap:6, padding:'6px 10px', marginBottom:6, background:'var(--surface2)', border:'1px solid var(--border)', borderRadius:4, fontSize:12, color:'var(--text)', textDecoration:'none', transition:'all 0.1s' }}
                  onMouseEnter={e => { e.currentTarget.style.borderColor='var(--blue)'; e.currentTarget.style.color='var(--blue)'; }}
                  onMouseLeave={e => { e.currentTarget.style.borderColor='var(--border)'; e.currentTarget.style.color='var(--text)'; }}
                >
                  <span style={{ fontSize:13 }}>✦</span> {q}
                </a>
              ))}
              <a href="/ai-assistant" style={{ display:'block', textAlign:'center', marginTop:8, padding:'7px', background:'var(--blue)', color:'#fff', borderRadius:4, fontSize:12, fontWeight:600, textDecoration:'none' }}>
                Open AI Assistant →
              </a>
            </div>
          </div>

          {/* Stats bar */}
          <div style={{ background:'var(--surface)', border:'1px solid var(--border)', borderRadius:5, padding:12, marginBottom:14 }}>
            <div style={{ fontSize:11, color:'var(--text-dim)', textTransform:'uppercase', letterSpacing:'0.05em', marginBottom:8 }}>Live Stats</div>
            {[
              ['Products Tracked','4,200+'],
              ['Sellers Compared','50+'],
              ['Prices Updated','Every 4h'],
              ['AI Powered','GPT-4'],
            ].map(([k,v]) => (
              <div key={k} style={{ display:'flex', justifyContent:'space-between', padding:'5px 0', borderBottom:'1px solid var(--divider)', fontSize:12 }}>
                <span style={{ color:'var(--text-muted)' }}>{k}</span>
                <span style={{ color:'var(--text)', fontWeight:600 }}>{v}</span>
              </div>
            ))}
          </div>

        </div>
      </div>

      {/* Bottom padding */}
      <div style={{ height:24 }} />
    </div>
  );
}
