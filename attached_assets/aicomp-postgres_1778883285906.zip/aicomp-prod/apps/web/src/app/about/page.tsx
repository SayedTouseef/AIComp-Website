import Link from 'next/link';
export const metadata = { title: 'About AIComp — India's AI Electronics Comparison Platform' };
export default function AboutPage() {
  return (
    <div className="max-w-4xl mx-auto px-6 py-16">
      <div className="section-label mb-4">Our Story</div>
      <h1 className="font-display font-extrabold text-5xl tracking-tight mb-6">Built for India's Electronics Buyers</h1>
      <p className="text-text-muted text-lg leading-relaxed mb-8">AIComp was founded in 2024 with one mission: make electronics buying in India transparent, intelligent, and stress-free. We combine real-time price data with AI-powered analysis to give every Indian buyer a fair shot at the best deal.</p>
      <div className="grid md:grid-cols-3 gap-5 mb-12">
        {[['4M+','Products Tracked'],['₹2.3Cr+','Saved by Users'],['50+','Sellers Compared']].map(([val,label])=>(
          <div key={label} className="glass rounded-2xl p-6 text-center"><div className="font-display font-extrabold text-4xl text-cyan mb-1">{val}</div><div className="text-text-muted">{label}</div></div>
        ))}
      </div>
      <h2 className="font-display font-bold text-2xl mb-4">Our Values</h2>
      <div className="space-y-4">
        {[['Transparency','We show prices from every seller, even if they don't partner with us.'],['Intelligence','Our AI doesn't just show data — it interprets it to give clear recommendations.'],['India-First','Every feature is designed for Indian market conditions, pricing, and buying behavior.']].map(([title,desc])=>(
          <div key={title} className="glass rounded-xl p-5"><div className="font-semibold mb-1">{title}</div><div className="text-text-muted text-sm">{desc}</div></div>
        ))}
      </div>
    </div>
  );
}