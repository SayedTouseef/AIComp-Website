import type { Metadata } from 'next';
import Link from 'next/link';
import { Rocket, Calendar, CheckCircle, Clock, HelpCircle } from 'lucide-react';

export const metadata: Metadata = {
  title: 'New Product Launches 2025 — AIComp India',
  description: 'Upcoming and recently launched electronics in India. Confirmed prices, expected dates, and pre-order links.',
};

const UPCOMING = [
  { name: 'Samsung Galaxy Z Fold 7', brand: 'Samsung', category: '📱 Smartphones', expectedDate: 'Jul 2025', price: '~₹1,90,000', status: 'expected', confidence: 90, notes: 'Snapdragon 8 Elite, improved hinge mechanism expected' },
  { name: 'Apple iPhone 17 Pro', brand: 'Apple', category: '📱 Smartphones', expectedDate: 'Sep 2025', price: '~₹1,35,000', status: 'rumoured', confidence: 85, notes: 'A19 Pro chip, thinner camera bar, USB4 support rumoured' },
  { name: 'OnePlus 14', brand: 'OnePlus', category: '📱 Smartphones', expectedDate: 'Q3 2025', price: '~₹62,000', status: 'expected', confidence: 80, notes: 'Hasselblad cameras, 100W charging, Snapdragon 8 Gen 4' },
  { name: 'MacBook Air M5', brand: 'Apple', category: '💻 Laptops', expectedDate: 'Mid 2025', price: '~₹1,20,000', status: 'expected', confidence: 75, notes: 'M5 chip with 40% faster Neural Engine, same design' },
  { name: 'NVIDIA RTX 5080', brand: 'NVIDIA', category: '🖥️ GPUs', expectedDate: 'Q2 2025', price: '~₹1,10,000', status: 'rumoured', confidence: 70, notes: 'Blackwell architecture, 4nm TSMC process' },
  { name: 'Sony Bravia 9 (2025)', brand: 'Sony', category: '📺 TVs', expectedDate: 'Aug 2025', price: '~₹3,50,000', status: 'expected', confidence: 88, notes: '65" XR Processor, Mini LED backlight upgrade' },
];

const RECENT = [
  { name: 'Samsung Galaxy S25 Ultra', brand: 'Samsung', category: '📱 Smartphones', launchDate: 'Jan 22, 2025', price: '₹1,29,999', status: 'available', where: 'Samsung.com, Amazon, Flipkart' },
  { name: 'ASUS ROG Phone 9 Pro', brand: 'ASUS', category: '📱 Smartphones', launchDate: 'Feb 5, 2025', price: '₹84,999', status: 'available', where: 'Flipkart' },
  { name: 'LG OLED G5', brand: 'LG', category: '📺 TVs', launchDate: 'Feb 28, 2025', price: '₹2,49,990', status: 'available', where: 'LG.com, Croma' },
  { name: 'Apple MacBook Air M4', brand: 'Apple', category: '💻 Laptops', launchDate: 'Mar 12, 2025', price: '₹1,09,900', status: 'available', where: 'Apple.com, Amazon' },
  { name: 'Nothing Phone (3)', brand: 'Nothing', category: '📱 Smartphones', launchDate: 'Apr 1, 2025', price: '₹44,999', status: 'available', where: 'Flipkart' },
];

const STATUS_CONFIG: Record<string, { label: string; color: string; icon: any }> = {
  confirmed: { label: 'Confirmed', color: 'text-emerald border-emerald/20 bg-emerald/5', icon: CheckCircle },
  expected: { label: 'Expected', color: 'text-cyan border-cyan/20 bg-cyan/5', icon: Clock },
  rumoured: { label: 'Rumoured', color: 'text-amber border-amber/20 bg-amber/5', icon: HelpCircle },
  available: { label: 'Available Now', color: 'text-emerald border-emerald/20 bg-emerald/5', icon: CheckCircle },
};

export default function LaunchesPage() {
  return (
    <div className="max-w-[1400px] mx-auto px-6 py-8">
      <div className="mb-10">
        <div className="section-label flex items-center gap-2"><Rocket size={12} /> Launch Radar</div>
        <h1 className="font-display font-extrabold text-4xl tracking-tight mb-2">New Launches & Upcoming Products</h1>
        <p className="text-text-muted">Track confirmed launches and upcoming products for India. Updated weekly.</p>
      </div>

      {/* Recently launched */}
      <div className="mb-12">
        <div className="flex items-center gap-3 mb-5">
          <div className="font-display font-bold text-2xl">🎉 Recently Launched</div>
          <div className="live-dot" />
        </div>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
          {RECENT.map((p, i) => (
            <div key={i} className="glass-hover rounded-2xl p-5">
              <div className="flex items-start justify-between mb-3">
                <div>
                  <div className="text-xs text-text-muted mb-1">{p.brand} · {p.category}</div>
                  <div className="font-display font-bold text-lg leading-tight">{p.name}</div>
                </div>
                <span className={`text-xs px-2.5 py-1 rounded-lg border flex-shrink-0 ${STATUS_CONFIG.available.color}`}>
                  Available
                </span>
              </div>
              <div className="flex items-center justify-between mb-3">
                <div className="font-mono font-bold text-emerald text-lg">{p.price}</div>
                <div className="flex items-center gap-1 text-xs text-text-muted">
                  <Calendar size={11} /> {p.launchDate}
                </div>
              </div>
              <div className="text-xs text-text-dim">Buy from: {p.where}</div>
              <Link href={`/search?q=${encodeURIComponent(p.name)}`}
                className="mt-3 w-full btn-ghost text-xs py-2 flex items-center justify-center gap-1">
                Compare Prices →
              </Link>
            </div>
          ))}
        </div>
      </div>

      {/* Upcoming */}
      <div>
        <div className="font-display font-bold text-2xl mb-5">🔭 Upcoming Products</div>
        <div className="glass rounded-2xl overflow-hidden">
          <div className="grid grid-cols-[2fr_1fr_1fr_100px_1fr] px-5 py-3 border-b border-border text-2xs text-text-dim uppercase tracking-wider">
            <div>Product</div>
            <div>Expected Date</div>
            <div>Est. Price</div>
            <div>Confidence</div>
            <div>Notes</div>
          </div>
          <div className="divide-y divide-border">
            {UPCOMING.map((p, i) => {
              const status = STATUS_CONFIG[p.status];
              return (
                <div key={i} className="grid grid-cols-[2fr_1fr_1fr_100px_1fr] gap-4 px-5 py-4 items-start hover:bg-surface-hover transition-colors">
                  <div>
                    <div className="text-xs text-text-muted mb-1">{p.brand} · {p.category}</div>
                    <div className="font-semibold text-sm text-text">{p.name}</div>
                    <span className={`text-xs px-2 py-0.5 rounded-lg border mt-1.5 inline-flex items-center gap-1 ${status.color}`}>
                      <status.icon size={9} /> {status.label}
                    </span>
                  </div>
                  <div className="text-sm text-text-muted">{p.expectedDate}</div>
                  <div className="font-mono text-sm text-amber">{p.price}</div>
                  <div className="flex items-center gap-2">
                    <div className="flex-1 h-1.5 bg-border rounded-full overflow-hidden">
                      <div className="h-full rounded-full bg-cyan" style={{ width: `${p.confidence}%` }} />
                    </div>
                    <span className="text-xs font-mono text-cyan">{p.confidence}%</span>
                  </div>
                  <div className="text-xs text-text-muted leading-relaxed">{p.notes}</div>
                </div>
              );
            })}
          </div>
        </div>
        <div className="text-xs text-text-dim mt-3">
          * Confidence % based on official teasers, regulatory filings, and supply chain reports. Not guaranteed.
        </div>
      </div>
    </div>
  );
}
