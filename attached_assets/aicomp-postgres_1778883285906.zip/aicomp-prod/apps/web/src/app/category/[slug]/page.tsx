'use client';

import { useState, useEffect } from 'react';
import { useParams } from 'next/navigation';
import Link from 'next/link';
import { AdLeaderboard } from '@/components/ads/AdRail';
import { Grid3X3, List, ChevronDown } from 'lucide-react';

const API = process.env.NEXT_PUBLIC_API_URL ?? 'http://localhost:4000';

const CAT_NAMES: Record<string,string> = {
  smartphones:'Smartphones', laptops:'Laptops', tvs:'TVs',
  'air-conditioners':'Air Conditioners', 'gaming-pcs':'Gaming PCs',
  cameras:'Cameras', monitors:'Monitors', smartwatches:'Smartwatches',
  headphones:'Headphones', tablets:'Tablets', gpus:'Graphics Cards', cpus:'Processors',
};

const SORT_OPTS = [
  { value:'popular',   label:'Most Popular' },
  { value:'newest',    label:'Newest First' },
  { value:'price_asc', label:'Price: Low to High' },
  { value:'price_desc',label:'Price: High to Low' },
  { value:'rating',    label:'Highest Rated' },
];

function formatPrice(p: number) { return `₹${(p/100).toLocaleString('en-IN')}`; }
function scoreColor(s: number) { return s>=85?'var(--green)':s>=70?'var(--orange)':'var(--red)'; }

function ProductCard({ p, view }: { p: any; view: 'grid'|'list' }) {
  const price = p.prices?.[0] ?? (p.min_price ? { price: p.min_price } : null);

  if (view === 'list') {
    return (
      <Link href={`/product/${p.slug}`}
        style={{ display:'flex', gap:12, padding:'10px 12px', borderBottom:'1px solid var(--divider)', textDecoration:'none' }}
        onMouseEnter={e => (e.currentTarget.style.background = 'var(--surface2)')}
        onMouseLeave={e => (e.currentTarget.style.background = '')}
      >
        <div style={{ width:72, height:72, background:'var(--surface)', border:'1px solid var(--border)', borderRadius:4, display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0, overflow:'hidden' }}>
          {p.thumbnail ? <img src={p.thumbnail} alt={p.name} style={{ width:'100%', height:'100%', objectFit:'contain', padding:4 }} /> : <span style={{ fontSize:32 }}>📦</span>}
        </div>
        <div style={{ flex:1, minWidth:0 }}>
          <div style={{ fontSize:11, color:'var(--text-muted)', marginBottom:2 }}>{p.brand_name}</div>
          <div style={{ fontSize:14, fontWeight:600, color:'var(--text)', lineHeight:1.3, marginBottom:4 }}>{p.name}</div>
          <div style={{ display:'flex', alignItems:'center', gap:10 }}>
            {price && <span style={{ fontSize:14, fontWeight:700, color:'var(--green)' }}>{formatPrice(price.price)}</span>}
            {price?.mrp && <span style={{ fontSize:11, color:'var(--text-dim)', textDecoration:'line-through' }}>{formatPrice(price.mrp)}</span>}
            {price?.discount && <span className="discount-badge">{price.discount}% off</span>}
          </div>
        </div>
        {p.overall_score && (
          <div style={{ display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', width:50, flexShrink:0 }}>
            <span style={{ fontSize:16, fontWeight:700, color:scoreColor(p.overall_score) }}>{p.overall_score}</span>
            <span style={{ fontSize:9, color:'var(--text-dim)', textTransform:'uppercase' }}>AI Score</span>
          </div>
        )}
      </Link>
    );
  }

  return (
    <Link href={`/product/${p.slug}`}
      style={{ display:'flex', flexDirection:'column', background:'var(--card)', border:'1px solid var(--border)', borderRadius:5, overflow:'hidden', textDecoration:'none', transition:'border-color 0.12s' }}
      onMouseEnter={e => (e.currentTarget.style.borderColor = 'var(--blue)')}
      onMouseLeave={e => (e.currentTarget.style.borderColor = 'var(--border)')}
    >
      <div style={{ aspectRatio:'1', background:'var(--surface)', display:'flex', alignItems:'center', justifyContent:'center', padding:12 }}>
        {p.thumbnail ? <img src={p.thumbnail} alt={p.name} style={{ width:'100%', height:'100%', objectFit:'contain' }} /> : <span style={{ fontSize:40 }}>📦</span>}
      </div>
      <div style={{ padding:'8px 10px', flex:1 }}>
        <div style={{ fontSize:10, color:'var(--text-muted)', marginBottom:2 }}>{p.brand_name}</div>
        <div style={{ fontSize:12, fontWeight:600, color:'var(--text)', lineHeight:1.3, marginBottom:6, overflow:'hidden', display:'-webkit-box', WebkitLineClamp:2, WebkitBoxOrient:'vertical' }}>{p.name}</div>
        <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between' }}>
          {price ? <span style={{ fontSize:13, fontWeight:700, color:'var(--green)' }}>{formatPrice(price.price)}</span> : <span style={{ fontSize:11, color:'var(--text-dim)' }}>TBA</span>}
          {p.overall_score && <span style={{ fontSize:10, fontWeight:700, padding:'1px 5px', borderRadius:3, background:`${scoreColor(p.overall_score)}15`, color:scoreColor(p.overall_score) }}>{p.overall_score}</span>}
        </div>
      </div>
    </Link>
  );
}

export default function CategoryPage() {
  const { slug } = useParams() as { slug: string };
  const name = CAT_NAMES[slug] ?? slug;
  const [products, setProducts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [sort, setSort] = useState('popular');
  const [view, setView] = useState<'grid'|'list'>('grid');
  const [page, setPage] = useState(1);
  const [total, setTotal] = useState(0);

  useEffect(() => {
    setLoading(true);
    fetch(`${API}/api/v1/products?category=${slug}&sort=${sort}&page=${page}&limit=24`)
      .then(r => r.json())
      .then(d => { setProducts(d.products ?? []); setTotal(d.pagination?.total ?? 0); })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, [slug, sort, page]);

  return (
    <div style={{ padding:'12px 16px' }}>
      {/* Breadcrumb */}
      <div className="breadcrumb" style={{ marginBottom:12 }}>
        <Link href="/">Home</Link>
        <span className="breadcrumb-sep">›</span>
        <Link href="/categories">Categories</Link>
        <span className="breadcrumb-sep">›</span>
        <span style={{ color:'var(--text)' }}>{name}</span>
      </div>

      <AdLeaderboard />

      {/* Page header */}
      <div style={{ marginBottom:12 }}>
        <h1 style={{ fontFamily:'"Roboto Condensed",sans-serif', fontWeight:700, fontSize:22, color:'var(--text)' }}>
          {name}
        </h1>
        <div style={{ fontSize:12, color:'var(--text-muted)', marginTop:2 }}>
          {loading ? 'Loading...' : `${total.toLocaleString()} products found`} · Live prices · AI comparison
        </div>
      </div>

      {/* Toolbar */}
      <div style={{ display:'flex', alignItems:'center', gap:8, marginBottom:12, padding:'8px 12px', background:'var(--surface)', border:'1px solid var(--border)', borderRadius:5 }}>
        <span style={{ fontSize:12, color:'var(--text-muted)', flexShrink:0 }}>Sort by:</span>
        <div style={{ position:'relative' }}>
          <select value={sort} onChange={e => { setSort(e.target.value); setPage(1); }}
            style={{ background:'var(--card)', border:'1px solid var(--border)', borderRadius:4, padding:'4px 24px 4px 8px', fontSize:12, color:'var(--text)', cursor:'pointer', appearance:'none', paddingRight:24 }}>
            {SORT_OPTS.map(o => <option key={o.value} value={o.value} style={{ background:'var(--card)' }}>{o.label}</option>)}
          </select>
          <ChevronDown size={12} style={{ position:'absolute', right:6, top:'50%', transform:'translateY(-50%)', color:'var(--text-muted)', pointerEvents:'none' }} />
        </div>

        <div style={{ marginLeft:'auto', display:'flex', gap:4 }}>
          <button onClick={() => setView('grid')}
            style={{ padding:'4px 8px', background:view==='grid'?'var(--blue)':'transparent', color:view==='grid'?'#fff':'var(--text-muted)', border:`1px solid ${view==='grid'?'var(--blue)':'var(--border)'}`, borderRadius:4, cursor:'pointer', display:'flex', alignItems:'center' }}>
            <Grid3X3 size={13} />
          </button>
          <button onClick={() => setView('list')}
            style={{ padding:'4px 8px', background:view==='list'?'var(--blue)':'transparent', color:view==='list'?'#fff':'var(--text-muted)', border:`1px solid ${view==='list'?'var(--blue)':'var(--border)'}`, borderRadius:4, cursor:'pointer', display:'flex', alignItems:'center' }}>
            <List size={13} />
          </button>
        </div>
      </div>

      {/* Product listing */}
      {loading ? (
        <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill, minmax(160px,1fr))', gap:10 }}>
          {Array.from({length:24}).map((_, i) => (
            <div key={i} style={{ aspectRatio:'4/5', borderRadius:5, overflow:'hidden' }}>
              <div className="skeleton" style={{ width:'100%', height:'100%' }} />
            </div>
          ))}
        </div>
      ) : products.length > 0 ? (
        view === 'grid' ? (
          <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill, minmax(160px,1fr))', gap:10 }}>
            {products.map(p => <ProductCard key={p.id} p={p} view="grid" />)}
          </div>
        ) : (
          <div style={{ background:'var(--card)', border:'1px solid var(--border)', borderRadius:5, overflow:'hidden' }}>
            {products.map(p => <ProductCard key={p.id} p={p} view="list" />)}
          </div>
        )
      ) : (
        <div style={{ padding:48, textAlign:'center', background:'var(--card)', border:'1px solid var(--border)', borderRadius:5 }}>
          <div style={{ fontSize:40, marginBottom:12 }}>🔍</div>
          <div style={{ fontSize:15, fontWeight:600, color:'var(--text)', marginBottom:6 }}>No products found</div>
          <div style={{ fontSize:13, color:'var(--text-muted)' }}>Try adjusting your filters</div>
        </div>
      )}

      {/* Pagination */}
      {!loading && total > 24 && (
        <div style={{ display:'flex', justifyContent:'center', gap:6, marginTop:20 }}>
          <button disabled={page===1} onClick={() => setPage(p=>p-1)}
            style={{ padding:'5px 14px', background:'transparent', border:'1px solid var(--border)', borderRadius:4, fontSize:12, cursor:'pointer', color:'var(--text-muted)', opacity:page===1?0.4:1 }}>
            ← Prev
          </button>
          <span style={{ display:'flex', alignItems:'center', fontSize:12, color:'var(--text-muted)', padding:'0 8px' }}>
            Page {page} of {Math.ceil(total/24)}
          </span>
          <button disabled={page>=Math.ceil(total/24)} onClick={() => setPage(p=>p+1)}
            style={{ padding:'5px 14px', background:'transparent', border:'1px solid var(--border)', borderRadius:4, fontSize:12, cursor:'pointer', color:'var(--text-muted)', opacity:page>=Math.ceil(total/24)?0.4:1 }}>
            Next →
          </button>
        </div>
      )}

      <div style={{ height:24 }} />
    </div>
  );
}
