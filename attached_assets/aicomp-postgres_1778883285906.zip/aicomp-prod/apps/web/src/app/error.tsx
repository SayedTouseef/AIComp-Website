"use client";
import { useEffect } from 'react';
export default function Error({ error, reset }: { error: Error; reset: () => void }) {
  useEffect(() => { console.error(error); }, [error]);
  return (
    <div className="min-h-screen flex flex-col items-center justify-center text-center px-6">
      <div className="text-6xl mb-6">⚠️</div>
      <h2 className="font-display font-bold text-3xl mb-4" style={{ color:'var(--text)' }}>Something went wrong</h2>
      <p className="mb-8" style={{ color:'var(--text-muted)' }}>An unexpected error occurred.</p>
      <button onClick={reset} className="btn-ai px-6 py-3">Try again</button>
    </div>
  );
}
