'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import Link from 'next/link';
import { Gamepad2, Zap, Trophy, Monitor, Cpu, ChevronRight, TrendingUp } from 'lucide-react';
import { cn, formatPrice } from '@/lib/utils';

const GAMES = [
  { name: 'Cyberpunk 2077', genre: 'RPG', img: '🎮', resolutions: ['1080p', '1440p', '4K'] },
  { name: 'GTA VI', genre: 'Action', img: '🏙️', resolutions: ['1080p', '1440p', '4K'] },
  { name: 'Black Myth: Wukong', genre: 'Action RPG', img: '🐒', resolutions: ['1080p', '1440p', '4K'] },
  { name: 'Valorant', genre: 'FPS', img: '🎯', resolutions: ['1080p', '1440p'] },
  { name: 'CS2', genre: 'FPS', img: '💣', resolutions: ['1080p', '1440p'] },
  { name: 'BGMI', genre: 'Battle Royale', img: '🪖', resolutions: ['HD', '1080p'] },
  { name: 'Alan Wake 2', genre: 'Horror', img: '👻', resolutions: ['1080p', '1440p', '4K'] },
  { name: 'Elden Ring', genre: 'Souls-like', img: '⚔️', resolutions: ['1080p', '1440p', '4K'] },
];

const GPU_BENCHMARK_DATA = [
  { name: 'RTX 4090', price: 17000000, tier: 'Enthusiast', scores: { cyber1080: 165, cyber1440: 128, cyber4k: 84, valorant: 520, gta1080: 120 }, color: '#63b3ed', badge: '👑 King' },
  { name: 'RTX 4080 Super', price: 11000000, tier: 'High-End', scores: { cyber1080: 145, cyber1440: 110, cyber4k: 72, valorant: 460, gta1080: 108 }, color: '#9f7aea', badge: '🚀 Top' },
  { name: 'RTX 4070 Ti Super', price: 8500000, tier: 'High-End', scores: { cyber1080: 128, cyber1440: 98, cyber4k: 61, valorant: 400, gta1080: 95 }, color: '#48bb78', badge: '⚡ Fast' },
  { name: 'RTX 4070 Super', price: 6500000, tier: 'Mid-High', scores: { cyber1080: 115, cyber1440: 88, cyber4k: 54, valorant: 360, gta1080: 84 }, color: '#48bb78', badge: '✨ Value' },
  { name: 'RTX 4070', price: 5500000, tier: 'Mid-Range', scores: { cyber1080: 102, cyber1440: 78, cyber4k: 47, valorant: 320, gta1080: 76 }, color: '#f6ad55', badge: '💰 Sweet Spot' },
  { name: 'RTX 4060 Ti', price: 4200000, tier: 'Mid-Range', scores: { cyber1080: 88, cyber1440: 65, cyber4k: 38, valorant: 280, gta1080: 65 }, color: '#f6ad55', badge: '' },
  { name: 'RX 7900 XTX', price: 9800000, tier: 'High-End', scores: { cyber1080: 138, cyber1440: 105, cyber4k: 68, valorant: 380, gta1080: 100 }, color: '#fc8181', badge: '🔥 AMD Best' },
  { name: 'RX 7800 XT', price: 4800000, tier: 'Mid-Range', scores: { cyber1080: 95, cyber1440: 72, cyber4k: 44, valorant: 290, gta1080: 70 }, color: '#fc8181', badge: '' },
];

const GAMING_LAPTOPS = [
  { name: 'ASUS ROG Zephyrus G16', gpu: 'RTX 4090', display: '240Hz QHD', price: 34000000, fps1080: 145, badge: '🏆 Best Overall' },
  { name: 'Razer Blade 16', gpu: 'RTX 4090', display: '240Hz QHD', price: 38000000, fps1080: 142, badge: '💎 Premium' },
  { name: 'MSI Titan GT77', gpu: 'RTX 4090', display: '360Hz FHD', price: 45000000, fps1080: 148, badge: '👑 Flagship' },
  { name: 'Lenovo Legion Pro 7', gpu: 'RTX 4080', display: '240Hz QHD', price: 22000000, fps1080: 128, badge: '⚡ Value King' },
  { name: 'ASUS ROG Strix G16', gpu: 'RTX 4070', display: '165Hz FHD', price: 16000000, fps1080: 108, badge: '💰 Budget Pick' },
  { name: 'Acer Predator Helios 18', gpu: 'RTX 4080', display: '250Hz QHD', price: 24000000, fps1080: 130, badge: '🎮 Gaming Beast' },
];

const BENCHMARK_COLS = [
  { key: 'cyber1080', label: 'Cyberpunk 1080p' },
  { key: 'cyber1440', label: 'Cyberpunk 1440p' },
  { key: 'cyber4k', label: 'Cyberpunk 4K' },
  { key: 'valorant', label: 'Valorant 1080p' },
  { key: 'gta1080', label: 'GTA VI 1080p' },
];

function FpsBar({ fps, max }: { fps: number; max: number }) {
  const pct = Math.min(100, (fps / max) * 100);
  const color = fps >= 144 ? '#48bb78' : fps >= 60 ? '#f6ad55' : '#fc8181';
  return (
    <div className="flex items-center gap-2">
      <div className="flex-1 h-1.5 bg-white/[0.06] rounded-full overflow-hidden">
        <motion.div className="h-full rounded-full" style={{ background: color }}
          initial={{ width: 0 }} whileInView={{ width: `${pct}%` }} viewport={{ once: true }}
          transition={{ duration: 0.8, ease: 'easeOut' }} />
      </div>
      <span className="font-mono text-xs w-8 text-right" style={{ color }}>{fps}</span>
    </div>
  );
}

export default function GamingPage() {
  const [activeTab, setActiveTab] = useState<'gpus' | 'laptops' | 'games'>('gpus');
  const [selectedGame, setSelectedGame] = useState('cyber1080');
  const [tier, setTier] = useState('All');

  const tiers = ['All', 'Enthusiast', 'High-End', 'Mid-High', 'Mid-Range'];
  const filtered = tier === 'All' ? GPU_BENCHMARK_DATA : GPU_BENCHMARK_DATA.filter(g => g.tier === tier);
  const maxScore = Math.max(...filtered.map(g => g.scores[selectedGame as keyof typeof g.scores]));

  return (
    <div className="max-w-[1400px] mx-auto px-6 py-8">
      {/* Hero */}
      <div className="relative rounded-3xl overflow-hidden bg-gradient-to-br from-rose/10 via-bg to-violet/10 border border-rose/20 p-10 mb-10">
        <div className="absolute inset-0 grid-bg opacity-30" />
        <div className="relative z-10">
          <div className="section-label flex items-center gap-2"><Gamepad2 size={12} /> Gaming Zone</div>
          <h1 className="font-display font-extrabold text-5xl tracking-tight mb-4">
            GPU & Gaming Laptop<br /><span className="gradient-text">Benchmark Database</span>
          </h1>
          <p className="text-text-muted text-lg max-w-xl mb-8">
            Tested FPS data for 50+ GPUs and gaming laptops across 200+ games. Find the best GPU for your budget.
          </p>
          <div className="flex gap-4">
            <div className="glass rounded-2xl px-5 py-3 text-center">
              <div className="font-display font-extrabold text-2xl text-cyan">50+</div>
              <div className="text-xs text-text-muted">GPUs Tested</div>
            </div>
            <div className="glass rounded-2xl px-5 py-3 text-center">
              <div className="font-display font-extrabold text-2xl text-violet">200+</div>
              <div className="text-xs text-text-muted">Games Benchmarked</div>
            </div>
            <div className="glass rounded-2xl px-5 py-3 text-center">
              <div className="font-display font-extrabold text-2xl text-emerald">Weekly</div>
              <div className="text-xs text-text-muted">Data Updates</div>
            </div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 border-b border-border mb-8">
        {[
          { key: 'gpus', label: '🖥️ Desktop GPUs' },
          { key: 'laptops', label: '💻 Gaming Laptops' },
          { key: 'games', label: '🎮 Game Library' },
        ].map(t => (
          <button key={t.key} onClick={() => setActiveTab(t.key as any)}
            className={cn('px-5 py-3 text-sm font-medium border-b-2 -mb-px transition-all',
              activeTab === t.key ? 'border-rose text-rose' : 'border-transparent text-text-muted hover:text-text')}>
            {t.label}
          </button>
        ))}
      </div>

      {/* GPU Benchmarks */}
      {activeTab === 'gpus' && (
        <div>
          <div className="flex flex-wrap items-center gap-4 mb-6">
            {/* Tier filter */}
            <div className="flex gap-2 flex-wrap">
              {tiers.map(t => (
                <button key={t} onClick={() => setTier(t)}
                  className={cn('px-3 py-1.5 rounded-xl text-xs font-medium transition-all',
                    tier === t ? 'bg-rose/20 text-rose border border-rose/30' : 'btn-ghost')}>
                  {t}
                </button>
              ))}
            </div>
            {/* Game selector */}
            <div className="ml-auto flex items-center gap-2">
              <span className="text-xs text-text-muted">Game:</span>
              <select value={selectedGame} onChange={e => setSelectedGame(e.target.value)}
                className="btn-ghost text-xs bg-transparent cursor-pointer">
                {BENCHMARK_COLS.map(c => (
                  <option key={c.key} value={c.key} className="bg-bg">{c.label}</option>
                ))}
              </select>
            </div>
          </div>

          <div className="glass rounded-2xl overflow-hidden">
            <div className="grid grid-cols-[2fr_1fr_1fr_2fr] gap-4 px-5 py-3 border-b border-border text-2xs text-text-dim uppercase tracking-wider">
              <div>GPU</div>
              <div>Tier</div>
              <div>Price</div>
              <div>{BENCHMARK_COLS.find(c => c.key === selectedGame)?.label} (FPS)</div>
            </div>
            <div className="divide-y divide-border">
              {filtered
                .sort((a, b) => b.scores[selectedGame as keyof typeof b.scores] - a.scores[selectedGame as keyof typeof a.scores])
                .map((gpu, i) => (
                  <motion.div key={gpu.name} initial={{ opacity: 0, x: -8 }} animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: i * 0.04 }}
                    className="grid grid-cols-[2fr_1fr_1fr_2fr] gap-4 px-5 py-4 items-center hover:bg-surface-hover transition-colors">
                    <div className="flex items-center gap-3">
                      <div className="font-mono text-xs text-text-dim w-5 text-center">#{i + 1}</div>
                      <div>
                        <div className="font-semibold text-sm text-text">{gpu.name}</div>
                        {gpu.badge && <div className="text-2xs text-text-muted mt-0.5">{gpu.badge}</div>}
                      </div>
                    </div>
                    <div>
                      <span className={cn('text-xs px-2 py-0.5 rounded-lg border',
                        gpu.tier === 'Enthusiast' ? 'text-violet border-violet/30 bg-violet/10' :
                        gpu.tier === 'High-End' ? 'text-cyan border-cyan/30 bg-cyan/10' :
                        'text-amber border-amber/30 bg-amber/10'
                      )}>{gpu.tier}</span>
                    </div>
                    <div className="font-mono text-sm text-emerald">{formatPrice(gpu.price)}</div>
                    <FpsBar fps={gpu.scores[selectedGame as keyof typeof gpu.scores]} max={maxScore} />
                  </motion.div>
                ))}
            </div>
          </div>

          <div className="grid md:grid-cols-3 gap-4 mt-8">
            <div className="glass rounded-2xl p-5 border-emerald/20">
              <div className="text-xs text-emerald mb-2 font-mono uppercase">Best Value</div>
              <div className="font-display font-bold text-xl mb-1">RTX 4070 Super</div>
              <div className="text-text-muted text-sm">1440p gaming at ~88 FPS avg. Best ₹/FPS ratio in 2025.</div>
              <Link href="/product/rtx-4070-super" className="mt-3 text-xs text-cyan flex items-center gap-1">
                View prices <ChevronRight size={12} />
              </Link>
            </div>
            <div className="glass rounded-2xl p-5 border-violet/20">
              <div className="text-xs text-violet mb-2 font-mono uppercase">Best 4K GPU</div>
              <div className="font-display font-bold text-xl mb-1">RTX 4090</div>
              <div className="text-text-muted text-sm">84 FPS in Cyberpunk 4K with ray tracing. Overkill for 1080p.</div>
              <Link href="/product/rtx-4090" className="mt-3 text-xs text-cyan flex items-center gap-1">
                View prices <ChevronRight size={12} />
              </Link>
            </div>
            <div className="glass rounded-2xl p-5 border-rose/20">
              <div className="text-xs text-rose mb-2 font-mono uppercase">Best AMD GPU</div>
              <div className="font-display font-bold text-xl mb-1">RX 7900 XTX</div>
              <div className="text-text-muted text-sm">AMD's flagship — beats RTX 4080 in rasterization at lower price.</div>
              <Link href="/product/rx-7900-xtx" className="mt-3 text-xs text-cyan flex items-center gap-1">
                View prices <ChevronRight size={12} />
              </Link>
            </div>
          </div>
        </div>
      )}

      {/* Gaming Laptops */}
      {activeTab === 'laptops' && (
        <div>
          <div className="glass rounded-2xl overflow-hidden mb-6">
            <div className="grid grid-cols-[2fr_1fr_1fr_1fr_80px] px-5 py-3 border-b border-border text-2xs text-text-dim uppercase tracking-wider">
              <div>Laptop</div><div>GPU</div><div>Display</div><div>1080p FPS (avg)</div><div>Price</div>
            </div>
            <div className="divide-y divide-border">
              {GAMING_LAPTOPS.sort((a, b) => b.fps1080 - a.fps1080).map((l, i) => (
                <motion.div key={l.name} initial={{ opacity: 0, x: -8 }} animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.05 }}
                  className="grid grid-cols-[2fr_1fr_1fr_1fr_80px] px-5 py-4 items-center hover:bg-surface-hover transition-colors">
                  <div>
                    <div className="font-semibold text-sm text-text">{l.name}</div>
                    {l.badge && <div className="text-2xs text-text-muted mt-0.5">{l.badge}</div>}
                  </div>
                  <div className="text-xs text-cyan font-mono">{l.gpu}</div>
                  <div className="text-xs text-text-muted">{l.display}</div>
                  <div className="flex items-center gap-2">
                    <div className="flex-1 h-1.5 bg-border rounded-full overflow-hidden max-w-24">
                      <div className="h-full rounded-full bg-emerald" style={{ width: `${(l.fps1080 / 150) * 100}%` }} />
                    </div>
                    <span className="font-mono text-xs text-emerald">{l.fps1080}</span>
                  </div>
                  <div className="font-mono text-sm text-text">{formatPrice(l.price)}</div>
                </motion.div>
              ))}
            </div>
          </div>

          <div className="glass rounded-2xl p-6 border-amber/20">
            <div className="flex items-center gap-3 mb-4">
              <Trophy size={20} className="text-amber" />
              <div className="font-display font-bold text-xl">AIComp Gaming Laptop Picks 2025</div>
            </div>
            <div className="grid md:grid-cols-3 gap-4">
              {[
                { tier: 'Best Under ₹1L', name: 'ASUS ROG Strix G16', note: 'RTX 4070 · 165Hz · Best 1080p gaming' },
                { tier: 'Best Under ₹2L', name: 'Lenovo Legion Pro 7', note: 'RTX 4080 · 240Hz · 1440p champion' },
                { tier: 'Best Overall', name: 'ASUS ROG Zephyrus G16', note: 'RTX 4090 · 240Hz · Thin & powerful' },
              ].map((pick, i) => (
                <div key={i} className="bg-surface rounded-xl p-4">
                  <div className="text-xs text-amber font-mono uppercase mb-1">{pick.tier}</div>
                  <div className="font-semibold text-sm text-text mb-1">{pick.name}</div>
                  <div className="text-xs text-text-muted">{pick.note}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Game Library */}
      {activeTab === 'games' && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {GAMES.map((game, i) => (
            <motion.div key={i} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.06 }}>
              <div className="glass-hover rounded-2xl p-5 text-center group cursor-pointer">
                <div className="text-4xl mb-3 group-hover:scale-110 transition-transform">{game.img}</div>
                <div className="font-semibold text-sm text-text mb-1">{game.name}</div>
                <div className="text-xs text-text-muted mb-3">{game.genre}</div>
                <div className="flex flex-wrap gap-1 justify-center">
                  {game.resolutions.map(r => (
                    <span key={r} className="badge-cyan text-2xs">{r}</span>
                  ))}
                </div>
              </div>
            </motion.div>
          ))}
          <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: GAMES.length * 0.06 }}>
            <div className="glass rounded-2xl p-5 text-center border-dashed flex flex-col items-center justify-center h-full min-h-[160px]">
              <div className="text-3xl mb-2">➕</div>
              <div className="text-sm text-text-muted">200+ more games</div>
              <div className="text-xs text-text-dim">in our database</div>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
}
