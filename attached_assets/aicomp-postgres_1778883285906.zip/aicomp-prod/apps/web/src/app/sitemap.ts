import { MetadataRoute } from 'next';
const BASE = 'https://aicomp.in';
export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const statics = ['','/products','/compare','/deals','/gaming','/pc-builder','/ai-assistant','/trending','/new-launches','/top-rated','/guides','/about','/contact','/privacy','/terms'].map(path => ({
    url: `${BASE}${path}`, lastModified: new Date(),
    changeFrequency: (path===''?'daily':'weekly') as 'daily'|'weekly', priority: path===''?1:0.8,
  }));
  const cats = ['smartphones','laptops','tvs','air-conditioners','gaming-pcs','cameras','monitors','smartwatches','headphones','tablets'].map(slug => ({
    url: `${BASE}/category/${slug}`, lastModified: new Date(), changeFrequency:'daily' as 'daily', priority: 0.9,
  }));
  return [...statics, ...cats];
}
