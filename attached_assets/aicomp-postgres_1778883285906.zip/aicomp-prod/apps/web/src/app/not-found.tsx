import Link from 'next/link';
export default function NotFound() {
  return (
    <div className="min-h-[60vh] flex flex-col items-center justify-center text-center px-6">
      <div className="text-8xl mb-6">🔍</div>
      <h1 className="font-display font-extrabold text-5xl mb-4" style={{ color:'var(--text)' }}>404</h1>
      <p className="text-xl mb-2 font-semibold" style={{ color:'var(--text)' }}>Page not found</p>
      <p className="mb-10" style={{ color:'var(--text-muted)' }}>The page you are looking for does not exist.</p>
      <div className="flex gap-4">
        <Link href="/" className="btn-ai px-6 py-3">Go Home</Link>
        <Link href="/search" className="btn-ghost px-6 py-3">Search Products</Link>
      </div>
    </div>
  );
}
