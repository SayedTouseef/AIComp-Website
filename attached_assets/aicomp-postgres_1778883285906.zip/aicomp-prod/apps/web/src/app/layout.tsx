import type { Metadata, Viewport } from 'next';
import { Noto_Sans, Roboto_Condensed } from 'next/font/google';
import { ThemeProvider } from 'next-themes';
import '../styles/globals.css';
import { Providers } from '@/components/layout/Providers';
import { SiteHeader } from '@/components/layout/SiteHeader';
import { SiteSubnav } from '@/components/layout/SiteSubnav';
import { SiteFooter } from '@/components/layout/SiteFooter';
import { AdRail } from '@/components/ads/AdRail';
import { Toaster } from 'react-hot-toast';

const notoSans = Noto_Sans({
  subsets: ['latin'],
  weight: ['400', '500', '600', '700'],
  display: 'swap',
  variable: '--font-body',
});
const robotoCond = Roboto_Condensed({
  subsets: ['latin'],
  weight: ['400', '600', '700'],
  display: 'swap',
  variable: '--font-condensed',
});

export const viewport: Viewport = {
  themeColor: [
    { media: '(prefers-color-scheme: dark)',  color: '#1a1d27' },
    { media: '(prefers-color-scheme: light)', color: '#1a6bc7' },
  ],
};

export const metadata: Metadata = {
  metadataBase: new URL('https://aicomp.in'),
  title: { default: 'AIComp — Electronics Comparison India', template: '%s - AIComp' },
  description: 'Compare 4,200+ smartphones, laptops, TVs and more. Live prices from Amazon, Flipkart & Croma. AI-powered specs comparison and buying recommendations.',
  keywords: ['electronics comparison India', 'price comparison', 'smartphone comparison', 'laptop specs'],
  openGraph: {
    type: 'website', locale: 'en_IN', siteName: 'AIComp',
    images: [{ url: '/og-image.png', width: 1200, height: 630 }],
  },
  twitter: { card: 'summary_large_image', site: '@aicomp_in' },
  robots: { index: true, follow: true },
  manifest: '/manifest.json',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
      </head>
      <body
        style={{ fontFamily: "'Noto Sans', system-ui, sans-serif" }}
        suppressHydrationWarning
      >
        <ThemeProvider
          attribute="class"
          defaultTheme="dark"
          enableSystem
          disableTransitionOnChange={false}
          storageKey="aicomp-theme"
        >
          <Providers>
            {/* GSMArena-style 3-column grid layout */}
            <div className="site-wrapper">

              {/* Full-width header */}
              <SiteHeader />

              {/* Full-width category subnav */}
              <SiteSubnav />

              {/* Left ad rail */}
              <aside className="ad-rail-left">
                <div className="sticky-ad">
                  <AdRail side="left" />
                </div>
              </aside>

              {/* Center content */}
              <main className="site-content">
                {children}
              </main>

              {/* Right ad rail */}
              <aside className="ad-rail-right">
                <div className="sticky-ad">
                  <AdRail side="right" />
                </div>
              </aside>

              {/* Full-width footer */}
              <SiteFooter />

            </div>

            <Toaster
              position="bottom-right"
              toastOptions={{
                style: {
                  background: 'var(--surface)',
                  border: '1px solid var(--border)',
                  color: 'var(--text)',
                  borderRadius: '6px',
                  fontSize: '13px',
                },
              }}
            />
          </Providers>
        </ThemeProvider>
      </body>
    </html>
  );
}
