'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import Link from 'next/link';
import { Timer, Zap, TrendingDown, Bell, ExternalLink, Filter } from 'lucide-react';
import { cn, formatPrice } from '@/lib/utils';
import { useDeals, useFlashDeals } from '@/hooks/useApi';

function Countdown({ endTime }: { endTime: number }) {
  const [timeLeft, setTimeLeft] = useState(endTime);
  useEffect(() => {
    const t = setInterval(() => setTimeLeft(p => Math.max(0, p - 1)), 1000);
    return () => clearInterval(t);
  }, []);
  const h = Math.floor(timeLeft / 3600);
  const m = Math.floor((timeLeft % 3600) / 60);
  const s = timeLeft % 60;
  return (
    <div className="flex items-center gap-1 font-mono text-rose">
      <Timer size={12} />
      <span className="text-xs">{String(h).padStart(2,'0')}:{String(m).padStart(2,'0')}:{String(s).padStart(2,'0')}</span>
    </div>
  );
}

const CATEGORIES = ['All', 'Smartphones', 'Laptops', 'TVs', 'Air Conditioners', 'Audio', 'Wearables'];

export default function DealsPage() {
  const [activeCategory, setActiveCategory] = useState('All');
  const [sortBy, setSortBy] = useState('discount');
  const { data: dealsData, isLoading } = useDeals();
  const { data: flashData } = useFlashDeals();

  const deals = dealsData?.products || [];
  const flashDeals = flashData?.deals || [];

  return (
    <div className="max-w-[1400px] mx-auto px-6 py-8">
      {/* Header */}
      <div className="mb-10">
        <div className="section-label flex items-center gap-2"><Zap size={12} /> Live Deals</div>
        <h1 className="font-display font-extrabold text-4xl tracking-tight mb-2">Today's Best Deals</h1>
        <p className="text-text-muted">Updated every 30 minutes. Set alerts to never miss a drop.</p>
      </div>

      {/* Flash deals */}
      {flashDeals.length > 0 && (
        <div className="mb-12">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-2">
                <div className="live-dot" />
                <span className="font-display font-bold text-xl">⚡ Flash Deals</span>
              </div>
              <div className="badge-rose">Limited Time</div>
            </div>
            <Countdown endTime={14400} />
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {flashDeals.slice(0, 4).map((deal: any, i: number) => {
              const price = deal.prices?.[0];
              return (
                <motion.div key={i} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.08 }}>
                  <Link href={`/product/${deal.slug}`} className="glass rounded-2xl overflow-hidden hover:border-rose/30 transition-all block group">
                    <div className="aspect-square bg-surface flex items-center justify-center p-4">
                      {deal.thumbnail
                        ? <img src={deal.thumbnail} alt={deal.name} className="w-full h-full object-contain group-hover:scale-105 transition-transform" />
                        : <span className="text-4xl">{deal.category?.emoji}</span>
                      }
                    </div>
                    <div className="p-4">
                      <div className="text-xs text-text-muted mb-1">{deal.brand?.name}</div>
                      <div className="text-sm font-semibold text-text line-clamp-2 mb-2">{deal.name}</div>
                      {price && (
                        <>
                          <div className="font-mono font-bold text-rose text-lg">{formatPrice(price.price)}</div>
                          {price.mrp && <div className="flex items-center gap-2 mt-0.5">
                            <span className="text-xs text-text-dim line-through font-mono">{formatPrice(price.mrp)}</span>
                            <span className="badge-rose text-2xs">{price.discount}% off</span>
                          </div>}
                        </>
                      )}
                    </div>
                  </Link>
                </motion.div>
              );
            })}
          </div>
        </div>
      )}

      {/* Category filter */}
      <div className="flex items-center gap-2 overflow-x-auto scrollbar-none mb-6">
        {CATEGORIES.map(cat => (
          <button key={cat} onClick={() => setActiveCategory(cat)}
            className={cn('px-4 py-2 rounded-xl text-sm font-medium whitespace-nowrap transition-all flex-shrink-0',
              activeCategory === cat ? 'bg-gradient-ai text-white' : 'btn-ghost')}>
            {cat}
          </button>
        ))}
        <div className="flex items-center gap-2 ml-auto flex-shrink-0">
          <select value={sortBy} onChange={e => setSortBy(e.target.value)}
            className="btn-ghost text-sm pr-8 bg-transparent cursor-pointer">
            <option value="discount">Highest Discount</option>
            <option value="popular">Most Popular</option>
            <option value="price_asc">Price: Low to High</option>
          </select>
        </div>
      </div>

      {/* All deals grid */}
      {isLoading ? (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {Array.from({ length: 12 }).map((_, i) => (
            <div key={i} className="glass rounded-2xl animate-pulse overflow-hidden">
              <div className="aspect-square bg-surface" />
              <div className="p-4 space-y-2">
                <div className="h-3 bg-surface rounded w-1/3" />
                <div className="h-4 bg-surface rounded" />
                <div className="h-5 bg-surface rounded w-1/2" />
              </div>
            </div>
          ))}
        </div>
      ) : deals.length > 0 ? (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {deals.map((deal: any, i: number) => {
            const price = deal.prices?.[0];
            return (
              <motion.div key={i} initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.04 }}>
                <Link href={`/product/${deal.slug}`} className="glass-hover rounded-2xl overflow-hidden block group">
                  <div className="relative aspect-square bg-surface flex items-center justify-center p-4">
                    {deal.thumbnail
                      ? <img src={deal.thumbnail} alt={deal.name} className="w-full h-full object-contain group-hover:scale-105 transition-transform duration-300" />
                      : <span className="text-5xl">{deal.category?.emoji}</span>
                    }
                    {price?.discount && (
                      <div className="absolute top-3 left-3 badge-emerald font-bold">{price.discount}% OFF</div>
                    )}
                    <button className="absolute top-3 right-3 w-8 h-8 rounded-full bg-bg/80 backdrop-blur-sm border border-border flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all text-text-dim hover:text-amber">
                      <Bell size={13} />
                    </button>
                  </div>
                  <div className="p-4">
                    <div className="text-xs text-text-muted mb-1">{deal.brand?.name}</div>
                    <div className="text-sm font-semibold text-text line-clamp-2 mb-3 leading-snug">{deal.name}</div>
                    {price && (
                      <div className="flex items-end gap-2">
                        <div className="font-mono font-bold text-base text-emerald">{formatPrice(price.price)}</div>
                        {price.mrp && <div className="text-xs text-text-dim line-through font-mono mb-0.5">{formatPrice(price.mrp)}</div>}
                      </div>
                    )}
                    {price?.seller && (
                      <div className="flex items-center justify-between mt-2">
                        <span className="text-xs text-text-muted">{price.seller.name}</span>
                        <span className="text-xs text-text-dim flex items-center gap-0.5"><TrendingDown size={10} className="text-emerald" /> Price dropped</span>
                      </div>
                    )}
                  </div>
                </Link>
              </motion.div>
            );
          })}
        </div>
      ) : (
        <div className="glass rounded-2xl p-16 text-center">
          <div className="text-4xl mb-4">🏷️</div>
          <div className="font-display font-bold text-xl mb-2">No deals available right now</div>
          <p className="text-text-muted mb-6">Set up price alerts to be the first to know when prices drop.</p>
          <Link href="/alerts" className="btn-ai inline-flex items-center gap-2">
            <Bell size={14} /> Set Price Alerts
          </Link>
        </div>
      )}
    </div>
  );
}
