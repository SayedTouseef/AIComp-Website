export const metadata = { title: 'Contact AIComp' };
export default function ContactPage() {
  return (
    <div className="max-w-2xl mx-auto px-6 py-16">
      <h1 className="font-display font-extrabold text-4xl tracking-tight mb-4">Get in Touch</h1>
      <p className="text-text-muted mb-10">Have a question, partnership inquiry, or found incorrect data? We read every message.</p>
      <div className="glass rounded-2xl p-8">
        <div className="space-y-4">
          {[['Your Name','text','your-name'],['Email Address','email','your-email'],['Subject','text','subject']].map(([label,type,id])=>(
            <div key={id}><label className="text-xs text-text-muted block mb-1.5">{label}</label><input type={type} className="w-full bg-surface border border-border rounded-xl px-4 py-3 text-sm text-text outline-none focus:border-border-glow transition-colors" /></div>
          ))}
          <div><label className="text-xs text-text-muted block mb-1.5">Message</label><textarea rows={5} className="w-full bg-surface border border-border rounded-xl px-4 py-3 text-sm text-text outline-none focus:border-border-glow transition-colors resize-none" /></div>
          <button className="btn-ai w-full py-3">Send Message</button>
        </div>
      </div>
      <div className="grid grid-cols-2 gap-4 mt-6">
        {[['Press & Media','press@aicomp.in'],['Partnerships','partners@aicomp.in'],['Support','hello@aicomp.in'],['Careers','careers@aicomp.in']].map(([label,email])=>(
          <div key={label} className="glass rounded-xl p-4"><div className="text-xs text-text-muted mb-1">{label}</div><a href={`mailto:${email}`} className="text-cyan text-sm hover:underline">{email}</a></div>
        ))}
      </div>
    </div>
  );
}