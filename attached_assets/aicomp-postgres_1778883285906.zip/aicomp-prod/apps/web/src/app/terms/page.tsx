export const metadata = { title: 'Terms of Use — AIComp' };
export default function TermsPage() {
  return (
    <div className="max-w-3xl mx-auto px-6 py-16">
      <h1 className="font-display font-extrabold text-4xl tracking-tight mb-2">Terms of Use</h1>
      <p className="text-text-muted mb-8">Effective: January 1, 2025</p>
      <div className="space-y-8">
        {[
          ['Acceptance', 'By using AIComp, you agree to these Terms. If you do not agree, please do not use our services.'],
          ['Use of Service', 'AIComp provides product information, price comparisons, and AI-generated recommendations for informational purposes. We strive for accuracy but cannot guarantee all information is up to date.'],
          ['Affiliate Links', 'We participate in affiliate programs. When you purchase through our links, we earn a commission at no extra cost to you. This does not influence our recommendations.'],
          ['Intellectual Property', 'All content, AI-generated text, design, and code on AIComp is owned by AIComp Technologies Pvt. Ltd. You may not copy or redistribute our content without permission.'],
          ['Limitation of Liability', 'AIComp is not liable for purchasing decisions made based on our platform. Always verify prices on the seller's website before purchasing.'],
          ['Modifications', 'We may update these Terms at any time. Continued use of AIComp after changes constitutes acceptance.'],
          ['Contact', 'For legal inquiries: legal@aicomp.in'],
        ].map(([title, content]) => (
          <div key={title as string}>
            <h2 className="font-display font-bold text-xl mb-2">{title as string}</h2>
            <p className="text-text-muted leading-relaxed">{content as string}</p>
          </div>
        ))}
      </div>
    </div>
  );
}