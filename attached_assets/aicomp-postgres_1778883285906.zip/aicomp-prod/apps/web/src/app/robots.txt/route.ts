import { NextResponse } from 'next/server';
export function GET() {
  return new NextResponse(
    `User-agent: *\nAllow: /\nDisallow: /api/\nDisallow: /auth/\nDisallow: /account/\nSitemap: https://aicomp.in/sitemap.xml`,
    { headers: { 'Content-Type': 'text/plain' } }
  );
}
