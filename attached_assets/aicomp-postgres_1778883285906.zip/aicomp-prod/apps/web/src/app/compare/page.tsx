'use client';

import { useState, useEffect } from 'react';
import { useSearchParams } from 'next/navigation';
import { motion } from 'framer-motion';
import { Plus, Search, Sparkles } from 'lucide-react';
import { ComparisonEngine } from '@/components/compare/ComparisonEngine';
import { api } from '@/hooks/useApi';

export default function ComparePage() {
  const searchParams = useSearchParams();
  const [products, setProducts] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<any[]>([]);

  useEffect(() => {
    const ids = searchParams.get('ids');
    if (ids) {
      setLoading(true);
      api.get(`/compare?ids=${ids}`)
        .then(d => setProducts(d.products || []))
        .catch(() => {})
        .finally(() => setLoading(false));
    }
  }, [searchParams]);

  const handleSearch = async (q: string) => {
    setSearchQuery(q);
    if (q.length < 2) return setSearchResults([]);
    const data = await api.get(`/search/autocomplete?q=${encodeURIComponent(q)}`);
    setSearchResults(data.results?.filter((r: any) => r.type === 'product') || []);
  };

  const addProduct = async (slug: string) => {
    if (products.length >= 4) return;
    const data = await api.get(`/products/${slug}`);
    if (!products.find(p => p.id === data.id)) {
      setProducts(prev => [...prev, data]);
    }
    setSearchResults([]);
    setSearchQuery('');
  };

  if (loading) {
    return (
      <div className="max-w-[1400px] mx-auto px-6 py-20 text-center">
        <div className="inline-flex items-center gap-3 text-text-muted">
          <div className="w-5 h-5 border-2 border-cyan border-t-transparent rounded-full animate-spin" />
          Loading comparison...
        </div>
      </div>
    );
  }

  // Empty state - show search to add products
  if (products.length === 0) {
    return (
      <div className="max-w-[900px] mx-auto px-6 py-20 text-center">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
          <div className="text-6xl mb-6">⚖️</div>
          <h1 className="font-display font-extrabold text-4xl tracking-tight mb-4">Compare Products</h1>
          <p className="text-text-muted text-lg mb-10">Search for products to compare side-by-side with AI-powered analysis.</p>

          <div className="relative max-w-lg mx-auto mb-4">
            <div className="glass rounded-2xl border-border-glow flex items-center gap-3 px-4">
              <Search size={18} className="text-text-muted flex-shrink-0" />
              <input
                value={searchQuery}
                onChange={e => handleSearch(e.target.value)}
                placeholder="Search iPhone 16, Samsung S24, MacBook..."
                className="flex-1 bg-transparent py-4 text-base outline-none text-text placeholder-text-dim"
              />
            </div>
            {searchResults.length > 0 && (
              <div className="absolute top-full left-0 right-0 mt-2 glass border-border-glow rounded-2xl overflow-hidden z-50">
                {searchResults.slice(0, 6).map((r: any, i: number) => (
                  <button key={i} onClick={() => addProduct(r.slug)}
                    className="w-full flex items-center gap-3 px-4 py-3 hover:bg-surface-hover transition-colors text-left">
                    <div className="text-xl">{r.image ? <img src={r.image} className="w-8 h-8 object-contain" alt="" /> : '📦'}</div>
                    <div>
                      <div className="text-sm font-medium text-text">{r.name}</div>
                      {r.category && <div className="text-xs text-text-muted">{r.category}</div>}
                    </div>
                    {r.price && <div className="ml-auto text-sm font-mono text-emerald">{r.price}</div>}
                    <Plus size={14} className="text-cyan flex-shrink-0" />
                  </button>
                ))}
              </div>
            )}
          </div>

          <div className="flex flex-wrap justify-center gap-3 mt-8">
            {['iPhone 16 Pro vs Samsung S24 Ultra', 'MacBook Air M3 vs Dell XPS 15', 'RTX 4070 vs RX 7800 XT'].map(pair => (
              <button key={pair} className="badge-cyan text-xs cursor-pointer hover:bg-cyan/20 transition-colors">{pair}</button>
            ))}
          </div>
        </motion.div>
      </div>
    );
  }

  return (
    <div>
      {/* Add more products bar */}
      {products.length < 4 && (
        <div className="border-b border-border bg-bg/80 backdrop-blur-xl sticky top-16 z-30">
          <div className="max-w-[1400px] mx-auto px-6 py-3 flex items-center gap-4">
            <div className="text-sm text-text-muted">Compare: {products.map(p => p.name).join(', ')}</div>
            <div className="relative ml-auto">
              <div className="flex items-center gap-2 glass rounded-xl px-3 py-2 border-border-glow">
                <Search size={14} className="text-text-muted" />
                <input
                  value={searchQuery}
                  onChange={e => handleSearch(e.target.value)}
                  placeholder="Add another product..."
                  className="bg-transparent text-sm outline-none text-text placeholder-text-dim w-48"
                />
              </div>
              {searchResults.length > 0 && (
                <div className="absolute top-full right-0 mt-2 w-72 glass border-border-glow rounded-xl overflow-hidden z-50 shadow-card">
                  {searchResults.slice(0, 5).map((r: any, i: number) => (
                    <button key={i} onClick={() => addProduct(r.slug)}
                      className="w-full flex items-center gap-3 px-3 py-2.5 hover:bg-surface-hover transition-colors text-left text-sm">
                      <span className="text-text">{r.name}</span>
                      <Plus size={12} className="ml-auto text-cyan" />
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      <ComparisonEngine initialProducts={products.map(formatProductForCompare)} />
    </div>
  );
}

function formatProductForCompare(p: any) {
  return {
    id: p.id,
    name: p.name,
    image: p.thumbnail || '',
    brand: p.brand?.name || '',
    category: p.category?.name || '',
    scores: {
      gaming: p.gameScore || 0,
      battery: p.batteryScore || 0,
      camera: p.cameraScore || 0,
      perf: p.perfScore || 0,
      value: p.valueScore || 0,
      cooling: p.coolingScore || 0,
    },
    prices: (p.prices || []).map((pr: any) => ({
      seller: pr.seller?.name || '',
      logo: pr.seller?.logo || '',
      price: pr.price / 100,
      mrp: pr.mrp ? pr.mrp / 100 : undefined,
      inStock: pr.inStock,
      url: pr.affiliateUrl || '#',
      cashback: pr.cashback,
    })),
    specs: (p.specs || []).map((s: any) => ({
      group: s.groupName,
      name: s.specName,
      values: [s.specValue],
    })),
    aiPros: p.aiPros || [],
    aiCons: p.aiCons || [],
  };
}
