export const metadata = { title: 'Privacy Policy — AIComp' };
export default function PrivacyPage() {
  return (
    <div className="max-w-3xl mx-auto px-6 py-16">
      <h1 className="font-display font-extrabold text-4xl tracking-tight mb-2">Privacy Policy</h1>
      <p className="text-text-muted mb-8">Last updated: January 1, 2025</p>
      <div className="space-y-8">
        {[
          ['Information We Collect', 'We collect information you provide (name, email, preferences) and usage data (search queries, viewed products, comparison history). We do not sell your personal data.'],
          ['How We Use Your Data', 'Your data is used to personalize recommendations, send price alerts you've requested, improve our AI models, and operate the platform. We never share personal data with advertisers.'],
          ['Cookies', 'We use cookies for authentication, preferences, and anonymous analytics. You can disable cookies but some features may not work correctly.'],
          ['Data Security', 'All data is encrypted in transit (TLS 1.3) and at rest. We use industry-standard security practices and regular audits.'],
          ['Your Rights', 'You can request a copy of your data, ask us to delete it, or opt out of marketing communications at any time via account settings or emailing privacy@aicomp.in.'],
          ['Contact', 'For privacy concerns, email privacy@aicomp.in. We respond within 48 hours.'],
        ].map(([title, content]) => (
          <div key={title as string}>
            <h2 className="font-display font-bold text-xl mb-2">{title as string}</h2>
            <p className="text-text-muted leading-relaxed">{content as string}</p>
          </div>
        ))}
      </div>
    </div>
  );
}