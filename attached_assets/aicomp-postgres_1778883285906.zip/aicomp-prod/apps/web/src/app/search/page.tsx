'use client';

import { useSearchParams } from 'next/navigation';
import { useState } from 'react';
import { motion } from 'framer-motion';
import Link from 'next/link';
import { Sparkles, Search, Filter, ArrowUpDown } from 'lucide-react';
import { cn, formatPrice, scoreColor } from '@/lib/utils';
import { useSearch } from '@/hooks/useApi';
import { SearchBar } from '@/components/search/SearchBar';

const SORT_OPTIONS = ['relevance', 'price_asc', 'price_desc', 'popular', 'rating', 'newest'];

export default function SearchPage() {
  const searchParams = useSearchParams();
  const q = searchParams.get('q') || '';
  const mode = searchParams.get('mode') || 'search';
  const [sort, setSort] = useState('relevance');
  const [page, setPage] = useState(1);

  const { data, isLoading } = useSearch(q, { sort, page, limit: 24 });
  const products = data?.products || [];
  const pagination = data?.pagination;
  const content = data?.content || [];

  return (
    <div className="max-w-[1400px] mx-auto px-6 py-8">
      {/* Search bar */}
      <div className="mb-8">
        <SearchBar fullPage />
      </div>

      {/* Query display */}
      <div className="flex items-center justify-between mb-6">
        <div>
          {mode === 'ai' && <div className="flex items-center gap-2 mb-2"><Sparkles size={14} className="text-violet" /><span className="text-sm text-violet">AI Search Results</span></div>}
          <h1 className="font-display font-bold text-2xl">
            {isLoading ? 'Searching...' : `${pagination?.total?.toLocaleString() || 0} results for "${q}"`}
          </h1>
        </div>
        <select value={sort} onChange={e => setSort(e.target.value)}
          className="btn-ghost text-sm bg-transparent cursor-pointer capitalize">
          {SORT_OPTIONS.map(s => <option key={s} value={s} className="bg-bg capitalize">{s.replace('_', ' ')}</option>)}
        </select>
      </div>

      {/* Content results */}
      {content.length > 0 && (
        <div className="mb-8">
          <div className="section-label mb-3">Related Guides</div>
          <div className="flex gap-3 overflow-x-auto scrollbar-none pb-2">
            {content.map((c: any, i: number) => (
              <Link key={i} href={`/guides/${c.slug}`}
                className="flex-shrink-0 glass rounded-xl px-4 py-3 hover:border-border-glow transition-colors">
                <div className="text-xs text-text-muted capitalize mb-1">{c.type.replace('_', ' ')}</div>
                <div className="text-sm font-semibold text-text w-52 truncate">{c.title}</div>
              </Link>
            ))}
          </div>
        </div>
      )}

      {/* Product grid */}
      {isLoading ? (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-4">
          {Array.from({ length: 12 }).map((_, i) => (
            <div key={i} className="glass rounded-2xl animate-pulse overflow-hidden">
              <div className="aspect-square bg-surface" />
              <div className="p-4 space-y-2">
                <div className="h-3 bg-surface rounded w-1/2" />
                <div className="h-4 bg-surface rounded" />
              </div>
            </div>
          ))}
        </div>
      ) : products.length > 0 ? (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-4">
          {products.map((p: any, i: number) => {
            const price = p.prices?.[0];
            return (
              <motion.div key={p.id} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.03 }}>
                <Link href={`/product/${p.slug}`} className="glass-hover rounded-2xl overflow-hidden group block">
                  <div className="aspect-square bg-surface flex items-center justify-center p-4">
                    {p.thumbnail ? <img src={p.thumbnail} alt={p.name} className="w-full h-full object-contain group-hover:scale-105 transition-transform" /> : <span className="text-4xl">{p.category?.emoji}</span>}
                  </div>
                  <div className="p-3">
                    <div className="text-2xs text-text-muted mb-0.5">{p.brand?.name}</div>
                    <div className="text-xs font-semibold text-text line-clamp-2 mb-2 leading-snug">{p.name}</div>
                    {price && <div className="font-mono text-sm font-bold text-text">{formatPrice(price.price)}</div>}
                    {p.overallScore && <div className="text-2xs font-mono mt-1" style={{ color: scoreColor(p.overallScore) }}>{p.overallScore}/100</div>}
                  </div>
                </Link>
              </motion.div>
            );
          })}
        </div>
      ) : (
        <div className="glass rounded-2xl p-16 text-center">
          <div className="text-4xl mb-4">🔍</div>
          <div className="font-display font-bold text-xl mb-2">No results for "{q}"</div>
          <p className="text-text-muted mb-6">Try different keywords or browse categories</p>
          <div className="flex flex-wrap justify-center gap-3">
            {['Smartphones', 'Laptops', 'TVs', 'Gaming PCs'].map(cat => (
              <Link key={cat} href={`/category/${cat.toLowerCase().replace(' ', '-')}`} className="badge-cyan">{cat}</Link>
            ))}
          </div>
        </div>
      )}

      {/* Pagination */}
      {pagination && pagination.totalPages > 1 && (
        <div className="flex justify-center gap-2 mt-10">
          <button disabled={!pagination.hasPrev} onClick={() => setPage(p => p - 1)} className="btn-ghost px-4 py-2 text-sm disabled:opacity-40">← Prev</button>
          <span className="flex items-center text-sm text-text-muted px-4">Page {page} of {pagination.totalPages}</span>
          <button disabled={!pagination.hasNext} onClick={() => setPage(p => p + 1)} className="btn-ghost px-4 py-2 text-sm disabled:opacity-40">Next →</button>
        </div>
      )}
    </div>
  );
}
