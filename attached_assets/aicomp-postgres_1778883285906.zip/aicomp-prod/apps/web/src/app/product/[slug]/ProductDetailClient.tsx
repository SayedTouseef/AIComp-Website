'use client';

import { useState } from 'react';
import Link from 'next/link';
import { ExternalLink, Bell, Heart, Share2, ChevronDown, ChevronUp, Star } from 'lucide-react';
import { AdLeaderboard, AdRectangle } from '@/components/ads/AdRail';

function scoreColor(s: number) { return s >= 85 ? 'var(--green)' : s >= 70 ? 'var(--orange)' : 'var(--red)'; }
function formatPrice(p: number) { return `₹${(p/100).toLocaleString('en-IN')}`; }

const SCORE_LABELS: Record<string, string> = {
  gameScore:'🎮 Gaming', batteryScore:'🔋 Battery', cameraScore:'📷 Camera',
  perfScore:'⚡ Perf', coolingScore:'❄️ Cooling', valueScore:'💰 Value',
};

export function ProductDetailClient({ product }: { product: any }) {
  const [activeTab, setActiveTab] = useState('specs');
  const [expanded, setExpanded] = useState<Set<string>>(new Set(['Display','Performance']));
  const [wishlisted, setWishlisted] = useState(false);

  const toggle = (g: string) => { const s = new Set(expanded); s.has(g)?s.delete(g):s.add(g); setExpanded(s); };
  const tabs = ['specs','prices','ai-review','benchmarks','reviews'];
  const bestPrice = product.prices?.[0];

  return (
    <div style={{ padding:'12px 16px' }}>

      {/* Breadcrumb */}
      <div className="breadcrumb" style={{ marginBottom:10 }}>
        <Link href="/">Home</Link>
        <span className="breadcrumb-sep">›</span>
        <Link href={`/category/${product.category?.slug}`}>{product.category?.name}</Link>
        <span className="breadcrumb-sep">›</span>
        <span style={{ color:'var(--text)' }}>{product.name}</span>
      </div>

      {/* Top grid */}
      <div style={{ display:'grid', gridTemplateColumns:'1fr 300px', gap:16, alignItems:'start', marginBottom:16 }}>

        {/* Left: Image + scores */}
        <div>
          <div style={{ marginBottom:10 }}>
            <div style={{ display:'flex', alignItems:'center', gap:8, marginBottom:6 }}>
              <span className="tag">{product.brand?.name}</span>
              {product.category && <span className="tag">{product.category.emoji} {product.category.name}</span>}
              {product.isTrending && <span className="discount-badge">🔥 Trending</span>}
            </div>
            <h1 style={{ fontFamily:'"Roboto Condensed",sans-serif', fontWeight:700, fontSize:22, color:'var(--text)', marginBottom:6, lineHeight:1.2 }}>
              {product.name}
            </h1>
            <div style={{ display:'flex', alignItems:'center', gap:16, fontSize:12, color:'var(--text-muted)' }}>
              {product.avgRating > 0 && (
                <div style={{ display:'flex', alignItems:'center', gap:4 }}>
                  <div className="stars">
                    {[1,2,3,4,5].map(s => <span key={s} style={{ color: s<=Math.round(product.avgRating) ? 'var(--yellow)' : 'var(--text-dim)', fontSize:13 }}>★</span>)}
                  </div>
                  <span style={{ fontWeight:600, color:'var(--text)' }}>{product.avgRating?.toFixed(1)}</span>
                  <span>({product.reviewCount} reviews)</span>
                </div>
              )}
              {product.overallScore && (
                <span className={`score-pill ${product.overallScore>=85?'score-high':product.overallScore>=70?'score-mid':'score-low'}`}>
                  AI {product.overallScore}/100
                </span>
              )}
            </div>
          </div>

          {/* Image */}
          <div style={{ background:'var(--surface)', border:'1px solid var(--border)', borderRadius:6, padding:24, display:'flex', alignItems:'center', justifyContent:'center', marginBottom:10, minHeight:240 }}>
            {product.thumbnail
              ? <img src={product.thumbnail} alt={product.name} style={{ maxHeight:200, maxWidth:'100%', objectFit:'contain' }} />
              : <span style={{ fontSize:80 }}>{product.category?.emoji ?? '📦'}</span>
            }
          </div>

          {/* Thumbnails */}
          {product.images?.length > 1 && (
            <div style={{ display:'flex', gap:6, overflowX:'auto', paddingBottom:4 }} className="scrollbar-none">
              {product.images.slice(0,6).map((img: string, i: number) => (
                <div key={i} style={{ width:56, height:56, background:'var(--surface)', border:'1px solid var(--border)', borderRadius:4, flexShrink:0, overflow:'hidden' }}>
                  <img src={img} alt="" style={{ width:'100%', height:'100%', objectFit:'contain', padding:4 }} />
                </div>
              ))}
            </div>
          )}

          {/* AI Scores */}
          {Object.entries(SCORE_LABELS).some(([k]) => product[k]) && (
            <div style={{ marginTop:12, background:'var(--card)', border:'1px solid var(--border)', borderRadius:6, overflow:'hidden' }}>
              <div className="section-head">AI Score Breakdown</div>
              <div style={{ padding:'10px 12px', display:'grid', gridTemplateColumns:'1fr 1fr', gap:'8px 16px' }}>
                {Object.entries(SCORE_LABELS).map(([key, label]) => {
                  const score = product[key];
                  if (!score) return null;
                  return (
                    <div key={key}>
                      <div style={{ display:'flex', justifyContent:'space-between', fontSize:11, marginBottom:3 }}>
                        <span style={{ color:'var(--text-muted)' }}>{label}</span>
                        <span style={{ fontWeight:700, color:scoreColor(score) }}>{score}</span>
                      </div>
                      <div style={{ height:5, background:'var(--surface2)', borderRadius:99, overflow:'hidden' }}>
                        <div style={{ height:'100%', borderRadius:99, background:scoreColor(score), width:`${score}%`, transition:'width 1s ease' }} />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        {/* Right: Buy box */}
        <div>
          <div style={{ background:'var(--card)', border:'1px solid var(--border)', borderRadius:6, overflow:'hidden', marginBottom:12 }}>
            <div className="section-head">Where to Buy</div>

            {bestPrice && (
              <div style={{ padding:'12px' }}>
                <div style={{ display:'flex', alignItems:'baseline', gap:8, marginBottom:6 }}>
                  <span className="price-badge">{formatPrice(bestPrice.price)}</span>
                  {bestPrice.mrp && bestPrice.mrp > bestPrice.price && (
                    <span className="price-old">{formatPrice(bestPrice.mrp)}</span>
                  )}
                  {bestPrice.discount && <span className="discount-badge">{bestPrice.discount}% off</span>}
                </div>

                <a href={bestPrice.affiliateUrl ?? '#'} target="_blank" rel="noopener noreferrer"
                  style={{ display:'flex', alignItems:'center', justifyContent:'center', gap:8, width:'100%', background:'var(--blue)', color:'#fff', border:'none', borderRadius:4, padding:'9px', fontSize:13, fontWeight:700, cursor:'pointer', textDecoration:'none', marginBottom:6 }}>
                  Buy from {bestPrice.seller?.name ?? 'Amazon'} <ExternalLink size={13} />
                </a>

                <button onClick={() => {}} style={{ display:'flex', alignItems:'center', justifyContent:'center', gap:6, width:'100%', background:'transparent', color:'var(--green)', border:'1px solid var(--green)', borderRadius:4, padding:'7px', fontSize:12, fontWeight:600, cursor:'pointer' }}>
                  <Bell size={13} /> Set Price Alert
                </button>

                {bestPrice.cashback && (
                  <div style={{ marginTop:8, padding:'6px 10px', background:'var(--green-bg)', border:'1px solid rgba(61,184,122,0.2)', borderRadius:4, fontSize:11, color:'var(--green)' }}>
                    💳 Extra {bestPrice.cashback} cashback
                  </div>
                )}
              </div>
            )}

            {/* All prices */}
            {product.prices?.length > 1 && (
              <div style={{ borderTop:'1px solid var(--border)' }}>
                <div style={{ padding:'6px 12px', fontSize:11, color:'var(--text-dim)', borderBottom:'1px solid var(--divider)' }}>Compare prices</div>
                {product.prices.slice(0,5).map((p: any, i: number) => (
                  <div key={i} style={{ display:'flex', alignItems:'center', justifyContent:'space-between', padding:'7px 12px', borderBottom:'1px solid var(--divider)' }}>
                    <span style={{ fontSize:12, color:'var(--text-muted)' }}>{p.seller?.name}</span>
                    <div style={{ display:'flex', alignItems:'center', gap:10 }}>
                      <span style={{ fontSize:13, fontWeight:700, color: i===0?'var(--green)':'var(--text)' }}>{formatPrice(p.price)}</span>
                      {p.affiliateUrl && p.inStock && (
                        <a href={p.affiliateUrl} target="_blank" rel="noopener noreferrer" className="btn-outline" style={{ padding:'2px 8px', fontSize:11 }}>
                          Buy
                        </a>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Action buttons */}
          <div style={{ display:'flex', gap:6, marginBottom:12 }}>
            <button
              onClick={() => setWishlisted(!wishlisted)}
              style={{ flex:1, display:'flex', alignItems:'center', justifyContent:'center', gap:6, background:'transparent', border:'1px solid var(--border)', borderRadius:4, padding:'7px', fontSize:12, cursor:'pointer', color: wishlisted?'var(--red)':'var(--text-muted)' }}
            >
              <Heart size={13} style={{ fill: wishlisted?'var(--red)':'none' }} />
              {wishlisted ? 'Wishlisted' : 'Add to Wishlist'}
            </button>
            <Link href={`/compare?ids=${product.id}`}
              style={{ flex:1, display:'flex', alignItems:'center', justifyContent:'center', gap:6, background:'transparent', border:'1px solid var(--border)', borderRadius:4, padding:'7px', fontSize:12, color:'var(--text-muted)', textDecoration:'none' }}>
              ⚖️ Compare
            </Link>
          </div>

          {/* Rectangle ad */}
          <div style={{ display:'flex', justifyContent:'center' }}>
            <AdRectangle />
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div style={{ display:'flex', gap:4, borderBottom:'2px solid var(--border)', marginBottom:0, overflowX:'auto' }} className="scrollbar-none">
        {tabs.map(tab => (
          <button key={tab} onClick={() => setActiveTab(tab)}
            style={{
              padding:'8px 16px', fontSize:13, fontWeight:600, cursor:'pointer',
              background: activeTab===tab ? 'var(--blue)' : 'transparent',
              color: activeTab===tab ? '#fff' : 'var(--text-muted)',
              border: activeTab===tab ? '2px solid var(--blue)' : '2px solid transparent',
              borderBottom: 'none', borderRadius:'4px 4px 0 0', whiteSpace:'nowrap',
              transition:'all 0.1s',
            }}>
            {tab==='ai-review' ? '✦ AI Review' : tab.charAt(0).toUpperCase() + tab.slice(1)}
          </button>
        ))}
      </div>

      {/* Tab content */}
      <div style={{ background:'var(--card)', border:'1px solid var(--border)', borderTop:'none', borderRadius:'0 0 4px 4px', marginBottom:16 }}>

        {/* Specs */}
        {activeTab==='specs' && (
          <div>
            {Object.entries(product.groupedSpecs ?? {}).map(([group, specs]: [string, any]) => (
              <div key={group}>
                <button onClick={() => toggle(group)}
                  style={{ width:'100%', display:'flex', alignItems:'center', justifyContent:'space-between', padding:'9px 12px', background:'var(--surface2)', border:'none', borderBottom:'1px solid var(--border)', cursor:'pointer', textAlign:'left' }}>
                  <span style={{ fontFamily:'"Roboto Condensed",sans-serif', fontWeight:700, fontSize:13, color:'var(--text)', textTransform:'uppercase', letterSpacing:'0.03em' }}>{group}</span>
                  {expanded.has(group) ? <ChevronUp size={14} style={{ color:'var(--text-muted)' }} /> : <ChevronDown size={14} style={{ color:'var(--text-muted)' }} />}
                </button>
                {expanded.has(group) && (
                  <table className="spec-table">
                    <tbody>
                      {specs.map((spec: any, i: number) => (
                        <tr key={i}>
                          <td className="spec-label">{spec.name}</td>
                          <td className="spec-val">{spec.value}{spec.unit ? ` ${spec.unit}` : ''}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                )}
              </div>
            ))}
            {!product.groupedSpecs && (
              <div style={{ padding:24, textAlign:'center', color:'var(--text-muted)', fontSize:13 }}>No spec data available yet.</div>
            )}
          </div>
        )}

        {/* Prices tab */}
        {activeTab==='prices' && (
          <div>
            {product.prices?.length > 0 ? product.prices.map((p: any, i: number) => (
              <div key={i} style={{ display:'flex', alignItems:'center', gap:12, padding:'10px 12px', borderBottom:'1px solid var(--divider)' }}>
                <div style={{ width:70, fontSize:12, color:'var(--text-muted)' }}>{p.seller?.name}</div>
                <div style={{ flex:1 }}>
                  {!p.inStock && <span style={{ fontSize:11, color:'var(--red)' }}>Out of stock</span>}
                </div>
                <div style={{ textAlign:'right' }}>
                  <div style={{ fontWeight:700, color: i===0?'var(--green)':'var(--text)', fontSize:15 }}>{formatPrice(p.price)}</div>
                  {p.mrp && p.mrp>p.price && <div className="price-old">{formatPrice(p.mrp)}</div>}
                </div>
                {p.affiliateUrl && p.inStock && (
                  <a href={p.affiliateUrl} target="_blank" rel="noopener noreferrer" className="btn-blue" style={{ padding:'6px 14px', fontSize:12 }}>
                    Buy →
                  </a>
                )}
              </div>
            )) : <div style={{ padding:24, textAlign:'center', color:'var(--text-muted)' }}>No price data available.</div>}
          </div>
        )}

        {/* AI Review */}
        {activeTab==='ai-review' && (
          <div style={{ padding:16 }}>
            <div style={{ display:'flex', alignItems:'center', gap:10, marginBottom:12, padding:'10px 12px', background:'var(--blue-bg)', border:'1px solid var(--blue-border)', borderRadius:5 }}>
              <span style={{ fontSize:20 }}>✦</span>
              <div>
                <div style={{ fontWeight:700, fontSize:13, color:'var(--blue)' }}>AI Analysis</div>
                <div style={{ fontSize:11, color:'var(--text-muted)' }}>Generated by AIComp Intelligence</div>
              </div>
            </div>
            <p style={{ fontSize:13, color:'var(--text)', lineHeight:1.7, marginBottom:14 }}>
              {product.aiSummary ?? `${product.name} is a ${product.category?.name ?? 'product'} from ${product.brand?.name}. Full AI analysis coming soon.`}
            </p>
            {product.aiPros?.length > 0 && (
              <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:12 }}>
                <div style={{ background:'var(--green-bg)', border:'1px solid rgba(61,184,122,0.2)', borderRadius:5, padding:'10px 12px' }}>
                  <div style={{ fontSize:11, fontWeight:700, color:'var(--green)', textTransform:'uppercase', letterSpacing:'0.05em', marginBottom:8 }}>✓ Pros</div>
                  {product.aiPros.map((p: string, i: number) => <div key={i} style={{ fontSize:12, color:'var(--text)', marginBottom:4, display:'flex', gap:6 }}><span style={{ color:'var(--green)' }}>+</span>{p}</div>)}
                </div>
                <div style={{ background:'rgba(224,92,92,0.06)', border:'1px solid rgba(224,92,92,0.15)', borderRadius:5, padding:'10px 12px' }}>
                  <div style={{ fontSize:11, fontWeight:700, color:'var(--red)', textTransform:'uppercase', letterSpacing:'0.05em', marginBottom:8 }}>✗ Cons</div>
                  {product.aiCons?.map((c: string, i: number) => <div key={i} style={{ fontSize:12, color:'var(--text)', marginBottom:4, display:'flex', gap:6 }}><span style={{ color:'var(--red)' }}>−</span>{c}</div>)}
                </div>
              </div>
            )}
          </div>
        )}

        {/* Benchmarks */}
        {activeTab==='benchmarks' && (
          <div>
            {product.benchmarks?.length > 0 ? (
              <table className="spec-table">
                <thead>
                  <tr>
                    <td className="spec-label" style={{ fontWeight:700, color:'var(--text)', background:'var(--surface2)' }}>Test</td>
                    <td className="spec-val" style={{ fontWeight:700, color:'var(--text)', background:'var(--surface2)' }}>Score</td>
                    <td className="spec-label" style={{ fontWeight:700, color:'var(--text)', background:'var(--surface2)' }}>Source</td>
                  </tr>
                </thead>
                <tbody>
                  {product.benchmarks.map((b: any, i: number) => (
                    <tr key={i}>
                      <td className="spec-label">{b.testName}</td>
                      <td className="spec-val" style={{ fontWeight:700, color:'var(--blue)' }}>{b.score.toLocaleString()}{b.unit?` ${b.unit}`:''}</td>
                      <td className="spec-label">{b.source ?? '—'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            ) : <div style={{ padding:24, textAlign:'center', color:'var(--text-muted)', fontSize:13 }}>No benchmark data yet.</div>}
          </div>
        )}

        {/* Reviews */}
        {activeTab==='reviews' && (
          <div style={{ padding:16, textAlign:'center', color:'var(--text-muted)', fontSize:13 }}>
            User reviews coming soon.
          </div>
        )}
      </div>

      {/* Leaderboard ad */}
      <AdLeaderboard />

    </div>
  );
}
