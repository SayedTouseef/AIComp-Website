import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { ProductDetailClient } from './ProductDetailClient';

interface Props {
  params: { slug: string };
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/v1/products/${params.slug}`, { next: { revalidate: 600 } }).catch(() => null);
  if (!res?.ok) return { title: 'Product Not Found' };
  const { name, brand, shortDesc, thumbnail, seoTitle, seoDesc } = (await res.json());
  return {
    title: seoTitle || `${name} Price in India, Specs & Review`,
    description: seoDesc || shortDesc || `${name} full specs, price, comparison and AI review.`,
    openGraph: { images: thumbnail ? [thumbnail] : [] },
  };
}

export default async function ProductPage({ params }: Props) {
  const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/v1/products/${params.slug}`, { next: { revalidate: 600 } }).catch(() => null);
  if (!res?.ok) notFound();
  const product = await res.json();
  return <ProductDetailClient product={product} />;
}
