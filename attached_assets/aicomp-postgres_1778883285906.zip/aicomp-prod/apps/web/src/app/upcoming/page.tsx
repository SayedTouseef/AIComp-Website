import type { Metadata } from 'next';
export const metadata: Metadata = { title:'Upcoming Electronics 2025 India — AIComp' };
export default function UpcomingPage() {
  return (
    <div className="max-w-container mx-auto px-6 py-8">
      <div className="section-label">🔭 Launch Radar</div>
      <h1 className="font-display font-extrabold text-4xl tracking-tight mb-4" style={{ color:'var(--text)' }}>Upcoming Products</h1>
      <p style={{ color:'var(--text-muted)' }}>See <a href="/launches" style={{ color:'var(--primary)' }}>New Launches</a> for full upcoming product tracking.</p>
    </div>
  );
}
