'use client';

import { motion } from 'framer-motion';
import Link from 'next/link';
import { Heart, Trash2, Bell, ExternalLink, ShoppingCart } from 'lucide-react';
import { formatPrice, scoreColor } from '@/lib/utils';
import { useWishlist, useToggleWishlist } from '@/hooks/useApi';

export default function WishlistPage() {
  const { data, isLoading } = useWishlist();
  const { mutate: toggle } = useToggleWishlist();
  const items = data?.items || [];

  if (isLoading) {
    return (
      <div className="max-w-4xl mx-auto px-6 py-8">
        <div className="grid gap-4">
          {[1,2,3].map(i => <div key={i} className="glass rounded-2xl h-28 animate-pulse" />)}
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-6 py-8">
      <div className="flex items-end justify-between mb-8">
        <div>
          <h1 className="font-display font-extrabold text-3xl tracking-tight">My Wishlist</h1>
          <p className="text-text-muted mt-1">{items.length} {items.length === 1 ? 'item' : 'items'} saved</p>
        </div>
        {items.length > 0 && (
          <Link href="/alerts" className="btn-ghost flex items-center gap-2 text-sm">
            <Bell size={14} /> Set price alerts for all
          </Link>
        )}
      </div>

      {items.length === 0 ? (
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
          className="glass rounded-2xl p-16 text-center">
          <Heart size={48} className="text-text-dim mx-auto mb-4" />
          <div className="font-display font-bold text-xl mb-2">Your wishlist is empty</div>
          <p className="text-text-muted mb-6">Save products to track their prices and compare later</p>
          <Link href="/" className="btn-ai inline-flex items-center gap-2">
            <ShoppingCart size={14} /> Browse Products
          </Link>
        </motion.div>
      ) : (
        <div className="space-y-3">
          {items.map((item: any, i: number) => {
            const p = item.product;
            const price = p.prices?.[0];
            return (
              <motion.div key={item.id} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05 }}>
                <div className="glass-hover rounded-2xl flex items-center gap-5 p-4">
                  <Link href={`/product/${p.slug}`}
                    className="w-20 h-20 rounded-xl bg-surface border border-border flex items-center justify-center overflow-hidden flex-shrink-0">
                    {p.thumbnail
                      ? <img src={p.thumbnail} alt={p.name} className="w-full h-full object-contain p-2" />
                      : <span className="text-3xl">{p.category?.emoji || '📦'}</span>
                    }
                  </Link>

                  <div className="flex-1 min-w-0">
                    <div className="text-xs text-text-muted mb-0.5">{p.brand?.name}</div>
                    <Link href={`/product/${p.slug}`}
                      className="font-semibold text-base text-text hover:text-cyan transition-colors line-clamp-1">
                      {p.name}
                    </Link>
                    <div className="flex items-center gap-4 mt-2">
                      {price ? (
                        <div className="font-mono font-bold text-lg text-emerald">{formatPrice(price.price)}</div>
                      ) : <div className="text-sm text-text-muted">Price TBA</div>}
                      {p.overallScore && (
                        <div className="text-xs font-mono px-2 py-0.5 rounded-lg"
                          style={{ color: scoreColor(p.overallScore), background: `${scoreColor(p.overallScore)}15` }}>
                          {p.overallScore}/100
                        </div>
                      )}
                      {price?.seller && (
                        <div className="text-xs text-text-muted">{price.seller.name}</div>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-2 flex-shrink-0">
                    <Link href={`/alerts?product=${p.id}`}
                      className="btn-ghost p-2.5 text-amber hover:bg-amber/5 hover:border-amber/20">
                      <Bell size={16} />
                    </Link>
                    {price?.affiliateUrl && (
                      <a href={price.affiliateUrl} target="_blank" rel="noopener noreferrer"
                        className="btn-ai px-3 py-2 text-xs flex items-center gap-1.5">
                        Buy <ExternalLink size={11} />
                      </a>
                    )}
                    <button onClick={() => toggle({ productId: p.id, inWishlist: true })}
                      className="btn-ghost p-2.5 text-text-muted hover:text-rose hover:bg-rose/5 hover:border-rose/20">
                      <Trash2 size={16} />
                    </button>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      )}

      {items.length > 0 && (
        <div className="mt-8 glass rounded-2xl p-5 flex items-center justify-between">
          <div>
            <div className="font-semibold text-base">Compare wishlist items</div>
            <div className="text-sm text-text-muted">Select up to 4 products to compare</div>
          </div>
          <Link href={`/compare?ids=${items.slice(0, 4).map((i: any) => i.product.id).join(',')}`}
            className="btn-ai text-sm flex items-center gap-2">
            Compare All →
          </Link>
        </div>
      )}
    </div>
  );
}
