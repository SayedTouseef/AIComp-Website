import { SignInForm } from '../AuthForms'; export default function Page() { return <SignInForm />; }
