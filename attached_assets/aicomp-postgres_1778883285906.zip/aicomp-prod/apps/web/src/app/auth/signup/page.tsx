import { SignUpForm } from '../AuthForms'; export default function Page() { return <SignUpForm />; }
