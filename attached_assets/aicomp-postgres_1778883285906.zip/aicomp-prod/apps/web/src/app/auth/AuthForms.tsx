'use client';

import { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { motion } from 'framer-motion';
import { Eye, EyeOff, Sparkles, Mail, Lock, User } from 'lucide-react';
import { cn } from '@/lib/utils';
import { api } from '@/hooks/useApi';
import toast from 'react-hot-toast';

export function SignInForm() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPass, setShowPass] = useState(false);
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const data = await api.post('/auth/login', { email, password });
      localStorage.setItem('token', data.token);
      toast.success('Welcome back!');
      router.push('/');
    } catch (err: any) {
      toast.error(err.message || 'Login failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center px-6">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="w-full max-w-md">
        <div className="text-center mb-8">
          <Link href="/" className="inline-flex items-center gap-2 mb-6">
            <div className="w-10 h-10 rounded-xl bg-gradient-ai flex items-center justify-center font-display font-black text-sm text-white">AI</div>
            <span className="font-display font-bold text-2xl">AI<span className="text-cyan">Comp</span></span>
          </Link>
          <h1 className="font-display font-extrabold text-3xl mb-2">Welcome back</h1>
          <p className="text-text-muted">Sign in to access price alerts and wishlist</p>
        </div>

        <div className="glass rounded-2xl p-8 border-border-glow">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="text-xs text-text-muted mb-1.5 block">Email</label>
              <div className="relative">
                <Mail size={15} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-text-muted" />
                <input type="email" value={email} onChange={e => setEmail(e.target.value)} required
                  className="w-full bg-surface border border-border rounded-xl pl-10 pr-4 py-3 text-sm text-text outline-none focus:border-border-glow transition-colors"
                  placeholder="you@example.com" />
              </div>
            </div>
            <div>
              <label className="text-xs text-text-muted mb-1.5 block">Password</label>
              <div className="relative">
                <Lock size={15} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-text-muted" />
                <input type={showPass ? 'text' : 'password'} value={password} onChange={e => setPassword(e.target.value)} required
                  className="w-full bg-surface border border-border rounded-xl pl-10 pr-10 py-3 text-sm text-text outline-none focus:border-border-glow transition-colors"
                  placeholder="••••••••" />
                <button type="button" onClick={() => setShowPass(!showPass)} className="absolute right-3.5 top-1/2 -translate-y-1/2 text-text-muted hover:text-text transition-colors">
                  {showPass ? <EyeOff size={15} /> : <Eye size={15} />}
                </button>
              </div>
            </div>

            <button type="submit" disabled={loading}
              className="btn-ai w-full py-3.5 flex items-center justify-center gap-2 disabled:opacity-60">
              {loading ? <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : 'Sign In'}
            </button>
          </form>

          <div className="relative my-6">
            <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-border" /></div>
            <div className="relative text-center"><span className="bg-bg-secondary px-3 text-xs text-text-muted">or continue with</span></div>
          </div>

          <button className="w-full btn-ghost py-3 flex items-center justify-center gap-3">
            <svg width="18" height="18" viewBox="0 0 24 24"><path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/><path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/><path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/><path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/></svg>
            Continue with Google
          </button>

          <p className="text-center text-sm text-text-muted mt-6">
            Don't have an account? <Link href="/auth/signup" className="text-cyan hover:underline">Sign up free</Link>
          </p>
        </div>
      </motion.div>
    </div>
  );
}

export function SignUpForm() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const data = await api.post('/auth/register', { name, email, password });
      localStorage.setItem('token', data.token);
      toast.success('Account created! Welcome to AIComp.');
      router.push('/');
    } catch (err: any) {
      toast.error(err.message || 'Registration failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center px-6">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="w-full max-w-md">
        <div className="text-center mb-8">
          <Link href="/" className="inline-flex items-center gap-2 mb-6">
            <div className="w-10 h-10 rounded-xl bg-gradient-ai flex items-center justify-center font-display font-black text-sm text-white">AI</div>
            <span className="font-display font-bold text-2xl">AI<span className="text-cyan">Comp</span></span>
          </Link>
          <h1 className="font-display font-extrabold text-3xl mb-2">Create account</h1>
          <p className="text-text-muted">Get price alerts, wishlist, and AI recommendations</p>
        </div>

        <div className="glass rounded-2xl p-8 border-border-glow">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="text-xs text-text-muted mb-1.5 block">Name</label>
              <div className="relative">
                <User size={15} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-text-muted" />
                <input type="text" value={name} onChange={e => setName(e.target.value)}
                  className="w-full bg-surface border border-border rounded-xl pl-10 pr-4 py-3 text-sm text-text outline-none focus:border-border-glow transition-colors"
                  placeholder="Your name" />
              </div>
            </div>
            <div>
              <label className="text-xs text-text-muted mb-1.5 block">Email</label>
              <div className="relative">
                <Mail size={15} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-text-muted" />
                <input type="email" value={email} onChange={e => setEmail(e.target.value)} required
                  className="w-full bg-surface border border-border rounded-xl pl-10 pr-4 py-3 text-sm text-text outline-none focus:border-border-glow transition-colors"
                  placeholder="you@example.com" />
              </div>
            </div>
            <div>
              <label className="text-xs text-text-muted mb-1.5 block">Password</label>
              <div className="relative">
                <Lock size={15} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-text-muted" />
                <input type="password" value={password} onChange={e => setPassword(e.target.value)} required minLength={8}
                  className="w-full bg-surface border border-border rounded-xl pl-10 pr-4 py-3 text-sm text-text outline-none focus:border-border-glow transition-colors"
                  placeholder="Min 8 characters" />
              </div>
            </div>
            <button type="submit" disabled={loading} className="btn-ai w-full py-3.5 flex items-center justify-center gap-2 disabled:opacity-60">
              {loading ? <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : 'Create Account'}
            </button>
          </form>
          <p className="text-center text-sm text-text-muted mt-6">
            Already have an account? <Link href="/auth/signin" className="text-cyan hover:underline">Sign in</Link>
          </p>
          <p className="text-center text-2xs text-text-dim mt-3">
            By signing up you agree to our <Link href="/terms" className="underline">Terms</Link> and <Link href="/privacy" className="underline">Privacy Policy</Link>
          </p>
        </div>
      </motion.div>
    </div>
  );
}
