'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import Link from 'next/link';
import { Bell, BellOff, Trash2, Plus, CheckCircle, Clock, Zap, TrendingDown } from 'lucide-react';
import { cn, formatPrice } from '@/lib/utils';
import { useAlerts } from '@/hooks/useApi';
import { api } from '@/hooks/useApi';
import toast from 'react-hot-toast';

const CHANNEL_ICONS: Record<string, string> = {
  EMAIL: '📧', PUSH: '🔔', WHATSAPP: '💬', TELEGRAM: '✈️', BROWSER: '🌐',
};

export default function AlertsPage() {
  const { data, refetch, isLoading } = useAlerts();
  const alerts = data?.alerts || [];

  const deleteAlert = async (id: string) => {
    try {
      await api.delete(`/alerts/${id}`);
      toast.success('Alert deleted');
      refetch();
    } catch { toast.error('Failed to delete alert'); }
  };

  if (isLoading) {
    return (
      <div className="max-w-4xl mx-auto px-6 py-8">
        <div className="space-y-3">
          {[1,2,3].map(i => <div key={i} className="glass rounded-2xl h-24 animate-pulse" />)}
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-6 py-8">
      <div className="flex items-end justify-between mb-8">
        <div>
          <div className="section-label flex items-center gap-2"><Bell size={12} /> Price Tracking</div>
          <h1 className="font-display font-extrabold text-3xl tracking-tight">Price Alerts</h1>
          <p className="text-text-muted mt-1">{alerts.length} active {alerts.length === 1 ? 'alert' : 'alerts'} · We check every 4 hours</p>
        </div>
      </div>

      {/* How it works */}
      <div className="grid grid-cols-3 gap-4 mb-8">
        {[
          { icon: Bell, label: 'Set Target Price', desc: 'Tell us your budget for any product', color: 'text-amber' },
          { icon: TrendingDown, label: 'We Monitor 24/7', desc: 'Prices checked every 4 hours across all sellers', color: 'text-cyan' },
          { icon: Zap, label: 'Instant Alert', desc: 'Get notified via WhatsApp, email, or push', color: 'text-emerald' },
        ].map((step, i) => (
          <div key={i} className="glass rounded-2xl p-4 flex items-center gap-3">
            <div className={cn('w-10 h-10 rounded-xl bg-surface border border-border flex items-center justify-center flex-shrink-0', step.color)}>
              <step.icon size={18} />
            </div>
            <div>
              <div className="text-sm font-semibold text-text">{step.label}</div>
              <div className="text-xs text-text-muted leading-relaxed">{step.desc}</div>
            </div>
          </div>
        ))}
      </div>

      {alerts.length === 0 ? (
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
          className="glass rounded-2xl p-16 text-center">
          <BellOff size={48} className="text-text-dim mx-auto mb-4" />
          <div className="font-display font-bold text-xl mb-2">No active alerts</div>
          <p className="text-text-muted mb-6">Browse products and set target prices to get notified when they drop</p>
          <Link href="/" className="btn-ai inline-flex items-center gap-2">
            <Plus size={14} /> Browse Products
          </Link>
        </motion.div>
      ) : (
        <div className="space-y-3">
          {alerts.map((alert: any, i: number) => {
            const p = alert.product;
            const currentPrice = p.prices?.[0]?.price;
            const priceMet = alert.targetPrice && currentPrice && currentPrice <= alert.targetPrice;

            return (
              <motion.div key={alert.id} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05 }}>
                <div className={cn('glass rounded-2xl flex items-center gap-4 p-4',
                  priceMet ? 'border-emerald/30 bg-emerald/5' : 'border-border')}>

                  <Link href={`/product/${p.slug}`}
                    className="w-16 h-16 rounded-xl bg-surface border border-border flex items-center justify-center flex-shrink-0 overflow-hidden">
                    {p.thumbnail
                      ? <img src={p.thumbnail} alt={p.name} className="w-full h-full object-contain p-1.5" />
                      : <span className="text-2xl">{p.category?.emoji || '📦'}</span>
                    }
                  </Link>

                  <div className="flex-1 min-w-0">
                    <Link href={`/product/${p.slug}`}
                      className="font-semibold text-sm text-text hover:text-cyan transition-colors line-clamp-1">
                      {p.name}
                    </Link>

                    <div className="flex items-center gap-4 mt-1.5">
                      {alert.targetPrice && (
                        <div className="text-xs text-text-muted">
                          Target: <span className="font-mono text-amber">{formatPrice(alert.targetPrice)}</span>
                        </div>
                      )}
                      {currentPrice && (
                        <div className="text-xs text-text-muted">
                          Current: <span className={cn('font-mono', priceMet ? 'text-emerald' : 'text-text')}>{formatPrice(currentPrice)}</span>
                        </div>
                      )}
                    </div>

                    <div className="flex items-center gap-2 mt-2">
                      {priceMet && (
                        <div className="flex items-center gap-1 text-xs text-emerald">
                          <CheckCircle size={12} /> Target reached!
                        </div>
                      )}
                      {!priceMet && (
                        <div className="flex items-center gap-1 text-xs text-text-muted">
                          <Clock size={11} /> Monitoring
                        </div>
                      )}
                      <div className="flex items-center gap-1 ml-auto">
                        {alert.channels?.map((ch: string) => (
                          <span key={ch} title={ch} className="text-sm">{CHANNEL_ICONS[ch]}</span>
                        ))}
                      </div>
                    </div>
                  </div>

                  <button onClick={() => deleteAlert(alert.id)}
                    className="btn-ghost p-2.5 text-text-muted hover:text-rose hover:bg-rose/5 hover:border-rose/20 flex-shrink-0">
                    <Trash2 size={15} />
                  </button>
                </div>
              </motion.div>
            );
          })}
        </div>
      )}

      {/* Tips */}
      <div className="mt-8 glass rounded-2xl p-5 border-border-glow">
        <div className="text-xs text-cyan font-mono uppercase tracking-wider mb-3">💡 Pro Tips</div>
        <ul className="space-y-2">
          {[
            'Set alerts for upcoming festivals — prices drop 30-50% during Diwali, Big Billion Days',
            'Enable WhatsApp alerts for instant notification without checking email',
            'Set "any price drop" alert to get notified of any reduction, not just your target',
          ].map((tip, i) => (
            <li key={i} className="text-xs text-text-muted flex items-start gap-2">
              <span className="text-cyan mt-0.5 flex-shrink-0">•</span> {tip}
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
