'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import { User, Bell, Shield, LogOut, Save, Camera, Star, Heart, Sparkles, ChevronRight } from 'lucide-react';
import { cn } from '@/lib/utils';
import { api } from '@/hooks/useApi';
import Link from 'next/link';
import toast from 'react-hot-toast';

const TABS = [
  { key: 'profile', label: 'Profile', icon: User },
  { key: 'notifications', label: 'Notifications', icon: Bell },
  { key: 'security', label: 'Security', icon: Shield },
];

const INTERESTS = ['Smartphones', 'Laptops', 'Gaming PCs', 'TVs', 'Air Conditioners', 'Cameras', 'Audio', 'Smartwatches'];

export default function AccountPage() {
  const [tab, setTab] = useState('profile');
  const [name, setName] = useState('Rohan Sharma');
  const [email] = useState('rohan@example.com');
  const [interests, setInterests] = useState(['Smartphones', 'Gaming PCs', 'Laptops']);
  const [budgetMin, setBudgetMin] = useState('');
  const [budgetMax, setBudgetMax] = useState('');
  const [notifEmail, setNotifEmail] = useState(true);
  const [notifPush, setNotifPush] = useState(true);
  const [notifWhatsapp, setNotifWhatsapp] = useState(false);
  const [notifTelegram, setNotifTelegram] = useState(false);
  const [saving, setSaving] = useState(false);

  const toggleInterest = (i: string) =>
    setInterests(p => p.includes(i) ? p.filter(x => x !== i) : [...p, i]);

  const handleSave = async () => {
    setSaving(true);
    try {
      await api.put('/users/profile', {
        name,
        profile: { interests, budgetMin: budgetMin ? +budgetMin * 100 : null, budgetMax: budgetMax ? +budgetMax * 100 : null },
      });
      toast.success('Profile updated!');
    } catch { toast.error('Save failed'); }
    finally { setSaving(false); }
  };

  return (
    <div className="max-w-4xl mx-auto px-6 py-8">
      <div className="mb-8">
        <h1 className="font-display font-extrabold text-3xl tracking-tight">My Account</h1>
        <p className="text-text-muted mt-1">Manage your profile, preferences, and notifications</p>
      </div>

      {/* Stats row */}
      <div className="grid grid-cols-3 gap-4 mb-8">
        {[
          { label: 'Wishlist Items', value: '12', icon: Heart, color: 'text-rose', href: '/wishlist' },
          { label: 'Active Alerts', value: '5', icon: Bell, color: 'text-amber', href: '/alerts' },
          { label: 'Comparisons', value: '8', icon: Sparkles, color: 'text-violet', href: '/compare' },
        ].map((s, i) => (
          <Link key={i} href={s.href}
            className="glass-hover rounded-2xl p-5 flex items-center gap-4 group">
            <div className={cn('w-10 h-10 rounded-xl bg-surface border border-border flex items-center justify-center', s.color)}>
              <s.icon size={18} />
            </div>
            <div>
              <div className="font-display font-bold text-2xl">{s.value}</div>
              <div className="text-xs text-text-muted">{s.label}</div>
            </div>
            <ChevronRight size={14} className="text-text-muted ml-auto group-hover:text-cyan group-hover:translate-x-0.5 transition-all" />
          </Link>
        ))}
      </div>

      <div className="grid md:grid-cols-[200px_1fr] gap-6">
        {/* Sidebar tabs */}
        <div className="space-y-1">
          {TABS.map(t => (
            <button key={t.key} onClick={() => setTab(t.key)}
              className={cn('w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all',
                tab === t.key ? 'bg-cyan/10 text-cyan border border-cyan/20' : 'text-text-muted hover:text-text hover:bg-surface')}>
              <t.icon size={16} /> {t.label}
            </button>
          ))}
          <button className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium text-rose hover:bg-rose/5 transition-all mt-4">
            <LogOut size={16} /> Sign Out
          </button>
        </div>

        {/* Content */}
        <div className="space-y-5">
          {tab === 'profile' && (
            <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}>
              {/* Avatar */}
              <div className="glass rounded-2xl p-6 mb-4">
                <div className="flex items-center gap-5">
                  <div className="relative">
                    <div className="w-20 h-20 rounded-2xl bg-gradient-ai flex items-center justify-center text-3xl font-bold text-white">
                      {name.charAt(0)}
                    </div>
                    <button className="absolute -bottom-1 -right-1 w-7 h-7 rounded-full bg-surface border border-border flex items-center justify-center text-text-muted hover:text-text transition-colors">
                      <Camera size={12} />
                    </button>
                  </div>
                  <div>
                    <div className="font-display font-bold text-xl">{name}</div>
                    <div className="text-sm text-text-muted">{email}</div>
                    <div className="flex items-center gap-1.5 mt-1 text-xs text-amber">
                      <Star size={11} className="fill-amber" /> 340 reputation points
                    </div>
                  </div>
                </div>
              </div>

              <div className="glass rounded-2xl p-6">
                <div className="font-display font-bold text-lg mb-5">Personal Info</div>
                <div className="space-y-4">
                  <div>
                    <label className="text-xs text-text-muted mb-1.5 block">Display Name</label>
                    <input value={name} onChange={e => setName(e.target.value)}
                      className="w-full bg-surface border border-border rounded-xl px-4 py-3 text-sm text-text outline-none focus:border-border-glow transition-colors" />
                  </div>
                  <div>
                    <label className="text-xs text-text-muted mb-1.5 block">Email (read-only)</label>
                    <input value={email} readOnly
                      className="w-full bg-surface border border-border rounded-xl px-4 py-3 text-sm text-text-muted outline-none opacity-60" />
                  </div>
                  <div>
                    <label className="text-xs text-text-muted mb-2 block">Budget Range (₹)</label>
                    <div className="flex gap-2">
                      <input type="number" value={budgetMin} onChange={e => setBudgetMin(e.target.value)} placeholder="Min"
                        className="flex-1 bg-surface border border-border rounded-xl px-4 py-3 text-sm text-text outline-none focus:border-border-glow transition-colors" />
                      <input type="number" value={budgetMax} onChange={e => setBudgetMax(e.target.value)} placeholder="Max"
                        className="flex-1 bg-surface border border-border rounded-xl px-4 py-3 text-sm text-text outline-none focus:border-border-glow transition-colors" />
                    </div>
                  </div>
                  <div>
                    <label className="text-xs text-text-muted mb-2 block">Interests</label>
                    <div className="flex flex-wrap gap-2">
                      {INTERESTS.map(i => (
                        <button key={i} onClick={() => toggleInterest(i)}
                          className={cn('px-3 py-1.5 rounded-xl text-xs font-medium transition-all border',
                            interests.includes(i) ? 'bg-cyan/10 text-cyan border-cyan/30' : 'border-border text-text-muted hover:border-border-glow hover:text-text')}>
                          {i}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
                <button onClick={handleSave} disabled={saving}
                  className="btn-ai flex items-center gap-2 mt-6 disabled:opacity-60">
                  {saving ? <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : <Save size={14} />}
                  Save Changes
                </button>
              </div>
            </motion.div>
          )}

          {tab === 'notifications' && (
            <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}>
              <div className="glass rounded-2xl p-6">
                <div className="font-display font-bold text-lg mb-5">Notification Channels</div>
                <div className="space-y-4">
                  {[
                    { label: 'Email Notifications', sub: 'Price alerts, new launches, weekly digest', value: notifEmail, set: setNotifEmail },
                    { label: 'Push Notifications', sub: 'Browser and mobile app push', value: notifPush, set: setNotifPush },
                    { label: 'WhatsApp Alerts', sub: 'Flash deals and price drops via WhatsApp', value: notifWhatsapp, set: setNotifWhatsapp },
                    { label: 'Telegram Alerts', sub: 'Price drops sent to your Telegram bot', value: notifTelegram, set: setNotifTelegram },
                  ].map((n, i) => (
                    <div key={i} className="flex items-center justify-between py-3 border-b border-border last:border-0">
                      <div>
                        <div className="text-sm font-medium text-text">{n.label}</div>
                        <div className="text-xs text-text-muted mt-0.5">{n.sub}</div>
                      </div>
                      <button onClick={() => n.set(!n.value)}
                        className={cn('relative w-11 h-6 rounded-full transition-colors flex-shrink-0',
                          n.value ? 'bg-cyan' : 'bg-border')}>
                        <div className={cn('absolute top-1 w-4 h-4 bg-white rounded-full shadow transition-transform',
                          n.value ? 'translate-x-6' : 'translate-x-1')} />
                      </button>
                    </div>
                  ))}
                </div>
                <button onClick={handleSave} className="btn-ai flex items-center gap-2 mt-5">
                  <Save size={14} /> Save Preferences
                </button>
              </div>
            </motion.div>
          )}

          {tab === 'security' && (
            <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}>
              <div className="glass rounded-2xl p-6">
                <div className="font-display font-bold text-lg mb-5">Change Password</div>
                <div className="space-y-4">
                  {['Current Password', 'New Password', 'Confirm New Password'].map(label => (
                    <div key={label}>
                      <label className="text-xs text-text-muted mb-1.5 block">{label}</label>
                      <input type="password" placeholder="••••••••"
                        className="w-full bg-surface border border-border rounded-xl px-4 py-3 text-sm text-text outline-none focus:border-border-glow transition-colors" />
                    </div>
                  ))}
                  <button className="btn-ai flex items-center gap-2">Update Password</button>
                </div>
              </div>
              <div className="glass rounded-2xl p-6">
                <div className="font-display font-bold text-lg mb-2">Active Sessions</div>
                <p className="text-sm text-text-muted mb-4">You're currently logged in from these devices.</p>
                {['Chrome on macOS · Mumbai · Active now', 'Safari on iPhone · Delhi · 2 hours ago'].map((s, i) => (
                  <div key={i} className="flex items-center justify-between py-3 border-b border-border last:border-0">
                    <div className="text-sm text-text">{s}</div>
                    <button className="text-xs text-rose hover:underline">Revoke</button>
                  </div>
                ))}
              </div>
            </motion.div>
          )}
        </div>
      </div>
    </div>
  );
}
