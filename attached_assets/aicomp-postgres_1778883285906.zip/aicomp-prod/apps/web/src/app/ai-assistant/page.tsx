'use client';

import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Send, Sparkles, User, Bot, RefreshCw, Copy, ThumbsUp, ThumbsDown, Mic, ChevronRight } from 'lucide-react';
import { cn } from '@/lib/utils';
import ReactMarkdown from 'react-markdown';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

const STARTERS = [
  { label: '📱 Best phone under ₹30K', prompt: 'What is the best smartphone under ₹30,000 right now?' },
  { label: '💻 Gaming laptop recommendations', prompt: 'Suggest the best gaming laptops under ₹1,00,000 for 1080p gaming' },
  { label: '❄️ Best inverter AC for 150 sq ft', prompt: 'What is the best 1-ton inverter AC for a 150 sq ft room in India?' },
  { label: '📺 4K TV under ₹50,000', prompt: 'Best 4K smart TV under ₹50,000 in India right now?' },
  { label: '🎮 PS5 vs Xbox Series X', prompt: 'Compare PS5 and Xbox Series X for Indian gamers' },
  { label: '🔋 Longest battery life phone', prompt: 'Which smartphone has the best battery life in 2025?' },
];

const API_BASE = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:4000/api/v1';

export default function AiAssistantPage() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [streaming, setStreaming] = useState(false);
  const [streamedText, setStreamedText] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, streamedText]);

  const sendMessage = async (text?: string) => {
    const content = text || input.trim();
    if (!content || streaming) return;

    const userMsg: Message = { id: Date.now().toString(), role: 'user', content, timestamp: new Date() };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setStreaming(true);
    setStreamedText('');

    try {
      const apiMessages = [...messages, userMsg].map(m => ({ role: m.role, content: m.content }));

      const res = await fetch(`${API_BASE}/ai/chat/stream`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ messages: apiMessages }),
      });

      if (!res.ok) throw new Error('Stream failed');

      const reader = res.body?.getReader();
      const decoder = new TextDecoder();
      let full = '';

      while (reader) {
        const { done, value } = await reader.read();
        if (done) break;
        const text = decoder.decode(value);
        const lines = text.split('\n');
        for (const line of lines) {
          if (line.startsWith('data: ')) {
            const data = line.slice(6);
            if (data === '[DONE]') break;
            try {
              const { chunk } = JSON.parse(data);
              if (chunk) { full += chunk; setStreamedText(full); }
            } catch {}
          }
        }
      }

      const aiMsg: Message = { id: (Date.now() + 1).toString(), role: 'assistant', content: full, timestamp: new Date() };
      setMessages(prev => [...prev, aiMsg]);
      setStreamedText('');
    } catch (err) {
      // Fallback to non-streaming
      try {
        const res = await fetch(`${API_BASE}/ai/chat`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ messages: [...messages, userMsg].map(m => ({ role: m.role, content: m.content })) }),
        });
        const data = await res.json();
        setMessages(prev => [...prev, { id: (Date.now() + 1).toString(), role: 'assistant', content: data.reply || 'Sorry, I could not process that.', timestamp: new Date() }]);
      } catch {
        setMessages(prev => [...prev, { id: (Date.now() + 1).toString(), role: 'assistant', content: '⚠️ Service temporarily unavailable. Please try again.', timestamp: new Date() }]);
      }
    } finally {
      setStreaming(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMessage(); }
  };

  const copyMessage = (content: string) => navigator.clipboard.writeText(content);

  return (
    <div className="max-w-4xl mx-auto px-6 py-8 min-h-screen flex flex-col">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-ai flex items-center justify-center">
            <Bot size={20} className="text-white" />
          </div>
          <div>
            <div className="font-display font-bold text-xl">AI Shopping Assistant</div>
            <div className="text-xs text-emerald flex items-center gap-1.5"><span className="live-dot" /> GPT-4 Powered · Available 24/7</div>
          </div>
        </div>
        {messages.length > 0 && (
          <button onClick={() => setMessages([])} className="btn-ghost text-sm flex items-center gap-2">
            <RefreshCw size={13} /> New Chat
          </button>
        )}
      </div>

      {/* Messages */}
      <div className="flex-1 space-y-6 mb-6">
        {/* Empty state */}
        {messages.length === 0 && !streaming && (
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center py-12">
            <div className="w-20 h-20 rounded-2xl bg-gradient-ai flex items-center justify-center mx-auto mb-6">
              <Sparkles size={36} className="text-white" />
            </div>
            <h2 className="font-display font-extrabold text-3xl mb-3">Ask me anything about electronics</h2>
            <p className="text-text-muted mb-10">I know every spec, every review, and every price. Ask in plain English.</p>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3 max-w-2xl mx-auto">
              {STARTERS.map((s, i) => (
                <button key={i} onClick={() => sendMessage(s.prompt)}
                  className="glass-hover text-left p-4 rounded-xl text-sm hover:border-border-glow group">
                  <span className="font-medium text-text">{s.label}</span>
                  <ChevronRight size={12} className="text-cyan mt-2 group-hover:translate-x-1 transition-transform" />
                </button>
              ))}
            </div>
          </motion.div>
        )}

        {/* Conversation */}
        <AnimatePresence initial={false}>
          {messages.map(msg => (
            <motion.div key={msg.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}
              className={cn('flex gap-3', msg.role === 'user' ? 'justify-end' : 'justify-start')}>
              {msg.role === 'assistant' && (
                <div className="w-8 h-8 rounded-xl bg-gradient-ai flex items-center justify-center flex-shrink-0 mt-1">
                  <Bot size={14} className="text-white" />
                </div>
              )}
              <div className={cn('max-w-[80%] group', msg.role === 'user' ? 'items-end' : 'items-start')}>
                <div className={cn('rounded-2xl px-5 py-4 text-sm leading-relaxed',
                  msg.role === 'user'
                    ? 'bg-gradient-ai text-white rounded-br-sm'
                    : 'glass border-border-glow text-text rounded-bl-sm'
                )}>
                  {msg.role === 'assistant' ? (
                    <div className="prose prose-invert prose-sm max-w-none [&>p]:mb-3 [&>ul]:mb-3 [&>ul>li]:mb-1 [&>h3]:font-bold [&>h3]:mb-2 [&>strong]:text-white">
                      <ReactMarkdown>{msg.content}</ReactMarkdown>
                    </div>
                  ) : msg.content}
                </div>
                {msg.role === 'assistant' && (
                  <div className="flex items-center gap-2 mt-2 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button onClick={() => copyMessage(msg.content)} className="text-text-dim hover:text-text p-1 rounded-lg hover:bg-surface transition-colors">
                      <Copy size={12} />
                    </button>
                    <button className="text-text-dim hover:text-emerald p-1 rounded-lg hover:bg-surface transition-colors"><ThumbsUp size={12} /></button>
                    <button className="text-text-dim hover:text-rose p-1 rounded-lg hover:bg-surface transition-colors"><ThumbsDown size={12} /></button>
                    <span className="text-2xs text-text-dim">{msg.timestamp.toLocaleTimeString()}</span>
                  </div>
                )}
              </div>
              {msg.role === 'user' && (
                <div className="w-8 h-8 rounded-xl bg-surface border border-border flex items-center justify-center flex-shrink-0 mt-1">
                  <User size={14} className="text-text-muted" />
                </div>
              )}
            </motion.div>
          ))}
        </AnimatePresence>

        {/* Streaming response */}
        {streaming && streamedText && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex gap-3">
            <div className="w-8 h-8 rounded-xl bg-gradient-ai flex items-center justify-center flex-shrink-0 mt-1">
              <Bot size={14} className="text-white" />
            </div>
            <div className="glass border-border-glow rounded-2xl rounded-bl-sm px-5 py-4 text-sm text-text leading-relaxed max-w-[80%]">
              <div className="prose prose-invert prose-sm max-w-none">
                <ReactMarkdown>{streamedText}</ReactMarkdown>
              </div>
              <span className="inline-block w-1.5 h-4 bg-cyan rounded-sm animate-pulse ml-1 align-middle" />
            </div>
          </motion.div>
        )}

        {/* Loading dots */}
        {streaming && !streamedText && (
          <div className="flex gap-3">
            <div className="w-8 h-8 rounded-xl bg-gradient-ai flex items-center justify-center flex-shrink-0">
              <Bot size={14} className="text-white" />
            </div>
            <div className="glass rounded-2xl rounded-bl-sm px-5 py-4 flex items-center gap-1.5">
              {[0,1,2].map(i => <div key={i} className="w-2 h-2 rounded-full bg-text-muted animate-bounce" style={{ animationDelay: `${i * 0.15}s` }} />)}
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Input */}
      <div className="glass rounded-2xl border-border-glow p-3">
        <div className="flex items-end gap-3">
          <textarea
            ref={inputRef}
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Ask about any product, budget, or use case..."
            rows={1}
            className="flex-1 bg-transparent text-text placeholder-text-dim text-base outline-none resize-none py-2 px-2 max-h-32"
            style={{ minHeight: '40px' }}
          />
          <div className="flex items-center gap-2 flex-shrink-0">
            <button className="text-text-dim hover:text-text p-2 rounded-lg hover:bg-surface transition-colors">
              <Mic size={18} />
            </button>
            <button onClick={() => sendMessage()} disabled={!input.trim() || streaming}
              className="btn-ai p-2.5 rounded-xl disabled:opacity-50 disabled:cursor-not-allowed">
              <Send size={16} />
            </button>
          </div>
        </div>
        <div className="flex items-center gap-4 mt-2 px-2">
          <div className="flex items-center gap-1.5 text-2xs text-text-dim">
            <Sparkles size={10} className="text-violet" />
            GPT-4 Powered · Knows live Indian prices
          </div>
          <div className="text-2xs text-text-dim ml-auto">Shift+Enter for new line</div>
        </div>
      </div>
    </div>
  );
}
