import type { Metadata } from 'next';
import Link from 'next/link';
import { BookOpen, Clock, Eye, ChevronRight } from 'lucide-react';

export const metadata: Metadata = {
  title: 'Buying Guides & Reviews — AIComp',
  description: 'Expert buying guides, reviews, and comparisons for electronics in India.',
};

const FEATURED_GUIDES = [
  { title: 'Best Smartphones Under ₹30,000 in India (2025)', slug: 'best-phones-under-30000', type: 'BUYING_GUIDE', readTime: '8 min', views: 45230, excerpt: 'We tested 24 phones under ₹30K. Here\'s our definitive ranking based on camera, battery, performance and value.', category: '📱 Smartphones', date: 'May 2025', featured: true },
  { title: 'Best Gaming Laptops Under ₹1 Lakh', slug: 'best-gaming-laptops-1-lakh', type: 'BUYING_GUIDE', readTime: '12 min', views: 38900, excerpt: 'Gaming laptops for every budget — RTX 4060 to RTX 4070, 144Hz to 240Hz. Our tested recommendations.', category: '💻 Laptops', date: 'May 2025', featured: true },
  { title: '1.5 Ton Inverter AC Buying Guide for India', slug: 'best-inverter-ac-india', type: 'BUYING_GUIDE', readTime: '10 min', views: 29400, excerpt: 'How to choose the right AC for Indian summers. Star ratings, BEE labels, and brand comparison.', category: '❄️ ACs', date: 'Apr 2025', featured: true },
];

const GUIDES = [
  { title: 'iPhone 16 vs Samsung S24 Ultra: Which Should You Buy?', slug: 'iphone-16-vs-s24-ultra', type: 'COMPARISON', readTime: '6 min', views: 23400, category: '📱 Smartphones', date: 'May 2025' },
  { title: 'Best 4K TVs Under ₹50,000 in India', slug: 'best-4k-tv-50000', type: 'BUYING_GUIDE', readTime: '9 min', views: 18900, category: '📺 TVs', date: 'Apr 2025' },
  { title: 'RTX 4070 vs RX 7800 XT: Complete India Comparison', slug: 'rtx-4070-vs-rx-7800', type: 'COMPARISON', readTime: '7 min', views: 16700, category: '🖥️ GPUs', date: 'Apr 2025' },
  { title: 'MacBook Air M3 vs Dell XPS 15: Which Laptop Wins?', slug: 'macbook-air-m3-vs-dell-xps', type: 'COMPARISON', readTime: '8 min', views: 14300, category: '💻 Laptops', date: 'Apr 2025' },
  { title: 'Best True Wireless Earbuds Under ₹5,000', slug: 'best-tws-earbuds-5000', type: 'BUYING_GUIDE', readTime: '5 min', views: 12100, category: '🎧 Audio', date: 'Mar 2025' },
  { title: 'Daikin vs Voltas vs LG AC: Which Brand is Best?', slug: 'daikin-vs-voltas-vs-lg-ac', type: 'COMPARISON', readTime: '7 min', views: 11800, category: '❄️ ACs', date: 'Mar 2025' },
  { title: 'Best Mirrorless Cameras for Beginners in India', slug: 'best-mirrorless-cameras-beginners', type: 'BUYING_GUIDE', readTime: '10 min', views: 9400, category: '📷 Cameras', date: 'Mar 2025' },
  { title: 'Gaming PC Build Under ₹80,000 (2025 Edition)', slug: 'gaming-pc-build-80000', type: 'HOW_TO', readTime: '14 min', views: 8700, category: '🖥️ PCs', date: 'Feb 2025' },
  { title: 'How to Read BEE Star Ratings for Air Conditioners', slug: 'bee-star-ratings-ac-explained', type: 'HOW_TO', readTime: '4 min', views: 7200, category: '❄️ ACs', date: 'Feb 2025' },
];

const TYPE_COLORS: Record<string, string> = {
  BUYING_GUIDE: 'text-cyan border-cyan/20 bg-cyan/5',
  COMPARISON: 'text-violet border-violet/20 bg-violet/5',
  HOW_TO: 'text-emerald border-emerald/20 bg-emerald/5',
  REVIEW: 'text-amber border-amber/20 bg-amber/5',
};

const TYPE_LABELS: Record<string, string> = {
  BUYING_GUIDE: 'Buying Guide',
  COMPARISON: 'Comparison',
  HOW_TO: 'How To',
  REVIEW: 'Review',
};

export default function GuidesPage() {
  return (
    <div className="max-w-[1400px] mx-auto px-6 py-8">
      {/* Header */}
      <div className="flex items-end justify-between mb-10">
        <div>
          <div className="section-label flex items-center gap-2"><BookOpen size={12} /> Expert Content</div>
          <h1 className="font-display font-extrabold text-4xl tracking-tight">Buying Guides & Comparisons</h1>
          <p className="text-text-muted mt-2">Research-backed guides to help you buy smarter in India</p>
        </div>
      </div>

      {/* Featured guides */}
      <div className="grid md:grid-cols-3 gap-5 mb-12">
        {FEATURED_GUIDES.map((g, i) => (
          <Link key={i} href={`/guides/${g.slug}`}
            className="glass-hover rounded-2xl overflow-hidden group flex flex-col">
            <div className="h-40 bg-gradient-to-br from-cyan/10 via-bg to-violet/10 flex items-center justify-center text-6xl">
              {g.category.split(' ')[0]}
            </div>
            <div className="p-5 flex flex-col flex-1">
              <div className="flex items-center gap-2 mb-3">
                <span className={`text-xs px-2 py-0.5 rounded-lg border ${TYPE_COLORS[g.type]}`}>{TYPE_LABELS[g.type]}</span>
                <span className="text-xs text-text-dim">{g.category}</span>
              </div>
              <h2 className="font-display font-bold text-lg leading-snug mb-2 group-hover:text-cyan transition-colors">{g.title}</h2>
              <p className="text-sm text-text-muted leading-relaxed flex-1 line-clamp-2">{g.excerpt}</p>
              <div className="flex items-center gap-4 mt-4 pt-4 border-t border-border text-xs text-text-dim">
                <span className="flex items-center gap-1"><Clock size={11} /> {g.readTime} read</span>
                <span className="flex items-center gap-1"><Eye size={11} /> {g.views.toLocaleString()}</span>
                <span className="ml-auto">{g.date}</span>
              </div>
            </div>
          </Link>
        ))}
      </div>

      {/* All guides */}
      <div className="section-label mb-5">All Guides</div>
      <div className="space-y-3">
        {GUIDES.map((g, i) => (
          <Link key={i} href={`/guides/${g.slug}`}
            className="glass-hover rounded-xl flex items-center gap-4 px-5 py-4 group">
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-1">
                <span className={`text-xs px-2 py-0.5 rounded-lg border ${TYPE_COLORS[g.type]}`}>{TYPE_LABELS[g.type]}</span>
                <span className="text-xs text-text-dim">{g.category}</span>
              </div>
              <div className="font-semibold text-sm text-text group-hover:text-cyan transition-colors">{g.title}</div>
            </div>
            <div className="flex items-center gap-4 text-xs text-text-dim flex-shrink-0">
              <span className="flex items-center gap-1"><Clock size={11} /> {g.readTime}</span>
              <span className="flex items-center gap-1"><Eye size={11} /> {g.views.toLocaleString()}</span>
              <span className="hidden md:block">{g.date}</span>
              <ChevronRight size={14} className="text-text-muted group-hover:text-cyan group-hover:translate-x-0.5 transition-all" />
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}
