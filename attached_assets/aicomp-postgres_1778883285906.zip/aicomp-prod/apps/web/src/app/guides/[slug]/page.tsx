import type { Metadata } from 'next';
import Link from 'next/link';
import { notFound } from 'next/navigation';
import { Clock, Eye, Share2, ArrowLeft, BookOpen } from 'lucide-react';

interface Props { params: { slug: string } }

// In production, fetch from DB/API
async function getGuide(slug: string) {
  // Mock data — replace with API call
  if (slug === 'best-phones-under-30000') {
    return {
      title: 'Best Smartphones Under ₹30,000 in India (2025)',
      excerpt: 'We tested 24 phones under ₹30K. Our definitive ranking.',
      readTime: '8 min', views: 45230,
      category: 'Smartphones', date: 'May 12, 2025',
      body: `
## Our Top Picks

After testing 24 smartphones under ₹30,000 across camera quality, battery life, performance, and display — here are our recommendations.

### 🏆 Best Overall: Samsung Galaxy A55 5G (₹27,999)
The Galaxy A55 5G is the most complete package under ₹30K. A bright 6.6" Super AMOLED display, capable 50MP triple camera, and impressive 5,000mAh battery make it the all-rounder to beat.

**What we liked:**
- Stunning display with 120Hz refresh rate
- Consistent camera output across lighting conditions
- 5G connectivity on all Indian bands
- Gorilla Glass Victus+ durability

**What could be better:**
- No 67W fast charging (only 25W)
- Average video stabilization

### 🥈 Best Camera: Google Pixel 8a (₹28,499)
If camera quality is your priority, the Pixel 8a delivers Google's computational photography magic in this price segment.

### 🥉 Best Battery: Realme 13 Pro+ (₹24,999)
6,000mAh battery, 67W fast charging, and a clean 50MP Sony IMX890 sensor make this the endurance champion.

---

## Full Comparison Table

| Phone | Price | RAM | Camera | Battery |
|-------|-------|-----|--------|---------|
| Samsung Galaxy A55 5G | ₹27,999 | 8GB | 50MP | 5,000mAh |
| Google Pixel 8a | ₹28,499 | 8GB | 64MP | 4,492mAh |
| Realme 13 Pro+ | ₹24,999 | 12GB | 50MP | 6,000mAh |
| OnePlus Nord 4 | ₹29,999 | 8GB | 50MP | 5,500mAh |

---

## How We Test

We test each phone for at least 2 weeks as a daily driver. Our evaluation covers:

1. **Camera**: 200+ photos in different lighting; blind comparison scoring
2. **Battery**: Standardized PCMark Battery Life test + real-world usage
3. **Performance**: Antutu, Geekbench, sustained performance under load
4. **Display**: Brightness, color accuracy, outdoor visibility
5. **Build**: Drop resistance, grip, button feel
      `,
    };
  }
  return null;
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const guide = await getGuide(params.slug);
  if (!guide) return { title: 'Guide Not Found' };
  return { title: `${guide.title} — AIComp`, description: guide.excerpt };
}

export default async function GuidePage({ params }: Props) {
  const guide = await getGuide(params.slug);
  if (!guide) notFound();

  return (
    <div className="max-w-4xl mx-auto px-6 py-8">
      {/* Back */}
      <Link href="/guides" className="flex items-center gap-2 text-sm text-text-muted hover:text-text mb-6 transition-colors">
        <ArrowLeft size={14} /> All Guides
      </Link>

      {/* Article header */}
      <div className="mb-8">
        <div className="flex items-center gap-2 mb-4">
          <span className="badge-cyan">📱 {guide.category}</span>
          <span className="badge-violet">Buying Guide</span>
        </div>
        <h1 className="font-display font-extrabold text-4xl tracking-tight leading-tight mb-4">{guide.title}</h1>
        <p className="text-text-muted text-lg">{guide.excerpt}</p>
        <div className="flex items-center gap-5 mt-5 pt-5 border-t border-border text-sm text-text-muted">
          <span className="flex items-center gap-1.5"><Clock size={14} /> {guide.readTime} read</span>
          <span className="flex items-center gap-1.5"><Eye size={14} /> {guide.views.toLocaleString()} views</span>
          <span>{guide.date}</span>
          <button className="ml-auto flex items-center gap-1.5 text-text-muted hover:text-text transition-colors">
            <Share2 size={14} /> Share
          </button>
        </div>
      </div>

      {/* Article body — rendered as markdown-like HTML */}
      <article className="glass rounded-2xl p-8 prose-like">
        <style>{`
          .prose-like h2 { font-family: 'Syne', sans-serif; font-weight: 800; font-size: 1.5rem; margin: 2rem 0 1rem; color: #e8edf8; }
          .prose-like h3 { font-family: 'Syne', sans-serif; font-weight: 700; font-size: 1.1rem; margin: 1.5rem 0 0.75rem; color: #c8d8f0; }
          .prose-like p { color: #8899bb; line-height: 1.8; margin-bottom: 1rem; }
          .prose-like ul, .prose-like ol { padding-left: 1.5rem; margin-bottom: 1rem; }
          .prose-like li { color: #8899bb; line-height: 1.7; margin-bottom: 0.25rem; }
          .prose-like strong { color: #e8edf8; }
          .prose-like table { width: 100%; border-collapse: collapse; margin: 1.5rem 0; }
          .prose-like th { text-align: left; padding: 10px 14px; background: rgba(255,255,255,0.04); border-bottom: 1px solid rgba(255,255,255,0.07); font-size: 0.75rem; text-transform: uppercase; letter-spacing: 0.05em; color: #6b7a9a; }
          .prose-like td { padding: 10px 14px; border-bottom: 1px solid rgba(255,255,255,0.04); color: #8899bb; font-size: 0.875rem; }
          .prose-like tr:last-child td { border-bottom: none; }
          .prose-like hr { border: none; border-top: 1px solid rgba(255,255,255,0.07); margin: 2rem 0; }
          .prose-like pre { background: rgba(255,255,255,0.04); border-radius: 10px; padding: 1rem; overflow-x: auto; }
          .prose-like code { font-family: 'Space Mono', monospace; font-size: 0.8rem; background: rgba(255,255,255,0.06); padding: 1px 5px; border-radius: 4px; }
        `}</style>
        <div dangerouslySetInnerHTML={{ __html: markdownToHtml(guide.body) }} />
      </article>

      {/* Related guides */}
      <div className="mt-10">
        <div className="section-label mb-4">Related Guides</div>
        <div className="grid md:grid-cols-2 gap-4">
          {['best-gaming-laptops-1-lakh', 'iphone-16-vs-s24-ultra'].map((slug, i) => (
            <Link key={i} href={`/guides/${slug}`}
              className="glass-hover rounded-xl p-4 flex items-center gap-3 group">
              <div className="w-10 h-10 rounded-xl bg-surface border border-border flex items-center justify-center text-xl flex-shrink-0">
                <BookOpen size={16} className="text-text-muted" />
              </div>
              <div>
                <div className="text-sm font-medium text-text group-hover:text-cyan transition-colors">Related Guide {i + 1}</div>
                <div className="text-xs text-text-muted">Read more →</div>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}

// Simple markdown-to-html converter
function markdownToHtml(md: string): string {
  return md
    .replace(/^### (.+)$/gm, '<h3>$1</h3>')
    .replace(/^## (.+)$/gm, '<h2>$1</h2>')
    .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
    .replace(/^\- (.+)$/gm, '<li>$1</li>')
    .replace(/(<li>.*<\/li>\n?)+/g, m => `<ul>${m}</ul>`)
    .replace(/^\d+\. (.+)$/gm, '<li>$1</li>')
    .replace(/^---$/gm, '<hr />')
    .replace(/^\|(.+)\|$/gm, (_, row) => {
      const cells = row.split('|').map((c: string) => c.trim());
      const isHeader = cells.every((c: string) => !c.startsWith('-'));
      if (cells.every((c: string) => c.match(/^-+$/))) return '';
      const tag = isHeader ? 'th' : 'td';
      return `<tr>${cells.map((c: string) => `<${tag}>${c}</${tag}>`).join('')}</tr>`;
    })
    .replace(/(<tr>.*<\/tr>\n?)+/g, m => `<table>${m}</table>`)
    .replace(/\n\n([^<\n].+)/g, '\n\n<p>$1</p>');
}
