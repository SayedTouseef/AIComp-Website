import type { Metadata } from 'next';
export const metadata: Metadata = { title:'Top Rated Electronics India — AIComp' };
export default function TopRatedPage() {
  return (
    <div className="max-w-container mx-auto px-6 py-8">
      <div className="section-label">⭐ Expert Verified</div>
      <h1 className="font-display font-extrabold text-4xl tracking-tight mb-4" style={{ color:'var(--text)' }}>Top Rated Products</h1>
      <p style={{ color:'var(--text-muted)' }}>Highest AI scores, best reviews, and proven performance. Loading...</p>
    </div>
  );
}
