import { MetadataRoute } from 'next';
export default function manifest(): MetadataRoute.Manifest {
  return {
    name: 'AIComp — Electronics Comparison',
    short_name: 'AIComp',
    description: 'AI-powered electronics comparison platform for India',
    start_url: '/',
    display: 'standalone',
    background_color: '#050810',
    theme_color: '#63b3ed',
    icons: [
      { src:'/icon-192.png', sizes:'192x192', type:'image/png' },
      { src:'/icon-512.png', sizes:'512x512', type:'image/png' },
    ],
  };
}
