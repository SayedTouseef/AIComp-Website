'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import { Cpu, Monitor, HardDrive, Zap, Fan, Package, MemoryStick, Gamepad2, Save, Share2, Trash2, Plus, CheckCircle, AlertTriangle } from 'lucide-react';
import { cn, formatPrice } from '@/lib/utils';

const COMPONENTS = [
  { key: 'cpu', label: 'Processor (CPU)', icon: Cpu, required: true, color: 'text-cyan' },
  { key: 'gpu', label: 'Graphics Card (GPU)', icon: Monitor, required: true, color: 'text-violet' },
  { key: 'ram', label: 'RAM', icon: MemoryStick, required: true, color: 'text-emerald' },
  { key: 'motherboard', label: 'Motherboard', icon: Package, required: true, color: 'text-amber' },
  { key: 'storage', label: 'Storage (SSD)', icon: HardDrive, required: true, color: 'text-cyan' },
  { key: 'psu', label: 'Power Supply (PSU)', icon: Zap, required: true, color: 'text-rose' },
  { key: 'case', label: 'PC Case', icon: Package, required: false, color: 'text-text-muted' },
  { key: 'cooler', label: 'CPU Cooler', icon: Fan, required: false, color: 'text-text-muted' },
  { key: 'monitor', label: 'Monitor', icon: Monitor, required: false, color: 'text-violet' },
];

const SAMPLE_BUILDS = [
  { name: 'Budget Gaming Build', price: 6500000, wattage: 450, desc: 'Perfect for 1080p gaming at high settings', parts: { cpu: 'AMD Ryzen 5 5600', gpu: 'RX 6600 XT', ram: '16GB DDR4', storage: '500GB NVMe SSD', psu: '550W 80+ Bronze', motherboard: 'B450M DS3H' } },
  { name: 'Mid-Range Beast', price: 12000000, wattage: 650, desc: '1440p gaming powerhouse', parts: { cpu: 'Intel Core i5-13600K', gpu: 'RTX 4070', ram: '32GB DDR5', storage: '1TB NVMe SSD', psu: '750W 80+ Gold', motherboard: 'Z790 Gaming X' } },
  { name: 'Creator Pro', price: 22000000, wattage: 750, desc: '4K gaming + content creation', parts: { cpu: 'AMD Ryzen 9 7950X', gpu: 'RTX 4090', ram: '64GB DDR5', storage: '2TB NVMe SSD', psu: '1000W 80+ Platinum', motherboard: 'X670E Hero' } },
];

const FPS_ESTIMATES: Record<string, Record<string, number>> = {
  'RTX 4090': { 'GTA VI': 95, 'Cyberpunk 2077': 120, 'Valorant': 400, 'BGMI': 300, 'Black Myth Wukong': 85 },
  'RTX 4070': { 'GTA VI': 72, 'Cyberpunk 2077': 85, 'Valorant': 300, 'BGMI': 250, 'Black Myth Wukong': 62 },
  'RX 6600 XT': { 'GTA VI': 58, 'Cyberpunk 2077': 64, 'Valorant': 240, 'BGMI': 180, 'Black Myth Wukong': 48 },
};

export default function PcBuilderPage() {
  const [selectedBuild, setSelectedBuild] = useState<typeof SAMPLE_BUILDS[0] | null>(null);
  const [customComponents, setCustomComponents] = useState<Record<string, string>>({});
  const [buildName, setBuildName] = useState('My Custom Build');
  const [activeTab, setActiveTab] = useState<'builder' | 'templates' | 'leaderboard'>('builder');

  const totalPrice = selectedBuild?.price || 0;
  const wattage = selectedBuild?.wattage || 0;
  const monthlyCost = Math.round(wattage * 8 * 30 * 7 / 100); // 8h/day, ₹7/unit

  const gpu = selectedBuild?.parts.gpu || '';
  const fpsData = FPS_ESTIMATES[gpu.split(' ').slice(-2).join(' ')] || FPS_ESTIMATES['RTX 4070'];

  return (
    <div className="max-w-[1400px] mx-auto px-6 py-8">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div>
          <div className="section-label">🖥️ Build Tool</div>
          <h1 className="font-display font-extrabold text-4xl tracking-tight">PC Builder</h1>
          <p className="text-text-muted mt-1">Build your perfect PC with compatibility checks and instant FPS estimates</p>
        </div>
        <div className="flex gap-3">
          <button className="btn-ghost flex items-center gap-2 text-sm"><Share2 size={14} /> Share</button>
          <button className="btn-ai flex items-center gap-2 text-sm"><Save size={14} /> Save Build</button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 border-b border-border mb-8">
        {(['builder', 'templates', 'leaderboard'] as const).map(tab => (
          <button key={tab} onClick={() => setActiveTab(tab)}
            className={cn('px-4 py-3 text-sm font-medium capitalize border-b-2 -mb-px transition-all',
              activeTab === tab ? 'border-cyan text-cyan' : 'border-transparent text-text-muted hover:text-text')}>
            {tab === 'builder' ? '🔧 Builder' : tab === 'templates' ? '📋 Templates' : '🏆 Leaderboard'}
          </button>
        ))}
      </div>

      {activeTab === 'templates' && (
        <div className="grid md:grid-cols-3 gap-5">
          {SAMPLE_BUILDS.map((build, i) => (
            <motion.div key={i} initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.1 }}>
              <div className={cn('glass-hover rounded-2xl p-6 cursor-pointer', selectedBuild?.name === build.name && 'border-cyan/40 bg-cyan/5')}
                onClick={() => { setSelectedBuild(build); setActiveTab('builder'); }}>
                <div className="font-display font-bold text-xl mb-2">{build.name}</div>
                <p className="text-sm text-text-muted mb-4">{build.desc}</p>
                <div className="space-y-1.5 mb-4">
                  {Object.entries(build.parts).slice(0, 4).map(([k, v]) => (
                    <div key={k} className="flex justify-between text-xs">
                      <span className="text-text-muted capitalize">{k}</span>
                      <span className="text-text font-medium">{v}</span>
                    </div>
                  ))}
                </div>
                <div className="flex items-center justify-between pt-3 border-t border-border">
                  <div className="font-mono font-bold text-emerald text-lg">{formatPrice(build.price)}</div>
                  <span className="badge-cyan text-2xs">{build.wattage}W</span>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      )}

      {activeTab === 'builder' && (
        <div className="grid lg:grid-cols-[1fr_360px] gap-8">
          {/* Component picker */}
          <div>
            <div className="flex items-center gap-3 mb-5">
              <input value={buildName} onChange={e => setBuildName(e.target.value)}
                className="font-display font-bold text-2xl bg-transparent outline-none text-text border-b border-transparent focus:border-border-glow pb-1 flex-1" />
            </div>

            <div className="space-y-3">
              {COMPONENTS.map((comp, i) => {
                const selected = selectedBuild?.parts[comp.key as keyof typeof selectedBuild.parts];
                return (
                  <motion.div key={comp.key} initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.05 }}>
                    <div className={cn('glass rounded-2xl p-4 flex items-center gap-4 transition-all hover:border-border-glow cursor-pointer group',
                      selected && 'border-border-strong')}>
                      <div className={cn('w-10 h-10 rounded-xl bg-surface border border-border flex items-center justify-center flex-shrink-0', comp.color)}>
                        <comp.icon size={18} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="text-xs text-text-muted mb-0.5">{comp.required ? '* Required' : 'Optional'}</div>
                        <div className="text-sm font-semibold text-text">{comp.label}</div>
                        {selected ? (
                          <div className="text-xs text-cyan mt-0.5">{selected}</div>
                        ) : (
                          <div className="text-xs text-text-dim mt-0.5">Click to add</div>
                        )}
                      </div>
                      {selected
                        ? <CheckCircle size={16} className="text-emerald flex-shrink-0" />
                        : <Plus size={16} className="text-text-muted flex-shrink-0 group-hover:text-cyan transition-colors" />
                      }
                    </div>
                  </motion.div>
                );
              })}
            </div>
          </div>

          {/* Summary panel */}
          <div className="space-y-4">
            {/* Price + Wattage */}
            <div className="glass rounded-2xl p-5">
              <div className="section-label mb-3">Build Summary</div>
              <div className="font-display font-extrabold text-4xl text-text mb-1">
                {selectedBuild ? formatPrice(selectedBuild.price) : '₹0'}
              </div>
              <div className="text-text-muted text-sm mb-4">Estimated total</div>

              <div className="grid grid-cols-2 gap-3">
                <div className="bg-surface rounded-xl p-3 border border-border">
                  <div className="text-2xs text-text-muted mb-1">Power Draw</div>
                  <div className="font-mono font-bold text-amber">{wattage}W</div>
                </div>
                <div className="bg-surface rounded-xl p-3 border border-border">
                  <div className="text-2xs text-text-muted mb-1">Monthly Electricity</div>
                  <div className="font-mono font-bold text-rose">~₹{monthlyCost}</div>
                </div>
              </div>

              {selectedBuild && (
                <div className="mt-4 space-y-2">
                  <div className="flex items-center gap-2 text-xs text-emerald">
                    <CheckCircle size={12} /> Parts compatible ✓
                  </div>
                  <div className="flex items-center gap-2 text-xs text-amber">
                    <AlertTriangle size={12} /> Verify PSU clearance in your case
                  </div>
                </div>
              )}

              <button className="btn-ai w-full mt-4 py-3 flex items-center justify-center gap-2">
                <Gamepad2 size={15} /> Get FPS Estimates
              </button>
            </div>

            {/* FPS estimates */}
            {selectedBuild && (
              <div className="glass rounded-2xl p-5">
                <div className="section-label mb-4">Estimated FPS @ 1080p Ultra</div>
                <div className="space-y-3">
                  {Object.entries(fpsData).map(([game, fps]) => (
                    <div key={game}>
                      <div className="flex justify-between text-xs mb-1">
                        <span className="text-text-muted">{game}</span>
                        <span className={cn('font-mono font-bold', fps >= 60 ? 'text-emerald' : fps >= 30 ? 'text-amber' : 'text-rose')}>{fps} FPS</span>
                      </div>
                      <div className="h-1.5 bg-border rounded-full overflow-hidden">
                        <div className={cn('h-full rounded-full transition-all', fps >= 60 ? 'bg-emerald' : fps >= 30 ? 'bg-amber' : 'bg-rose')}
                          style={{ width: `${Math.min(100, fps / 4)}%` }} />
                      </div>
                    </div>
                  ))}
                </div>
                <div className="text-2xs text-text-dim mt-3">* Estimates based on benchmark data. Actual FPS may vary.</div>
              </div>
            )}

            {/* Buy all links */}
            {selectedBuild && (
              <div className="glass rounded-2xl p-5">
                <div className="section-label mb-3">Buy Components</div>
                <div className="space-y-2">
                  {Object.entries(selectedBuild.parts).slice(0, 5).map(([key, name]) => (
                    <div key={key} className="flex items-center justify-between py-2 border-b border-border last:border-0">
                      <div className="text-xs text-text">{name}</div>
                      <a href={`https://www.amazon.in/s?k=${encodeURIComponent(name)}&tag=aicomp-21`}
                        target="_blank" rel="noopener noreferrer"
                        className="text-xs text-cyan hover:underline">Amazon →</a>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
