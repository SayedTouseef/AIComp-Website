'use client';

import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, X, Sparkles, ChevronDown, ExternalLink, Bell, Share2, Download } from 'lucide-react';
import { cn } from '@/lib/utils';

// ─── Types ───────────────────────────────────────────────

interface SpecRow {
  group: string;
  name: string;
  values: (string | null)[];
  highlight?: boolean; // best value gets highlighted
}

interface PriceEntry {
  seller: string;
  logo: string;
  price: number;
  mrp?: number;
  inStock: boolean;
  delivery?: string;
  url: string;
  cashback?: string;
}

interface ProductCompare {
  id: string;
  name: string;
  image: string;
  brand: string;
  category: string;
  scores: { gaming: number; battery: number; camera: number; perf: number; value: number; cooling: number };
  prices: PriceEntry[];
  specs: SpecRow[];
  aiVerdict?: string;
  aiPros: string[];
  aiCons: string[];
}

// ─── Score bar ───────────────────────────────────────────

function ScoreBar({ label, scores, colors }: { label: string; scores: number[]; colors: string[] }) {
  const best = Math.max(...scores);
  return (
    <div className="flex items-center gap-4">
      <div className="w-24 text-xs text-text-muted flex-shrink-0">{label}</div>
      {scores.map((score, i) => (
        <div key={i} className="flex-1 flex items-center gap-2">
          <div className="flex-1 score-bar">
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${score}%` }}
              transition={{ duration: 1, ease: 'easeOut', delay: i * 0.1 }}
              className="score-bar-fill"
              style={{ background: colors[i] }}
            />
          </div>
          <div className={cn('text-xs font-mono w-7 text-right', score === best && 'text-emerald font-bold')}>{score}</div>
        </div>
      ))}
    </div>
  );
}

// ─── Price card ──────────────────────────────────────────

function PriceTable({ products }: { products: ProductCompare[] }) {
  const allSellers = Array.from(new Set(products.flatMap(p => p.prices.map(pr => pr.seller))));

  return (
    <div className="space-y-4">
      {products.map((product, pi) => (
        <div key={pi} className="glass rounded-2xl overflow-hidden">
          <div className="px-5 py-3 border-b border-border bg-surface">
            <div className="font-display font-bold text-sm">{product.name}</div>
          </div>
          <div className="divide-y divide-border">
            {product.prices
              .sort((a, b) => a.price - b.price)
              .map((price, i) => (
                <div key={i} className={cn(
                  'flex items-center justify-between px-5 py-4',
                  i === 0 && 'bg-emerald/5'
                )}>
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-surface border border-border flex items-center justify-center text-sm">
                      {price.logo}
                    </div>
                    <div>
                      <div className="text-sm font-semibold text-text">{price.seller}</div>
                      {price.delivery && <div className="text-xs text-text-muted">{price.delivery}</div>}
                      {price.cashback && <div className="text-xs text-emerald">{price.cashback}</div>}
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="text-right">
                      <div className={cn('font-mono font-bold text-base', i === 0 ? 'text-emerald' : 'text-text')}>
                        ₹{price.price.toLocaleString('en-IN')}
                      </div>
                      {price.mrp && price.mrp > price.price && (
                        <div className="text-xs text-text-dim line-through font-mono">₹{price.mrp.toLocaleString('en-IN')}</div>
                      )}
                    </div>
                    {price.inStock ? (
                      <a href={price.url} target="_blank" rel="noopener noreferrer"
                        className="btn-ai text-xs px-4 py-2 flex items-center gap-1.5">
                        Buy <ExternalLink size={11} />
                      </a>
                    ) : (
                      <div className="text-xs text-text-dim border border-border rounded-lg px-3 py-2">Out of Stock</div>
                    )}
                  </div>
                </div>
              ))}
          </div>
        </div>
      ))}
    </div>
  );
}

// ─── Main comparison component ───────────────────────────

export function ComparisonEngine({ initialProducts = [] }: { initialProducts?: ProductCompare[] }) {
  const [products, setProducts] = useState<ProductCompare[]>(initialProducts);
  const [activeSection, setActiveSection] = useState('overview');
  const [showDiff, setShowDiff] = useState(false);

  const sections = ['overview', 'specs', 'prices', 'benchmarks', 'ai-verdict'];

  const scoreColors = ['#63b3ed', '#9f7aea', '#48bb78'];

  const getBestIndex = (values: (string | null)[]) => {
    // Try numeric comparison
    const nums = values.map(v => v ? parseFloat(v.replace(/[^0-9.]/g, '')) : -Infinity);
    const max = Math.max(...nums);
    return nums.indexOf(max);
  };

  const allSpecGroups = Array.from(new Set(
    products.flatMap(p => p.specs.map(s => s.group))
  ));

  return (
    <div className="max-w-[1400px] mx-auto px-6 py-10">

      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div>
          <div className="section-label mb-1">Side-by-side comparison</div>
          <h1 className="font-display font-extrabold text-4xl tracking-tight">
            {products.map(p => p.name).join(' vs ')}
          </h1>
        </div>
        <div className="flex items-center gap-3">
          <button className="btn-ghost flex items-center gap-2 text-sm">
            <Bell size={14} /> Price Alert
          </button>
          <button className="btn-ghost flex items-center gap-2 text-sm">
            <Share2 size={14} /> Share
          </button>
          <button onClick={() => setShowDiff(!showDiff)} className={cn(
            'btn-ghost text-sm',
            showDiff && 'border-cyan/40 text-cyan bg-cyan/5'
          )}>
            {showDiff ? 'Show All' : 'Highlight Differences'}
          </button>
        </div>
      </div>

      {/* Product header columns */}
      <div className={`grid gap-4 mb-6`} style={{ gridTemplateColumns: `200px repeat(${products.length}, 1fr)` }}>
        <div />
        {products.map((product, i) => (
          <motion.div key={product.id} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.1 }}>
            <div className="glass rounded-2xl p-5 text-center relative group">
              <button className="absolute top-3 right-3 opacity-0 group-hover:opacity-100 transition-opacity text-text-dim hover:text-rose">
                <X size={14} />
              </button>
              <img src={product.image} alt={product.name} className="w-24 h-24 object-contain mx-auto mb-4" />
              <div className="font-mono text-xs text-text-muted mb-1">{product.brand}</div>
              <div className="font-display font-bold text-base leading-tight">{product.name}</div>
              <div className="font-mono text-emerald text-sm mt-2">
                ₹{Math.min(...product.prices.map(p => p.price)).toLocaleString('en-IN')}
              </div>
              <a href={product.prices.sort((a,b) => a.price-b.price)[0]?.url}
                className="btn-ai text-xs px-4 py-2 mt-3 inline-flex items-center gap-1">
                Best Price <ExternalLink size={10} />
              </a>
            </div>
          </motion.div>
        ))}

        {/* Add product */}
        {products.length < 4 && (
          <button className="glass rounded-2xl p-5 border-dashed border-2 border-border hover:border-border-glow flex flex-col items-center justify-center gap-3 text-text-dim hover:text-text transition-all group min-h-[200px]">
            <div className="w-12 h-12 rounded-full bg-surface border border-border flex items-center justify-center group-hover:border-border-glow transition-colors">
              <Plus size={20} />
            </div>
            <div className="text-sm">Add Product</div>
          </button>
        )}
      </div>

      {/* Section tabs */}
      <div className="flex gap-2 border-b border-border mb-8 overflow-x-auto scrollbar-none">
        {sections.map(s => (
          <button
            key={s}
            onClick={() => setActiveSection(s)}
            className={cn(
              'px-4 py-3 text-sm font-medium capitalize whitespace-nowrap transition-all border-b-2 -mb-px',
              activeSection === s
                ? 'border-cyan text-cyan'
                : 'border-transparent text-text-muted hover:text-text'
            )}
          >
            {s === 'ai-verdict' ? '✦ AI Verdict' : s.charAt(0).toUpperCase() + s.slice(1)}
          </button>
        ))}
      </div>

      {/* AI Score Overview */}
      {activeSection === 'overview' && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
          <div className="glass rounded-2xl p-6">
            <div className="section-label mb-4">AI Scores</div>
            <div className="space-y-4">
              {(['gaming', 'battery', 'camera', 'perf', 'value', 'cooling'] as const).map(key => (
                <ScoreBar
                  key={key}
                  label={key.charAt(0).toUpperCase() + key.slice(1)}
                  scores={products.map(p => p.scores[key])}
                  colors={scoreColors}
                />
              ))}
            </div>
          </div>

          {/* Legend */}
          <div className="flex items-center gap-6">
            {products.map((p, i) => (
              <div key={i} className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full" style={{ background: scoreColors[i] }} />
                <span className="text-sm text-text-muted">{p.name}</span>
              </div>
            ))}
          </div>
        </motion.div>
      )}

      {/* Spec table */}
      {activeSection === 'specs' && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-8">
          {allSpecGroups.map(group => {
            const groupSpecs = products[0]?.specs.filter(s => s.group === group) || [];
            return (
              <div key={group}>
                <div className="section-label mb-3">{group}</div>
                <div className="glass rounded-2xl overflow-hidden">
                  {groupSpecs.map((spec, si) => {
                    const values = products.map(p =>
                      p.specs.find(s => s.group === group && s.name === spec.name)?.values[0] || '—'
                    );
                    const bestIdx = getBestIndex(values);
                    const allSame = new Set(values).size === 1;
                    if (showDiff && allSame) return null;
                    return (
                      <div key={si} className={cn(
                        'grid border-b border-border last:border-0',
                        `grid-cols-[200px_repeat(${products.length},1fr)]`
                      )}>
                        <div className="px-5 py-3.5 text-xs text-text-muted font-medium uppercase tracking-wider bg-surface">
                          {spec.name}
                        </div>
                        {values.map((val, vi) => (
                          <div key={vi} className={cn(
                            'px-5 py-3.5 text-sm font-mono',
                            vi === bestIdx && !allSame ? 'text-emerald font-bold' : 'text-text'
                          )}>
                            {val}
                          </div>
                        ))}
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </motion.div>
      )}

      {/* Prices */}
      {activeSection === 'prices' && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
          <PriceTable products={products} />
        </motion.div>
      )}

      {/* AI Verdict */}
      {activeSection === 'ai-verdict' && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
          <div className="glass rounded-2xl p-8 border-cyan/20">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 rounded-xl bg-gradient-ai flex items-center justify-center">
                <Sparkles size={18} className="text-white" />
              </div>
              <div>
                <div className="font-display font-bold text-lg">AI Verdict</div>
                <div className="text-xs text-text-muted">Powered by AIComp Intelligence</div>
              </div>
            </div>
            {products.map((product, i) => (
              <div key={i} className="mb-6">
                <div className="font-display font-bold mb-3 text-cyan">{product.name}</div>
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="bg-emerald/[0.06] border border-emerald/15 rounded-xl p-4">
                    <div className="text-xs text-emerald font-mono uppercase tracking-wider mb-3">✓ Pros</div>
                    <ul className="space-y-2">
                      {product.aiPros.map((pro, pi) => (
                        <li key={pi} className="text-sm text-text flex items-start gap-2">
                          <span className="text-emerald mt-0.5">+</span> {pro}
                        </li>
                      ))}
                    </ul>
                  </div>
                  <div className="bg-rose/[0.06] border border-rose/15 rounded-xl p-4">
                    <div className="text-xs text-rose font-mono uppercase tracking-wider mb-3">✗ Cons</div>
                    <ul className="space-y-2">
                      {product.aiCons.map((con, ci) => (
                        <li key={ci} className="text-sm text-text flex items-start gap-2">
                          <span className="text-rose mt-0.5">−</span> {con}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </motion.div>
      )}
    </div>
  );
}
