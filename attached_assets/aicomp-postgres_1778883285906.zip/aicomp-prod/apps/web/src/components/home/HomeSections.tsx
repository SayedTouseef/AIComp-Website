'use client';
// ═══════════════════════════════════════════════════════════
//  Homepage Sections — All in one file for efficiency
// ═══════════════════════════════════════════════════════════

import Link from 'next/link';
import { motion } from 'framer-motion';
import { TrendingUp, Sparkles, Zap, Bell, Globe, Bot, Cpu, BarChart3, Search, Package, Shield, ChevronRight, ArrowRight } from 'lucide-react';
import { useState } from 'react';

// ─── Trending Section ─────────────────────────────────────

const TRENDING_PRODUCTS = [
  { name: 'iPhone 16 Pro', brand: 'Apple', emoji: '📱', price: '₹1,19,900', trend: '+234%', score: 96, badge: '🔥 Hot' },
  { name: 'MacBook Air M4', brand: 'Apple', emoji: '💻', price: '₹1,29,900', trend: '+189%', score: 94, badge: '✨ New' },
  { name: 'Samsung S24 Ultra', brand: 'Samsung', emoji: '📱', price: '₹1,24,999', trend: '+145%', score: 91, badge: '🏆 Top' },
  { name: 'ASUS ROG Zephyrus', brand: 'ASUS', emoji: '💻', price: '₹1,89,990', trend: '+98%', score: 93, badge: '🎮 Gaming' },
  { name: 'Sony Bravia XR 65"', brand: 'Sony', emoji: '📺', price: '₹1,79,990', trend: '+76%', score: 89, badge: '🖥️ 4K' },
  { name: 'Daikin 1.5T Inverter', brand: 'Daikin', emoji: '❄️', price: '₹42,990', trend: '+71%', score: 88, badge: '⭐ Top' },
];

export function TrendingSection() {
  return (
    <section className="max-w-[1400px] mx-auto px-6 py-16">
      <div className="flex items-end justify-between mb-8">
        <div>
          <div className="section-label flex items-center gap-2">
            <TrendingUp size={12} /> Trending Now
          </div>
          <h2 className="font-display font-extrabold text-3xl tracking-tight">What India's Searching</h2>
        </div>
        <Link href="/search?sort=trending" className="btn-ghost text-sm hidden sm:block">View all →</Link>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {TRENDING_PRODUCTS.map((p, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.07 }}
          >
            <Link href={`/product/${p.name.toLowerCase().replace(/\s+/g, '-')}`}
              className="product-card flex items-center gap-4 rounded-2xl group">
              <div className="w-14 h-14 rounded-xl bg-surface border border-border flex items-center justify-center text-2xl flex-shrink-0 group-hover:scale-105 transition-transform">
                {p.emoji}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-0.5">
                  <span className="text-sm font-semibold text-text truncate">{p.name}</span>
                  <span className="badge-amber text-[9px] flex-shrink-0">{p.badge}</span>
                </div>
                <div className="text-xs text-text-muted">{p.brand}</div>
                <div className="flex items-center justify-between mt-2">
                  <span className="font-mono text-sm text-emerald font-bold">{p.price}</span>
                  <div className="flex items-center gap-2">
                    <span className="text-2xs text-emerald font-mono">{p.trend}</span>
                    <div className="flex items-center gap-1">
                      <div className="w-12 h-1 rounded-full bg-border overflow-hidden">
                        <div className="h-full rounded-full bg-cyan" style={{ width: `${p.score}%` }} />
                      </div>
                      <span className="text-2xs font-mono text-text-muted">{p.score}</span>
                    </div>
                  </div>
                </div>
              </div>
            </Link>
          </motion.div>
        ))}
      </div>
    </section>
  );
}

// ─── Feature Bento Grid ───────────────────────────────────

const FEATURES = [
  {
    title: 'AI Shopping Assistant',
    desc: 'Chat with AI to find the perfect product based on your exact needs and budget.',
    icon: Bot, color: 'text-violet', bg: 'bg-violet/10 border-violet/20',
    size: 'lg:col-span-2', href: '/ai-assistant', emoji: '🤖',
  },
  {
    title: 'Live Price Tracking',
    desc: 'Real-time prices from Amazon, Flipkart, Croma & more. Never miss a deal.',
    icon: Zap, color: 'text-emerald', bg: 'bg-emerald/10 border-emerald/20',
    size: '', href: '/deals', emoji: '💰',
  },
  {
    title: 'Price Drop Alerts',
    desc: 'Set your target price and get notified via WhatsApp, Telegram, or email.',
    icon: Bell, color: 'text-amber', bg: 'bg-amber/10 border-amber/20',
    size: '', href: '/alerts', emoji: '🔔',
  },
  {
    title: 'Gaming FPS Database',
    desc: 'Tested FPS data for 500+ games across every GPU and gaming laptop.',
    icon: Cpu, color: 'text-rose', bg: 'bg-rose/10 border-rose/20',
    size: '', href: '/gaming', emoji: '🎮',
  },
  {
    title: 'PC Builder Tool',
    desc: 'Build your perfect PC with compatibility checks and instant FPS estimates.',
    icon: Package, color: 'text-cyan', bg: 'bg-cyan/10 border-cyan/20',
    size: '', href: '/pc-builder', emoji: '🖥️',
  },
  {
    title: 'AI Score System',
    desc: 'Every product scored across 8 dimensions: gaming, battery, camera, value, and more.',
    icon: BarChart3, color: 'text-violet', bg: 'bg-violet/10 border-violet/20',
    size: 'lg:col-span-2', href: '/compare', emoji: '📊',
  },
];

export function FeatureBento() {
  return (
    <section className="max-w-[1400px] mx-auto px-6 py-16">
      <div className="text-center mb-12">
        <div className="section-label text-center justify-center flex">Platform Features</div>
        <h2 className="font-display font-extrabold text-4xl tracking-tight mb-4">
          Intelligence at Every Step
        </h2>
        <p className="text-text-muted max-w-lg mx-auto">Not just specs. AI-powered insights, live data, and smart tools to make every buying decision easier.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {FEATURES.map((f, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.08 }}
            className={f.size}
          >
            <Link href={f.href}
              className={`glass-hover rounded-2xl p-6 h-full flex flex-col gap-4 group border ${f.bg}`}>
              <div className={`w-12 h-12 rounded-xl ${f.bg} border flex items-center justify-center text-2xl`}>
                {f.emoji}
              </div>
              <div className="flex-1">
                <div className={`font-display font-bold text-lg mb-2 ${f.color}`}>{f.title}</div>
                <p className="text-sm text-text-muted leading-relaxed">{f.desc}</p>
              </div>
              <div className={`flex items-center gap-1 text-xs font-medium ${f.color}`}>
                Explore <ChevronRight size={12} className="group-hover:translate-x-1 transition-transform" />
              </div>
            </Link>
          </motion.div>
        ))}
      </div>
    </section>
  );
}

// ─── AI Assistant Preview ─────────────────────────────────

const SAMPLE_CHAT = [
  { role: 'user', text: 'Best gaming laptop under ₹1,20,000 for 1080p gaming?' },
  { role: 'ai', text: 'For ₹1,20,000 budget at 1080p, here are my top picks:\n\n🏆 **ASUS ROG Strix G16** (₹1,12,990)\n→ RTX 4070 · 240Hz · Best overall\n\n🥈 **Lenovo Legion Pro 5** (₹1,09,990)\n→ RTX 4070 · 165Hz · Better thermals\n\n🎯 My recommendation: ROG Strix G16 for gaming. Delivers 100+ FPS in most AAA titles.' },
  { role: 'user', text: 'Which one is better for streaming too?' },
  { role: 'ai', text: 'For gaming + streaming combo, the **Lenovo Legion Pro 5** wins — it has better thermals under combined CPU+GPU load, plus the 165Hz display is smoother for content creation. Battery life is also better at 4.5h vs 3h.' },
];

export function AiAssistantPreview() {
  const [typed, setTyped] = useState('');

  return (
    <section className="max-w-[1400px] mx-auto px-6 py-16">
      <div className="grid lg:grid-cols-2 gap-16 items-center">
        <div>
          <div className="section-label">AI Shopping Intelligence</div>
          <h2 className="font-display font-extrabold text-4xl tracking-tight mb-6">
            Ask anything. Get<br /><span className="gradient-text">expert answers.</span>
          </h2>
          <p className="text-text-muted leading-relaxed mb-8">
            Our AI knows every spec, every review, and every price. Ask in plain English — it understands use cases, budgets, and Indian market conditions.
          </p>
          <ul className="space-y-3 mb-10">
            {['Compares based on your exact use case', 'Knows live Indian prices', 'Understands "best under ₹50,000"', 'Recommends alternatives you might not know'].map((point, i) => (
              <li key={i} className="flex items-center gap-3 text-sm text-text">
                <span className="w-5 h-5 rounded-full bg-emerald/10 border border-emerald/20 flex items-center justify-center text-emerald text-xs">✓</span>
                {point}
              </li>
            ))}
          </ul>
          <Link href="/ai-assistant" className="btn-ai inline-flex items-center gap-2">
            <Sparkles size={16} /> Try AI Assistant Free
          </Link>
        </div>

        {/* Chat preview */}
        <div className="glass rounded-3xl overflow-hidden border-border-glow shadow-glow">
          <div className="px-5 py-4 border-b border-border flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl bg-gradient-ai flex items-center justify-center"><Bot size={16} className="text-white" /></div>
            <div>
              <div className="text-sm font-semibold">AIComp Assistant</div>
              <div className="text-2xs text-emerald flex items-center gap-1"><span className="live-dot w-1.5 h-1.5" /> Online · GPT-4 Powered</div>
            </div>
          </div>
          <div className="p-5 space-y-4 max-h-80 overflow-y-auto scrollbar-none">
            {SAMPLE_CHAT.map((msg, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 8 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.15 }}
                className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div className={`max-w-[85%] rounded-2xl px-4 py-3 text-sm leading-relaxed whitespace-pre-line ${
                  msg.role === 'user'
                    ? 'bg-gradient-ai text-white rounded-br-sm'
                    : 'bg-surface border border-border text-text rounded-bl-sm'
                }`}>
                  {msg.text}
                </div>
              </motion.div>
            ))}
          </div>
          <div className="px-5 py-4 border-t border-border">
            <div className="flex gap-2 items-center bg-surface border border-border rounded-xl px-4 py-3">
              <input
                value={typed}
                onChange={e => setTyped(e.target.value)}
                placeholder="Ask about any product..."
                className="flex-1 bg-transparent text-sm text-text placeholder-text-dim outline-none"
              />
              <Link href="/ai-assistant" className="btn-ai text-xs px-3 py-1.5 rounded-lg">Ask →</Link>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

// ─── Recent Launches ──────────────────────────────────────

const LAUNCHES = [
  { name: 'Samsung Galaxy S25 Ultra', brand: 'Samsung', date: 'Jan 22, 2025', price: '₹1,29,999', emoji: '📱', status: 'confirmed', isNew: true },
  { name: 'Apple iPhone 17 Pro', brand: 'Apple', date: 'Sep 2025', price: '~₹1,35,000', emoji: '📱', status: 'rumoured', isNew: false },
  { name: 'MacBook Air M5', brand: 'Apple', date: 'Mid 2025', price: '~₹1,20,000', emoji: '💻', status: 'expected', isNew: false },
  { name: 'OnePlus 14 Pro', brand: 'OnePlus', date: 'Q1 2025', price: '~₹65,000', emoji: '📱', status: 'expected', isNew: false },
  { name: 'ASUS ROG Phone 9', brand: 'ASUS', date: 'Feb 2025', price: '₹79,999', emoji: '📱', status: 'confirmed', isNew: true },
  { name: 'LG OLED G5', brand: 'LG', date: 'Mar 2025', price: '~₹2,50,000', emoji: '📺', status: 'rumoured', isNew: false },
];

const statusColors: Record<string, string> = {
  confirmed: 'badge-emerald',
  expected: 'badge-cyan',
  rumoured: 'badge-amber',
};

export function RecentLaunches() {
  return (
    <section className="max-w-[1400px] mx-auto px-6 py-16">
      <div className="flex items-end justify-between mb-8">
        <div>
          <div className="section-label">Upcoming & New</div>
          <h2 className="font-display font-extrabold text-3xl tracking-tight">Launch Radar</h2>
        </div>
        <Link href="/launches" className="btn-ghost text-sm hidden sm:block">All launches →</Link>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {LAUNCHES.map((l, i) => (
          <motion.div key={i} initial={{ opacity: 0, y: 12 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.06 }}>
            <div className="glass-hover rounded-2xl p-5 flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-surface border border-border flex items-center justify-center text-2xl flex-shrink-0">
                {l.emoji}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-sm font-semibold text-text truncate">{l.name}</span>
                  {l.isNew && <span className="badge-cyan text-2xs">NEW</span>}
                </div>
                <div className="text-xs text-text-muted">{l.brand} · {l.date}</div>
                <div className="flex items-center justify-between mt-2">
                  <span className="font-mono text-sm text-cyan">{l.price}</span>
                  <span className={`${statusColors[l.status]} text-2xs`}>{l.status}</span>
                </div>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </section>
  );
}

// ─── How It Works ─────────────────────────────────────────

const STEPS = [
  { step: '01', title: 'Search or Browse', desc: 'Find any product by name, category, or ask our AI in natural language.', icon: Search, color: 'text-cyan' },
  { step: '02', title: 'Compare Side-by-Side', desc: 'Add up to 4 products. See specs, prices, scores — all differences highlighted.', icon: BarChart3, color: 'text-violet' },
  { step: '03', title: 'Get AI Verdict', desc: 'Our AI analyzes specs, reviews, and your use case to give a clear recommendation.', icon: Bot, color: 'text-emerald' },
  { step: '04', title: 'Buy at Best Price', desc: 'We show prices from 50+ sellers. One click to buy with affiliate cashback.', icon: Zap, color: 'text-amber' },
];

export function HowItWorks() {
  return (
    <section className="max-w-[1400px] mx-auto px-6 py-16">
      <div className="text-center mb-12">
        <div className="section-label flex justify-center">How AIComp Works</div>
        <h2 className="font-display font-extrabold text-4xl tracking-tight">From Search to Purchase in 4 Steps</h2>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {STEPS.map((s, i) => (
          <motion.div key={i} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.1 }}>
            <div className="glass rounded-2xl p-6 h-full relative overflow-hidden">
              <div className="absolute top-4 right-4 font-display font-extrabold text-4xl text-white/[0.04]">{s.step}</div>
              <div className={`w-12 h-12 rounded-xl bg-surface border border-border flex items-center justify-center mb-4 ${s.color}`}>
                <s.icon size={22} />
              </div>
              <div className={`font-mono text-2xs tracking-widest uppercase mb-2 ${s.color}`}>Step {s.step}</div>
              <div className="font-display font-bold text-lg mb-2">{s.title}</div>
              <p className="text-sm text-text-muted leading-relaxed">{s.desc}</p>
            </div>
          </motion.div>
        ))}
      </div>
    </section>
  );
}

// ─── Platform Modules CTA ─────────────────────────────────

const MODULES = [
  { title: 'PC Builder', desc: 'Build your dream PC', emoji: '🖥️', href: '/pc-builder', color: 'from-cyan/10' },
  { title: 'Gaming Zone', desc: 'FPS benchmarks & leaderboards', emoji: '🎮', href: '/gaming', color: 'from-rose/10' },
  { title: 'Deals Hub', desc: 'Best prices live right now', emoji: '🏷️', href: '/deals', color: 'from-emerald/10' },
  { title: 'AI Chat', desc: 'Your personal buying advisor', emoji: '🤖', href: '/ai-assistant', color: 'from-violet/10' },
];

export function PlatformModules() {
  return (
    <section className="max-w-[1400px] mx-auto px-6 py-16 mb-8">
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {MODULES.map((m, i) => (
          <Link key={i} href={m.href}
            className={`glass-hover rounded-2xl p-6 bg-gradient-to-b ${m.color} to-transparent flex flex-col gap-3 group`}>
            <span className="text-4xl group-hover:scale-110 transition-transform duration-200">{m.emoji}</span>
            <div>
              <div className="font-display font-bold text-lg">{m.title}</div>
              <div className="text-sm text-text-muted">{m.desc}</div>
            </div>
            <div className="flex items-center gap-1 text-xs text-cyan mt-auto">
              Explore <ArrowRight size={12} className="group-hover:translate-x-1 transition-transform" />
            </div>
          </Link>
        ))}
      </div>
    </section>
  );
}
