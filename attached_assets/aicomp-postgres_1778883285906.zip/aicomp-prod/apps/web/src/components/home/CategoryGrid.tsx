'use client';

import Link from 'next/link';
import { motion } from 'framer-motion';

const categories = [
  { name: 'Smartphones', slug: 'smartphones', emoji: '📱', count: '4,200+', color: 'from-cyan/20 to-transparent', border: 'border-cyan/20 hover:border-cyan/40' },
  { name: 'Laptops', slug: 'laptops', emoji: '💻', count: '1,800+', color: 'from-violet/20 to-transparent', border: 'border-violet/20 hover:border-violet/40' },
  { name: 'TVs', slug: 'tvs', emoji: '📺', count: '900+', color: 'from-emerald/20 to-transparent', border: 'border-emerald/20 hover:border-emerald/40' },
  { name: 'Air Conditioners', slug: 'air-conditioners', emoji: '❄️', count: '650+', color: 'from-cyan/20 to-transparent', border: 'border-cyan/20 hover:border-cyan/40' },
  { name: 'Gaming PCs', slug: 'gaming-pcs', emoji: '🎮', count: '380+', color: 'from-rose/20 to-transparent', border: 'border-rose/20 hover:border-rose/40' },
  { name: 'Cameras', slug: 'cameras', emoji: '📷', count: '540+', color: 'from-amber/20 to-transparent', border: 'border-amber/20 hover:border-amber/40' },
  { name: 'Monitors', slug: 'monitors', emoji: '🖥️', count: '720+', color: 'from-violet/20 to-transparent', border: 'border-violet/20 hover:border-violet/40' },
  { name: 'Smartwatches', slug: 'smartwatches', emoji: '⌚', count: '480+', color: 'from-emerald/20 to-transparent', border: 'border-emerald/20 hover:border-emerald/40' },
  { name: 'Headphones', slug: 'headphones', emoji: '🎧', count: '1,100+', color: 'from-cyan/20 to-transparent', border: 'border-cyan/20 hover:border-cyan/40' },
  { name: 'Refrigerators', slug: 'refrigerators', emoji: '🧊', count: '440+', color: 'from-amber/20 to-transparent', border: 'border-amber/20 hover:border-amber/40' },
  { name: 'Washing Machines', slug: 'washing-machines', emoji: '🫧', count: '360+', color: 'from-violet/20 to-transparent', border: 'border-violet/20 hover:border-violet/40' },
  { name: 'Tablets', slug: 'tablets', emoji: '📱', count: '280+', color: 'from-rose/20 to-transparent', border: 'border-rose/20 hover:border-rose/40' },
];

export function CategoryGrid() {
  return (
    <section className="max-w-[1400px] mx-auto px-6 py-16">
      <div className="flex items-end justify-between mb-8">
        <div>
          <div className="section-label">Explore Categories</div>
          <h2 className="font-display font-extrabold text-3xl tracking-tight">Browse by Category</h2>
        </div>
        <Link href="/categories" className="btn-ghost text-sm hidden sm:block">View all →</Link>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
        {categories.map((cat, i) => (
          <motion.div
            key={cat.slug}
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.04, duration: 0.4 }}
          >
            <Link href={`/category/${cat.slug}`}
              className={`group flex flex-col items-center gap-3 p-5 rounded-2xl bg-gradient-to-b ${cat.color} border ${cat.border} transition-all duration-200 hover:-translate-y-0.5 hover:shadow-card text-center`}
            >
              <span className="text-3xl group-hover:scale-110 transition-transform duration-200">{cat.emoji}</span>
              <div>
                <div className="text-sm font-semibold text-text leading-tight">{cat.name}</div>
                <div className="text-2xs text-text-muted font-mono mt-0.5">{cat.count}</div>
              </div>
            </Link>
          </motion.div>
        ))}
      </div>
    </section>
  );
}
