export { TrendingSection } from './HomeSections';
