'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { motion } from 'framer-motion';
import { ArrowRight, Sparkles, Zap, TrendingUp } from 'lucide-react';

const stats = [
  { value: '2M+', label: 'Products Tracked' },
  { value: '50+', label: 'Sellers Compared' },
  { value: 'Live', label: 'Price Updates', live: true },
  { value: 'AI ✦', label: 'Powered Insights' },
];

const compareSample = {
  products: [
    { name: 'iPhone 16 Pro', emoji: '📱', price: '₹1,19,900', color: '#63b3ed' },
    { name: 'Samsung S24 Ultra', emoji: '📱', price: '₹1,29,999', color: '#9f7aea' },
  ],
  rows: [
    { label: 'Chipset', values: ['A18 Pro', 'SD 8 Gen 3'], best: 0 },
    { label: 'RAM', values: ['8 GB', '12 GB'], best: 1 },
    { label: 'Battery', values: ['3274 mAh', '5000 mAh'], best: 1 },
    { label: 'Camera', values: ['48 MP', '200 MP'], best: 1 },
    { label: 'AI Score', values: ['96/100', '91/100'], best: 0 },
  ],
  verdict: 'iPhone 16 Pro wins on performance & AI speed. Samsung leads on battery & camera resolution. Best for gaming: iPhone 16 Pro.',
};

export function HeroSection() {
  const [currentRow, setCurrentRow] = useState(0);

  useEffect(() => {
    const t = setInterval(() => setCurrentRow(r => (r + 1) % compareSample.rows.length), 1800);
    return () => clearInterval(t);
  }, []);

  return (
    <section className="relative min-h-[90vh] flex items-center overflow-hidden">
      <div className="max-w-[1400px] mx-auto px-6 w-full py-20 grid lg:grid-cols-2 gap-16 items-center">

        {/* Left — Copy */}
        <div>
          {/* Badge */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="inline-flex items-center gap-2 bg-cyan/[0.08] border border-cyan/20 rounded-full px-4 py-1.5 mb-8"
          >
            <span className="w-5 h-5 rounded-full bg-gradient-ai flex items-center justify-center text-[10px]">✦</span>
            <span className="font-mono text-xs tracking-wide text-cyan-bright">AI-Powered Electronics Intelligence · v1.0</span>
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="font-display font-extrabold text-[clamp(42px,7vw,88px)] leading-[1.0] tracking-[-2px] mb-6"
          >
            Compare<br />
            <span className="gradient-text">Smarter</span><br />
            with AI
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="text-lg text-text-muted font-light max-w-md leading-relaxed mb-10"
          >
            The most advanced electronics comparison platform. Live prices, benchmark intelligence, and AI-powered recommendations — all in one place.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
            className="flex flex-wrap gap-4 mb-14"
          >
            <Link href="/compare" className="btn-ai flex items-center gap-2 text-base px-7 py-3.5">
              <span>🔍</span> Start Comparing
              <ArrowRight size={16} />
            </Link>
            <Link href="/ai-assistant" className="btn-ghost flex items-center gap-2 text-base px-6 py-3.5">
              <Sparkles size={16} className="text-violet" />
              Ask AI Assistant
            </Link>
          </motion.div>

          {/* Stats */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.4 }}
            className="flex flex-wrap gap-8 pt-10 border-t border-border"
          >
            {stats.map((stat, i) => (
              <div key={i} className="text-left">
                <div className="font-display font-extrabold text-3xl tracking-tight text-text flex items-center gap-2">
                  {stat.value}
                  {stat.live && (
                    <span className="flex items-center gap-1.5 text-xs font-mono font-normal text-emerald">
                      <span className="live-dot" />
                    </span>
                  )}
                </div>
                <div className="text-2xs text-text-muted uppercase tracking-widest mt-1">{stat.label}</div>
              </div>
            ))}
          </motion.div>
        </div>

        {/* Right — Animated comparison card */}
        <motion.div
          initial={{ opacity: 0, x: 40 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.7, delay: 0.3 }}
          className="hidden lg:block"
        >
          <div className="glass border-border/50 rounded-3xl overflow-hidden shadow-card-hover">
            {/* Window chrome */}
            <div className="px-5 py-4 border-b border-border flex items-center gap-3">
              <div className="flex gap-1.5">
                <span className="w-3 h-3 rounded-full bg-[#ff5f57]" />
                <span className="w-3 h-3 rounded-full bg-[#febc2e]" />
                <span className="w-3 h-3 rounded-full bg-[#28c840]" />
              </div>
              <span className="font-mono text-xs text-text-muted ml-auto">aicomp.in/compare</span>
            </div>

            <div className="p-5">
              {/* Column headers */}
              <div className="grid grid-cols-3 gap-2 mb-3">
                <div />
                {compareSample.products.map((p, i) => (
                  <div key={i} className="bg-surface border border-border rounded-xl p-3 text-center">
                    <div className="text-2xl mb-1">{p.emoji}</div>
                    <div className="font-display font-bold text-xs text-text leading-tight">{p.name}</div>
                    <div className="font-mono text-2xs text-emerald mt-1">{p.price}</div>
                  </div>
                ))}
              </div>

              {/* Spec rows */}
              {compareSample.rows.map((row, ri) => (
                <motion.div
                  key={ri}
                  className={`grid grid-cols-3 gap-2 mb-1 rounded-lg p-1 transition-colors ${ri === currentRow ? 'bg-cyan/5' : ''}`}
                  animate={{ opacity: 1 }}
                >
                  <div className="text-2xs text-text-muted uppercase tracking-wider font-medium flex items-center px-2">{row.label}</div>
                  {row.values.map((val, vi) => (
                    <div key={vi} className={`px-3 py-2 rounded-lg text-xs font-mono text-center ${vi === row.best ? 'text-emerald font-bold' : 'text-text'}`}>
                      {val}
                    </div>
                  ))}
                </motion.div>
              ))}

              {/* AI verdict */}
              <div className="mt-4 p-3.5 rounded-xl bg-gradient-to-r from-cyan/[0.08] to-violet/[0.08] border border-cyan/15">
                <div className="flex items-center gap-2 mb-2">
                  <Sparkles size={14} className="text-cyan" />
                  <span className="font-mono text-2xs text-cyan uppercase tracking-wider">AI Verdict</span>
                </div>
                <p className="text-xs text-text leading-relaxed">{compareSample.verdict}</p>
              </div>
            </div>
          </div>

          {/* Floating cards */}
          <motion.div
            animate={{ y: [0, -8, 0] }}
            transition={{ duration: 4, repeat: Infinity, ease: 'easeInOut' }}
            className="absolute -bottom-4 -left-8 glass rounded-xl p-3 flex items-center gap-3 shadow-card border-emerald/20"
          >
            <TrendingUp size={16} className="text-emerald" />
            <div>
              <div className="text-xs font-semibold text-text">Price dropped!</div>
              <div className="text-2xs text-emerald font-mono">iPhone 16 Pro ↓ ₹5,000</div>
            </div>
          </motion.div>

          <motion.div
            animate={{ y: [0, 8, 0] }}
            transition={{ duration: 5, repeat: Infinity, ease: 'easeInOut', delay: 1 }}
            className="absolute -top-4 -right-4 glass rounded-xl p-3 flex items-center gap-3 shadow-card border-violet/20"
          >
            <Zap size={16} className="text-violet" />
            <div>
              <div className="text-xs font-semibold text-text">AI Score</div>
              <div className="text-2xs text-violet-bright font-mono">Gaming: 96/100</div>
            </div>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}
