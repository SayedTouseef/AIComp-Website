'use client';

import Link from 'next/link';

const COLS = {
  'Platform': [
    { label:'Compare',     href:'/compare' },
    { label:'AI Assistant',href:'/ai-assistant' },
    { label:'PC Builder',  href:'/pc-builder' },
    { label:'Price Alerts',href:'/alerts' },
    { label:'Deals',       href:'/deals' },
  ],
  'Categories': [
    { label:'Smartphones', href:'/category/smartphones' },
    { label:'Laptops',     href:'/category/laptops' },
    { label:'TVs',         href:'/category/tvs' },
    { label:'ACs',         href:'/category/air-conditioners' },
    { label:'Gaming PCs',  href:'/category/gaming-pcs' },
    { label:'All →',       href:'/categories' },
  ],
  'Resources': [
    { label:'Buying Guides',href:'/guides' },
    { label:'Gaming Zone', href:'/gaming' },
    { label:'New Launches',href:'/launches' },
    { label:'Top Rated',   href:'/top-rated' },
    { label:'Trending',    href:'/trending' },
  ],
  'Company': [
    { label:'About',          href:'/about' },
    { label:'Contact',        href:'/contact' },
    { label:'Privacy Policy', href:'/privacy' },
    { label:'Terms of Use',   href:'/terms' },
    { label:'Sitemap',        href:'/sitemap.xml' },
  ],
};

export function SiteFooter() {
  return (
    <footer className="site-footer" style={{ background: 'var(--nav-bg)', borderTop: '2px solid var(--nav-border)', marginTop: 0 }}>
      {/* Ad leaderboard in footer */}
      <div style={{ borderBottom: '1px solid rgba(255,255,255,0.08)', display: 'flex', alignItems: 'center', justifyContent: 'center', height: 70, gap: 8 }}>
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,0.3)" strokeWidth="1.5">
          <rect x="3" y="3" width="18" height="18" rx="2" /><path d="M3 9h18M9 21V9" />
        </svg>
        <span style={{ color: 'rgba(255,255,255,0.3)', fontSize: 11, textTransform: 'uppercase', letterSpacing: '0.06em' }}>728×90 Footer Advertisement</span>
      </div>

      {/* Main footer */}
      <div style={{ maxWidth: 1400, margin: '0 auto', padding: '32px 16px 24px' }}>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr repeat(4, auto)', gap: 32, marginBottom: 32 }}>
          {/* Brand */}
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 12 }}>
              <div style={{ width: 28, height: 28, background: '#fff', borderRadius: 3, display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: '"Roboto Condensed",sans-serif', fontWeight: 700, fontSize: 10, color: '#1a6bc7' }}>AI</div>
              <span style={{ fontFamily: '"Roboto Condensed",sans-serif', fontWeight: 700, fontSize: 18, color: '#fff' }}>AIComp</span>
            </div>
            <p style={{ color: 'rgba(255,255,255,0.5)', fontSize: 12, lineHeight: 1.6, maxWidth: 220 }}>
              India&apos;s most comprehensive electronics comparison platform. AI-powered specs, live prices, and smart recommendations.
            </p>
            <div style={{ marginTop: 12, display: 'flex', gap: 6 }}>
              <span className="live-dot" style={{ marginTop: 2 }} />
              <span style={{ color: 'rgba(255,255,255,0.4)', fontSize: 11 }}>Prices updated every 4h</span>
            </div>
          </div>

          {/* Link columns */}
          {Object.entries(COLS).map(([title, links]) => (
            <div key={title}>
              <div style={{ color: 'rgba(255,255,255,0.9)', fontSize: 12, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 10 }}>
                {title}
              </div>
              <ul style={{ listStyle: 'none', display: 'flex', flexDirection: 'column', gap: 5 }}>
                {links.map(({ label, href }) => (
                  <li key={label}>
                    <Link href={href} style={{ color: 'rgba(255,255,255,0.45)', fontSize: 12, textDecoration: 'none', transition: 'color 0.1s' }}
                      onMouseEnter={e => (e.currentTarget.style.color = 'rgba(255,255,255,0.9)')}
                      onMouseLeave={e => (e.currentTarget.style.color = 'rgba(255,255,255,0.45)')}
                    >
                      {label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Bottom bar */}
        <div style={{ borderTop: '1px solid rgba(255,255,255,0.08)', paddingTop: 16, display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 8 }}>
          <span style={{ color: 'rgba(255,255,255,0.3)', fontSize: 11 }}>
            © {new Date().getFullYear()} AIComp Technologies Pvt. Ltd. · Made in India 🇮🇳 · Prices include affiliate links
          </span>
          <div style={{ display: 'flex', gap: 16 }}>
            {[['Privacy','/privacy'],['Terms','/terms'],['Contact','/contact']].map(([l,h]) => (
              <Link key={l} href={h} style={{ color: 'rgba(255,255,255,0.3)', fontSize: 11 }}
                onMouseEnter={e => (e.currentTarget.style.color = 'rgba(255,255,255,0.7)')}
                onMouseLeave={e => (e.currentTarget.style.color = 'rgba(255,255,255,0.3)')}
              >{l}</Link>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
}
