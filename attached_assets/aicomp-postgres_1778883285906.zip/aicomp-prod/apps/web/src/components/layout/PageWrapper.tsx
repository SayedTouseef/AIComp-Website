import { Navbar } from './Navbar';
import { Footer } from './Footer';

export function PageWrapper({ children }: { children: React.ReactNode }) {
  return (
    <>
      <Navbar />
      <main className="pt-16 flex-1">{children}</main>
      <Footer />
    </>
  );
}
