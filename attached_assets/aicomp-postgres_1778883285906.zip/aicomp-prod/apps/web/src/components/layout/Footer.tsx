// Footer is now SiteFooter — this file is kept for backward compatibility
export function Footer() { return null; }
