// Navbar is now SiteHeader — this file is kept for backward compatibility
export function Navbar() { return null; }
