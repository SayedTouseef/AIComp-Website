'use client';

import { useState, useEffect, useRef } from 'react';
import Link from 'next/link';
import { useTheme } from 'next-themes';
import { Sun, Moon, Monitor, Search, Bell, User, ChevronDown, X } from 'lucide-react';
import { useDebounce } from '@/hooks/useDebounce';

const API = process.env.NEXT_PUBLIC_API_URL ?? 'http://localhost:4000';

function ThemeToggle() {
  const { theme, setTheme } = useTheme();
  const [mounted, setMounted] = useState(false);
  const [open, setOpen] = useState(false);
  useEffect(() => setMounted(true), []);
  if (!mounted) return <div style={{ width: 26, height: 26 }} />;

  const icons: Record<string, React.ReactNode> = {
    light:  <Sun size={14} />,
    dark:   <Moon size={14} />,
    system: <Monitor size={14} />,
  };
  const cur = theme ?? 'dark';

  return (
    <div style={{ position: 'relative' }}>
      <button
        onClick={() => setOpen(!open)}
        title={`Theme: ${cur}`}
        style={{
          display: 'flex', alignItems: 'center', gap: 4,
          background: 'rgba(255,255,255,0.1)', border: '1px solid rgba(255,255,255,0.2)',
          borderRadius: 4, padding: '4px 8px', cursor: 'pointer', color: '#fff', fontSize: 12,
        }}
      >
        {icons[cur] ?? <Moon size={14} />}
        <ChevronDown size={10} />
      </button>

      {open && (
        <div style={{
          position: 'absolute', top: '110%', right: 0, zIndex: 999,
          background: 'var(--card)', border: '1px solid var(--border)',
          borderRadius: 6, minWidth: 120, boxShadow: 'var(--shadow-lg)',
          overflow: 'hidden',
        }}>
          {[
            { value: 'light',  label: 'Light',  Icon: Sun },
            { value: 'dark',   label: 'Dark',   Icon: Moon },
            { value: 'system', label: 'System', Icon: Monitor },
          ].map(({ value, label, Icon }) => (
            <button
              key={value}
              onClick={() => { setTheme(value); setOpen(false); }}
              style={{
                width: '100%', display: 'flex', alignItems: 'center', gap: 8,
                padding: '8px 12px', fontSize: 12, cursor: 'pointer', border: 'none',
                background: cur === value ? 'var(--blue-bg)' : 'transparent',
                color: cur === value ? 'var(--blue)' : 'var(--text)',
                fontWeight: cur === value ? 600 : 400,
              }}
            >
              <Icon size={13} /> {label}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

function QuickSearch() {
  const [q, setQ] = useState('');
  const [results, setResults] = useState<any[]>([]);
  const [open, setOpen] = useState(false);
  const debounced = useDebounce(q, 280);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!debounced || debounced.length < 2) { setResults([]); return; }
    fetch(`${API}/api/v1/search/autocomplete?q=${encodeURIComponent(debounced)}`)
      .then(r => r.json()).then(d => setResults(d.results ?? [])).catch(() => {});
  }, [debounced]);

  useEffect(() => {
    const fn = (e: MouseEvent) => { if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false); };
    document.addEventListener('mousedown', fn);
    return () => document.removeEventListener('mousedown', fn);
  }, []);

  return (
    <div ref={ref} style={{ position: 'relative', flex: 1, maxWidth: 460 }}>
      <div style={{ display: 'flex', background: 'rgba(255,255,255,0.12)', border: '1px solid rgba(255,255,255,0.2)', borderRadius: 4, overflow: 'hidden' }}>
        <input
          value={q}
          onChange={e => { setQ(e.target.value); setOpen(true); }}
          onFocus={() => setOpen(true)}
          placeholder="Search phones, laptops, TVs..."
          style={{ flex: 1, background: 'transparent', border: 'none', outline: 'none', padding: '7px 12px', fontSize: 13, color: '#fff' }}
        />
        {q && (
          <button onClick={() => { setQ(''); setResults([]); }} style={{ background: 'transparent', border: 'none', padding: '0 8px', cursor: 'pointer', color: 'rgba(255,255,255,0.6)' }}>
            <X size={14} />
          </button>
        )}
        <button
          onClick={() => { if (q.trim()) window.location.href = `/search?q=${encodeURIComponent(q.trim())}`; }}
          style={{ background: 'rgba(0,0,0,0.3)', border: 'none', padding: '0 14px', cursor: 'pointer', color: '#fff' }}
        >
          <Search size={15} />
        </button>
      </div>

      {open && results.length > 0 && (
        <div style={{
          position: 'absolute', top: '110%', left: 0, right: 0, zIndex: 999,
          background: 'var(--card)', border: '1px solid var(--border)',
          borderRadius: 6, boxShadow: 'var(--shadow-lg)', overflow: 'hidden',
        }}>
          {results.slice(0, 7).map((r: any, i: number) => (
            <a key={i} href={`/product/${r.slug}`}
              style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '8px 12px', borderBottom: '1px solid var(--divider)', color: 'var(--text)' }}
              onMouseEnter={e => (e.currentTarget.style.background = 'var(--surface2)')}
              onMouseLeave={e => (e.currentTarget.style.background = '')}
            >
              {r.image
                ? <img src={r.image} alt="" style={{ width: 32, height: 32, objectFit: 'contain', flexShrink: 0, background: 'var(--surface)' }} />
                : <div style={{ width: 32, height: 32, background: 'var(--surface)', borderRadius: 3, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 14 }}>📦</div>
              }
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 13, fontWeight: 600, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{r.name}</div>
                {r.category && <div style={{ fontSize: 11, color: 'var(--text-muted)' }}>{r.category}</div>}
              </div>
              {r.price && <div style={{ fontSize: 12, fontWeight: 700, color: 'var(--green)', flexShrink: 0 }}>{r.price}</div>}
            </a>
          ))}
          <a href={`/search?q=${encodeURIComponent(q)}`} style={{ display: 'block', textAlign: 'center', padding: '8px', fontSize: 12, color: 'var(--blue)', borderTop: '1px solid var(--divider)', background: 'var(--surface)' }}>
            See all results for &ldquo;{q}&rdquo; →
          </a>
        </div>
      )}
    </div>
  );
}

export function SiteHeader() {
  return (
    <header className="site-header" style={{ background: 'var(--nav-bg)', borderBottom: '2px solid var(--nav-border)', position: 'sticky', top: 0, zIndex: 100 }}>
      {/* Top bar */}
      <div style={{ maxWidth: 1400, margin: '0 auto', padding: '0 16px', height: 44, display: 'flex', alignItems: 'center', gap: 16 }}>

        {/* Logo */}
        <Link href="/" style={{ display: 'flex', alignItems: 'center', gap: 8, flexShrink: 0, textDecoration: 'none' }}>
          <div style={{ width: 30, height: 30, background: '#fff', borderRadius: 4, display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: '"Roboto Condensed",sans-serif', fontWeight: 700, fontSize: 11, color: 'var(--blue-dark)', letterSpacing: '0.02em' }}>
            AI
          </div>
          <span style={{ fontFamily: '"Roboto Condensed",sans-serif', fontWeight: 700, fontSize: 20, color: '#fff', letterSpacing: '-0.01em' }}>
            AIComp
          </span>
        </Link>

        {/* Search */}
        <QuickSearch />

        {/* Right actions */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexShrink: 0, marginLeft: 'auto' }}>
          <ThemeToggle />

          <a href="/alerts" style={{ display: 'flex', alignItems: 'center', gap: 4, color: 'rgba(255,255,255,0.8)', fontSize: 12, padding: '4px 8px', borderRadius: 4, background: 'rgba(255,255,255,0.08)' }}>
            <Bell size={13} />
            <span className="hidden sm:block">Alerts</span>
          </a>

          <a href="/auth/signin" style={{ display: 'flex', alignItems: 'center', gap: 4, color: 'rgba(255,255,255,0.8)', fontSize: 12, padding: '4px 8px', borderRadius: 4, background: 'rgba(255,255,255,0.08)' }}>
            <User size={13} />
            <span className="hidden sm:block">Sign In</span>
          </a>
        </div>
      </div>
    </header>
  );
}
