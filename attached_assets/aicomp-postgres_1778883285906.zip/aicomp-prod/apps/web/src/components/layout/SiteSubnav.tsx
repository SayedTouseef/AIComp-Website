'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';

const CATS = [
  { label: 'Smartphones', href: '/category/smartphones', emoji: '📱' },
  { label: 'Laptops',     href: '/category/laptops',     emoji: '💻' },
  { label: 'TVs',         href: '/category/tvs',         emoji: '📺' },
  { label: 'ACs',         href: '/category/air-conditioners', emoji: '❄️' },
  { label: 'GPUs',        href: '/category/gpus',         emoji: '🖥️' },
  { label: 'Cameras',     href: '/category/cameras',      emoji: '📷' },
  { label: 'Headphones',  href: '/category/headphones',   emoji: '🎧' },
  { label: 'Smartwatches',href: '/category/smartwatches', emoji: '⌚' },
];

const NAVLINKS = [
  { label: 'Compare',    href: '/compare' },
  { label: 'Deals',      href: '/deals' },
  { label: 'Gaming',     href: '/gaming' },
  { label: 'PC Builder', href: '/pc-builder' },
  { label: 'AI Chat',    href: '/ai-assistant' },
  { label: 'Launches',   href: '/launches' },
  { label: 'Guides',     href: '/guides' },
];

export function SiteSubnav() {
  const pathname = usePathname();
  const isActive = (href: string) => pathname === href || pathname.startsWith(href + '/');

  return (
    <nav className="site-subnav" style={{ background: 'var(--subnav-bg)', borderBottom: '1px solid var(--border)', position: 'sticky', top: 44, zIndex: 90 }}>
      <div style={{ maxWidth: 1400, margin: '0 auto', padding: '0 16px', display: 'flex', alignItems: 'center', overflowX: 'auto', gap: 0 }} className="scrollbar-none">

        {/* Category pills */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 2, padding: '5px 0', borderRight: '1px solid var(--border)', paddingRight: 10, marginRight: 10, flexShrink: 0 }}>
          {CATS.map(c => (
            <Link key={c.href} href={c.href}
              style={{
                display: 'flex', alignItems: 'center', gap: 4,
                padding: '3px 9px', borderRadius: 3, fontSize: 12, fontWeight: 500,
                whiteSpace: 'nowrap', textDecoration: 'none',
                background: isActive(c.href) ? 'var(--blue)' : 'transparent',
                color: isActive(c.href) ? '#fff' : 'var(--text-muted)',
                transition: 'all 0.1s',
              }}
              onMouseEnter={e => { if (!isActive(c.href)) (e.currentTarget.style.background = 'var(--surface2)'); }}
              onMouseLeave={e => { if (!isActive(c.href)) (e.currentTarget.style.background = 'transparent'); }}
            >
              <span style={{ fontSize: 13 }}>{c.emoji}</span>
              {c.label}
            </Link>
          ))}
        </div>

        {/* Section links */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 2, padding: '5px 0', flexShrink: 0 }}>
          {NAVLINKS.map(n => (
            <Link key={n.href} href={n.href}
              style={{
                display: 'flex', alignItems: 'center',
                padding: '3px 9px', borderRadius: 3, fontSize: 12, fontWeight: 500,
                whiteSpace: 'nowrap', textDecoration: 'none',
                background: isActive(n.href) ? 'var(--blue)' : 'transparent',
                color: isActive(n.href) ? '#fff' : 'var(--text-muted)',
                transition: 'all 0.1s',
              }}
              onMouseEnter={e => { if (!isActive(n.href)) (e.currentTarget.style.background = 'var(--surface2)'); }}
              onMouseLeave={e => { if (!isActive(n.href)) (e.currentTarget.style.background = 'transparent'); }}
            >
              {n.label}
            </Link>
          ))}
        </div>
      </div>
    </nav>
  );
}
