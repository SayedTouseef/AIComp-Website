'use client';

import { useState, useEffect, useRef, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, Mic, Sparkles, X, Clock, TrendingUp, ArrowRight } from 'lucide-react';
import { cn } from '@/lib/utils';
import { useDebounce } from '@/hooks/useDebounce';

const SUGGESTIONS = [
  'Best gaming laptop under ₹80,000',
  'Best AC for 200 sq ft room',
  'iPhone 16 Pro vs Samsung S24 Ultra',
  'Best camera phone for YouTube',
  'Gaming PC build under ₹1,00,000',
  'Best 4K TV under ₹50,000',
  'Best earbuds under ₹5,000',
  'Best refrigerator for 4 person family',
];

const TRENDING = [
  { query: 'iPhone 16 Pro', trend: '+234%' },
  { query: 'MacBook M4', trend: '+189%' },
  { query: 'Samsung S24 Ultra', trend: '+145%' },
  { query: 'PS5 Slim', trend: '+98%' },
  { query: 'Daikin 1.5 Ton AC', trend: '+76%' },
];

interface SearchBarProps {
  fullPage?: boolean;
  autoFocus?: boolean;
  onClose?: () => void;
}

export function SearchBar({ fullPage, autoFocus, onClose }: SearchBarProps) {
  const [query, setQuery] = useState('');
  const [focused, setFocused] = useState(false);
  const [results, setResults] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [aiMode, setAiMode] = useState(true);
  const [placeholderIndex, setPlaceholderIndex] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);
  const router = useRouter();
  const debouncedQuery = useDebounce(query, 300);

  // Rotate placeholder
  useEffect(() => {
    const t = setInterval(() => setPlaceholderIndex(i => (i + 1) % SUGGESTIONS.length), 3500);
    return () => clearInterval(t);
  }, []);

  // Autofocus
  useEffect(() => {
    if (autoFocus) inputRef.current?.focus();
  }, [autoFocus]);

  // Fetch autocomplete
  useEffect(() => {
    if (!debouncedQuery || debouncedQuery.length < 2) { setResults([]); return; }
    setIsLoading(true);
    fetch(`/api/search/autocomplete?q=${encodeURIComponent(debouncedQuery)}`)
      .then(r => r.json())
      .then(data => setResults(data.results || []))
      .catch(() => setResults([]))
      .finally(() => setIsLoading(false));
  }, [debouncedQuery]);

  const handleSubmit = useCallback((q?: string) => {
    const searchQuery = q || query;
    if (!searchQuery.trim()) return;
    const mode = aiMode ? 'ai' : 'search';
    router.push(`/search?q=${encodeURIComponent(searchQuery)}&mode=${mode}`);
    onClose?.();
  }, [query, aiMode, router, onClose]);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') handleSubmit();
    if (e.key === 'Escape') { onClose?.(); setFocused(false); }
  };

  const showDropdown = focused && (query.length > 0 ? results.length > 0 : true);

  return (
    <div className={cn('relative', fullPage ? 'max-w-3xl mx-auto px-6' : 'w-full')}>
      {/* Input wrapper */}
      <motion.div
        animate={focused ? { boxShadow: '0 0 0 4px rgba(99,179,237,0.1)' } : { boxShadow: '0 0 0 0px rgba(99,179,237,0)' }}
        className={cn(
          'flex items-center gap-3 glass rounded-2xl border transition-colors duration-200',
          focused ? 'border-cyan/40' : 'border-border'
        )}
      >
        {/* AI toggle */}
        <button
          onClick={() => setAiMode(!aiMode)}
          className={cn(
            'ml-3 flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-mono font-bold transition-all flex-shrink-0',
            aiMode ? 'bg-gradient-ai text-white' : 'text-text-muted border border-border'
          )}
        >
          <Sparkles size={11} />
          {aiMode ? 'AI' : 'Search'}
        </button>

        <input
          ref={inputRef}
          value={query}
          onChange={e => setQuery(e.target.value)}
          onFocus={() => setFocused(true)}
          onBlur={() => setTimeout(() => setFocused(false), 200)}
          onKeyDown={handleKeyDown}
          placeholder={SUGGESTIONS[placeholderIndex]}
          className="flex-1 bg-transparent border-none outline-none text-text placeholder-text-dim text-base py-4"
        />

        {/* Clear */}
        {query && (
          <button onClick={() => setQuery('')} className="text-text-dim hover:text-text-muted transition-colors">
            <X size={16} />
          </button>
        )}

        {/* Voice */}
        <button className="text-text-dim hover:text-violet transition-colors" aria-label="Voice search">
          <Mic size={18} />
        </button>

        {/* Search button */}
        <button
          onClick={() => handleSubmit()}
          className="btn-ai flex items-center gap-2 px-5 py-3 m-1.5 rounded-xl text-sm flex-shrink-0"
        >
          {aiMode ? <><Sparkles size={14} /> Ask AI</> : <><Search size={14} /> Search</>}
        </button>
      </motion.div>

      {/* Chips */}
      {fullPage && !focused && (
        <div className="flex flex-wrap items-center gap-2 mt-4">
          <span className="text-xs text-text-dim">Try:</span>
          {['Best AC for 200 sq ft', 'Gaming PC under ₹1L', 'Best camera phone', '4K TV under ₹50K'].map(chip => (
            <button
              key={chip}
              onClick={() => { setQuery(chip); handleSubmit(chip); }}
              className="text-xs text-text-muted border border-border rounded-full px-3 py-1.5 hover:border-border-glow hover:text-cyan-bright hover:bg-cyan/5 transition-all"
            >
              {chip}
            </button>
          ))}
        </div>
      )}

      {/* Dropdown */}
      <AnimatePresence>
        {showDropdown && (
          <motion.div
            initial={{ opacity: 0, y: 6 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 6 }}
            transition={{ duration: 0.15 }}
            className="absolute top-full left-0 right-0 mt-2 glass border-border-glow rounded-2xl overflow-hidden z-50 shadow-card"
          >
            {/* Loading skeleton */}
            {isLoading && (
              <div className="p-4 space-y-2">
                {[1,2,3].map(i => (
                  <div key={i} className="h-10 rounded-lg bg-surface animate-pulse" />
                ))}
              </div>
            )}

            {/* Results */}
            {!isLoading && results.length > 0 && (
              <div className="p-2">
                {results.map((r: any, i: number) => (
                  <button
                    key={i}
                    onClick={() => handleSubmit(r.query || r.name)}
                    className="w-full flex items-center gap-3 px-4 py-3 rounded-xl hover:bg-surface-hover transition-colors text-left"
                  >
                    {r.image && <img src={r.image} alt="" className="w-10 h-10 object-contain rounded-lg" />}
                    <div className="flex-1">
                      <div className="text-sm text-text">{r.name || r.query}</div>
                      {r.category && <div className="text-xs text-text-muted">{r.category}</div>}
                    </div>
                    {r.price && <div className="text-sm font-mono text-emerald">{r.price}</div>}
                    <ArrowRight size={14} className="text-text-dim" />
                  </button>
                ))}
              </div>
            )}

            {/* Empty — show trending */}
            {!isLoading && results.length === 0 && !query && (
              <div className="p-4">
                <div className="section-label mb-3">🔥 Trending Searches</div>
                {TRENDING.map((t, i) => (
                  <button
                    key={i}
                    onClick={() => handleSubmit(t.query)}
                    className="w-full flex items-center justify-between px-3 py-2.5 rounded-xl hover:bg-surface-hover transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      <TrendingUp size={14} className="text-text-muted" />
                      <span className="text-sm text-text">{t.query}</span>
                    </div>
                    <span className="text-xs font-mono text-emerald">{t.trend}</span>
                  </button>
                ))}
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
