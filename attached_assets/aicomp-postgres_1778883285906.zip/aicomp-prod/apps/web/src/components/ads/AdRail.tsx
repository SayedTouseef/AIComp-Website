'use client';

interface AdRailProps { side: 'left' | 'right'; }

function AdSlotIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" style={{ opacity: 0.4 }}>
      <rect x="3" y="3" width="18" height="18" rx="2" />
      <path d="M3 9h18M9 21V9" />
    </svg>
  );
}

export function AdRail({ side }: AdRailProps) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '10px', padding: '8px' }}>
      {/* Skyscraper 160×600 */}
      <div className="ad-slot ad-slot-160x600">
        <AdSlotIcon />
        <span>160×600</span>
        <span style={{ fontSize: 9, marginTop: 2 }}>Advertisement</span>
      </div>

      {/* Half page 160×320 */}
      <div className="ad-slot ad-slot-160x320">
        <AdSlotIcon />
        <span>160×320</span>
        <span style={{ fontSize: 9, marginTop: 2 }}>Advertisement</span>
      </div>
    </div>
  );
}

// Leaderboard banner for inside content areas
export function AdLeaderboard() {
  return (
    <div className="ad-leaderboard">
      <AdSlotIcon />
      <span>728×90 — Leaderboard Advertisement</span>
    </div>
  );
}

// Medium Rectangle 300×250
export function AdRectangle() {
  return (
    <div className="ad-rectangle">
      <AdSlotIcon />
      <span style={{ fontSize: 10 }}>300×250</span>
      <span style={{ fontSize: 9, marginTop: 2, color: 'var(--text-dim)' }}>Advertisement</span>
    </div>
  );
}
