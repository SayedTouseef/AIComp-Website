'use client';
import Link from 'next/link';
import { Zap } from 'lucide-react';
import { useFlashDeals } from '@/hooks/useApi';
import { formatPrice } from '@/lib/utils';

export function LiveDeals() {
  const { data } = useFlashDeals();
  const deals = data?.deals?.slice(0, 4) || [];
  if (deals.length === 0) return null;
  return (
    <section className="max-w-[1400px] mx-auto px-6 py-10">
      <div className="flex items-center justify-between mb-5">
        <div className="flex items-center gap-2">
          <div className="live-dot" />
          <span className="font-display font-bold text-2xl">Live Deals</span>
        </div>
        <Link href="/deals" className="btn-ghost text-sm">View all →</Link>
      </div>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {deals.map((d: any, i: number) => {
          const price = d.prices?.[0];
          return (
            <Link key={i} href={`/product/${d.slug}`} className="glass-hover rounded-2xl p-4 flex flex-col gap-3">
              <div className="text-3xl text-center py-2">{d.category?.emoji || '📦'}</div>
              <div className="text-xs text-text-muted">{d.brand?.name}</div>
              <div className="text-sm font-semibold text-text line-clamp-2">{d.name}</div>
              {price && <div className="font-mono font-bold text-emerald">{formatPrice(price.price)}</div>}
              {price?.discount && <div className="badge-emerald text-2xs w-fit">{price.discount}% off</div>}
            </Link>
          );
        })}
      </div>
    </section>
  );
}
