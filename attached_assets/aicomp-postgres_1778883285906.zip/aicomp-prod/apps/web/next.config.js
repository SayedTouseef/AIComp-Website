/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  images: {
    formats: ['image/avif', 'image/webp'],
    remotePatterns: [
      { protocol: 'https', hostname: 'm.media-amazon.com' },
      { protocol: 'https', hostname: 'rukminim2.flixcart.com' },
      { protocol: 'https', hostname: 'images.croma.com' },
      { protocol: 'https', hostname: '**.cloudinary.com' },
    ],
  },
  async redirects() {
    return [
      { source: '/product/:slug', destination: '/products/:slug', permanent: true },
      { source: '/launches',      destination: '/new-launches',    permanent: false },
      { source: '/privacy',       destination: '/privacy-policy',  permanent: false },
    ];
  },
  poweredByHeader: false,
};
module.exports = nextConfig;
