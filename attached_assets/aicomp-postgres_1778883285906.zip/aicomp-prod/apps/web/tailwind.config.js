/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./src/**/*.{js,ts,jsx,tsx,mdx}'],
  darkMode: 'class',
  theme: {
    extend: {
      fontFamily: {
        body:      ['"Noto Sans"', 'system-ui', 'sans-serif'],
        condensed: ['"Roboto Condensed"', 'sans-serif'],
        mono:      ['"Roboto Mono"', 'monospace'],
        sans:      ['"Noto Sans"', 'system-ui', 'sans-serif'],
      },
      colors: {
        blue:    { DEFAULT: '#4a9eff', hover: '#63adff', dark: '#1a6bc7' },
        green:   '#3db87a',
        orange:  '#f0883e',
        yellow:  '#d4a82a',
        red:     '#e05c5c',
      },
      maxWidth: { site: '1400px' },
      screens: {
        xs: '480px',
      },
    },
  },
  plugins: [],
};
