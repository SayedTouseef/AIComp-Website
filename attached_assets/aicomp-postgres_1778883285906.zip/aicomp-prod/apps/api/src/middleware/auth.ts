import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();
const JWT_SECRET = process.env.JWT_SECRET || 'aicomp-dev-secret-change-in-prod';

export interface AuthRequest extends Request {
  user?: { id: string; email: string; role: string };
}

export async function authMiddleware(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const header = req.headers.authorization;
    if (!header?.startsWith('Bearer ')) {
      return res.status(401).json({ error: 'No token provided' });
    }
    const token = header.slice(7);
    const payload = jwt.verify(token, JWT_SECRET) as any;

    // Optionally verify session in DB
    const session = await prisma.userSession.findUnique({
      where: { token },
      include: { user: { select: { id: true, email: true, role: true, isBanned: true } } },
    });

    if (!session || session.expiresAt < new Date()) {
      return res.status(401).json({ error: 'Session expired' });
    }
    if (session.user.isBanned) {
      return res.status(403).json({ error: 'Account suspended' });
    }

    req.user = { id: session.user.id, email: session.user.email, role: session.user.role };
    next();
  } catch {
    return res.status(401).json({ error: 'Invalid token' });
  }
}

export function optionalAuth(req: AuthRequest, res: Response, next: NextFunction) {
  const header = req.headers.authorization;
  if (!header?.startsWith('Bearer ')) return next();
  try {
    const token = header.slice(7);
    const payload = jwt.verify(token, JWT_SECRET) as any;
    req.user = payload;
  } catch {}
  next();
}

export function requireAdmin(req: AuthRequest, res: Response, next: NextFunction) {
  if (!req.user) return res.status(401).json({ error: 'Unauthorized' });
  const adminRoles = ['SUPER_ADMIN', 'PRODUCT_MANAGER', 'CONTENT_MANAGER', 'SEO_MANAGER'];
  if (!adminRoles.includes(req.user.role)) {
    return res.status(403).json({ error: 'Insufficient permissions' });
  }
  next();
}

export function requireSuperAdmin(req: AuthRequest, res: Response, next: NextFunction) {
  if (!req.user || req.user.role !== 'SUPER_ADMIN') {
    return res.status(403).json({ error: 'Super admin only' });
  }
  next();
}

export function generateToken(userId: string, email: string, role: string): string {
  return jwt.sign({ id: userId, email, role }, JWT_SECRET, { expiresIn: '30d' });
}
