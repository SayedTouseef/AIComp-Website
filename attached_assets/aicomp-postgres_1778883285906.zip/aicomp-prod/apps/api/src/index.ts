/**
 * AIComp API — Standalone Express server using pg directly (no Prisma binary).
 * Run: npx tsx src/index.ts
 */
import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import compression from 'compression';
import { Pool } from 'pg';
import { rateLimit } from 'express-rate-limit';

const app = express();
const PORT = parseInt(process.env.PORT || '4000');

// ─── Database ─────────────────────────────────────────────
const pool = new Pool({
  connectionString: process.env.DATABASE_URL || 'postgresql://postgres:admin123@localhost:5432/aicomp',
  max: 20,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 5000,
});
pool.on('error', (err) => console.error('[DB] Pool error:', err.message));

// ─── Middleware ────────────────────────────────────────────
app.set('trust proxy', 1);
app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors({
  origin: [
    process.env.WEB_URL   || 'http://localhost:3000',
    process.env.ADMIN_URL || 'http://localhost:3001',
    'https://aicomp.in',
    'https://admin.aicomp.in',
    'https://www.aicomp.in',
  ],
  credentials: true,
}));
app.use(compression() as any);
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// Global rate limiter
app.use('/api/', rateLimit({ windowMs: 15*60*1000, max: 500, standardHeaders: true, legacyHeaders: false }));
// Stricter AI limiter
const aiLimiter = rateLimit({ windowMs: 60*1000, max: 20, message: { error: 'AI rate limit — try again in a minute.' } });

// ─── Request logging (simple) ─────────────────────────────
app.use((req, _res, next) => {
  if (process.env.NODE_ENV !== 'production') {
    console.log(`${new Date().toISOString().slice(11,19)} ${req.method} ${req.path}`);
  }
  next();
});

// ─────────────────────────────────────────────────────────
// HEALTH
// ─────────────────────────────────────────────────────────
app.get('/health', async (_req, res) => {
  try {
    await pool.query('SELECT 1');
    res.json({ status: 'ok', db: 'connected', version: '1.0.0', uptime: Math.round(process.uptime()) });
  } catch {
    res.status(500).json({ status: 'error', db: 'disconnected' });
  }
});

// ─────────────────────────────────────────────────────────
// CATEGORIES
// ─────────────────────────────────────────────────────────
app.get('/api/v1/categories', async (_req, res) => {
  try {
    const { rows } = await pool.query(`
      SELECT c.id, c.name, c.slug, c.emoji, c.description, c.image, c.sort_order,
        (SELECT COUNT(*)::int FROM products p WHERE p.category_id = c.id AND p.status = 'APPROVED') AS product_count
      FROM categories c
      WHERE c.is_active = true AND c.parent_id IS NULL
      ORDER BY c.sort_order, c.name
    `);
    res.json({ categories: rows });
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

app.get('/api/v1/categories/:slug', async (req, res) => {
  try {
    const { rows } = await pool.query(`
      SELECT c.*, 
        (SELECT COUNT(*)::int FROM products p WHERE p.category_id = c.id AND p.status = 'APPROVED') AS product_count,
        (SELECT json_agg(a.*) FROM category_attributes a WHERE a.category_id = c.id ORDER BY a.sort_order) AS attributes
      FROM categories c WHERE c.slug = $1
    `, [req.params.slug]);
    if (!rows[0]) return res.status(404).json({ error: 'Category not found' });
    res.json({ category: rows[0] });
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

// ─────────────────────────────────────────────────────────
// PRODUCTS
// ─────────────────────────────────────────────────────────
app.get('/api/v1/products', async (req, res) => {
  try {
    const { category, brand, sort = 'popular', page = '1', limit = '24', q } = req.query;
    const pageNum = Math.max(1, parseInt(page as string));
    const limitNum = Math.min(100, parseInt(limit as string));
    const offset = (pageNum - 1) * limitNum;

    const conditions = ["p.status = 'APPROVED'"];
    const params: any[] = [];
    let pi = 1;

    if (category) { conditions.push(`c.slug = $${pi++}`); params.push(category); }
    if (brand)    { conditions.push(`b.slug = $${pi++}`); params.push(brand); }
    if (q)        { conditions.push(`(p.name ILIKE $${pi} OR b.name ILIKE $${pi})`); params.push(`%${q}%`); pi++; }

    const orderMap: Record<string,string> = {
      popular:    'p.view_count DESC, p.avg_rating DESC',
      newest:     'p.created_at DESC',
      price_asc:  'MIN(pp.price) ASC NULLS LAST',
      price_desc: 'MIN(pp.price) DESC NULLS LAST',
      rating:     'p.avg_rating DESC',
      trending:   'p.is_trending DESC, p.view_count DESC',
    };
    const order = orderMap[sort as string] || 'p.view_count DESC';
    const where = conditions.join(' AND ');

    const [{ rows: products }, { rows: countRows }] = await Promise.all([
      pool.query(`
        SELECT
          p.id, p.name, p.slug, p.thumbnail, p.avg_rating, p.review_count,
          p.overall_score, p.is_trending, p.is_featured,
          b.name AS brand_name, b.slug AS brand_slug,
          c.name AS category_name, c.slug AS category_slug, c.emoji AS category_emoji,
          MIN(pp.price) AS min_price,
          json_agg(
            json_build_object(
              'price', pp.price, 'mrp', pp.mrp, 'discount', pp.discount,
              'in_stock', pp.in_stock, 'affiliate_url', pp.affiliate_url,
              'seller', json_build_object('name', s.name, 'slug', s.slug)
            ) ORDER BY pp.price
          ) FILTER (WHERE pp.id IS NOT NULL) AS prices
        FROM products p
        JOIN brands b ON b.id = p.brand_id
        JOIN categories c ON c.id = p.category_id
        LEFT JOIN product_prices pp ON pp.product_id = p.id AND pp.in_stock = true
        LEFT JOIN sellers s ON s.id = pp.seller_id
        WHERE ${where}
        GROUP BY p.id, b.name, b.slug, c.name, c.slug, c.emoji
        ORDER BY ${order}
        LIMIT $${pi++} OFFSET $${pi++}
      `, [...params, limitNum, offset]),
      pool.query(`
        SELECT COUNT(DISTINCT p.id)
        FROM products p
        JOIN brands b ON b.id = p.brand_id
        JOIN categories c ON c.id = p.category_id
        WHERE ${where}
      `, params),
    ]);

    const total = parseInt(countRows[0].count);
    res.json({
      products,
      pagination: {
        page: pageNum, limit: limitNum, total,
        totalPages: Math.ceil(total / limitNum),
        hasNext: offset + limitNum < total,
        hasPrev: pageNum > 1,
      },
    });
  } catch (e: any) {
    console.error('[Products]', e.message);
    res.status(500).json({ error: e.message });
  }
});

app.get('/api/v1/products/:slug', async (req, res) => {
  try {
    const { rows } = await pool.query(`
      SELECT
        p.*,
        b.name AS brand_name, b.slug AS brand_slug, b.logo AS brand_logo,
        c.name AS category_name, c.slug AS category_slug, c.emoji AS category_emoji,
        (SELECT json_agg(ps.* ORDER BY ps.sort_order)
          FROM product_specs ps WHERE ps.product_id = p.id) AS specs,
        (SELECT json_agg(
          json_build_object(
            'price', pp.price, 'mrp', pp.mrp, 'discount', pp.discount,
            'in_stock', pp.in_stock, 'affiliate_url', pp.affiliate_url, 'cashback', pp.cashback,
            'seller', json_build_object('name', s.name, 'slug', s.slug, 'logo', s.logo)
          ) ORDER BY pp.price)
          FROM product_prices pp JOIN sellers s ON s.id = pp.seller_id WHERE pp.product_id = p.id
        ) AS prices,
        (SELECT json_agg(json_build_object('price', ph.price, 'recorded_at', ph.recorded_at) ORDER BY ph.recorded_at)
          FROM price_history ph WHERE ph.product_id = p.id LIMIT 90) AS price_history,
        (SELECT json_agg(fps.* ORDER BY fps.game_title)
          FROM fps_data fps WHERE fps.product_id = p.id) AS fps_data,
        (SELECT json_agg(bm.* ORDER BY bm.category)
          FROM benchmarks bm WHERE bm.product_id = p.id) AS benchmarks
      FROM products p
      JOIN brands b ON b.id = p.brand_id
      JOIN categories c ON c.id = p.category_id
      WHERE p.slug = $1 AND p.status = 'APPROVED'
    `, [req.params.slug]);

    if (!rows[0]) return res.status(404).json({ error: 'Product not found' });

    const product = rows[0];

    // Group specs by group_name
    if (product.specs) {
      const grouped: Record<string, any[]> = {};
      for (const s of product.specs) {
        if (!grouped[s.group_name]) grouped[s.group_name] = [];
        grouped[s.group_name].push({ name: s.spec_name, value: s.spec_value, unit: s.unit });
      }
      product.grouped_specs = grouped;
    }

    // Price stats
    if (product.prices?.length) {
      const pricelist = product.prices.map((p: any) => p.price).filter(Boolean);
      product.price_stats = {
        min: Math.min(...pricelist),
        max: Math.max(...pricelist),
        avg: Math.round(pricelist.reduce((a: number, b: number) => a + b, 0) / pricelist.length),
      };
    }

    // Increment view count async
    pool.query('UPDATE products SET view_count = view_count + 1 WHERE slug = $1', [req.params.slug]).catch(() => {});

    res.json(product);
  } catch (e: any) {
    console.error('[Product Detail]', e.message);
    res.status(500).json({ error: e.message });
  }
});

app.get('/api/v1/products/:slug/similar', async (req, res) => {
  try {
    const { rows: [product] } = await pool.query(
      'SELECT category_id FROM products WHERE slug = $1', [req.params.slug]
    );
    if (!product) return res.status(404).json({ error: 'Not found' });

    const { rows } = await pool.query(`
      SELECT p.id, p.name, p.slug, p.thumbnail, p.avg_rating, p.overall_score,
        b.name AS brand_name,
        MIN(pp.price) AS min_price
      FROM products p
      JOIN brands b ON b.id = p.brand_id
      LEFT JOIN product_prices pp ON pp.product_id = p.id AND pp.in_stock = true
      WHERE p.category_id = $1 AND p.slug != $2 AND p.status = 'APPROVED'
      GROUP BY p.id, b.name
      ORDER BY p.view_count DESC
      LIMIT 6
    `, [product.category_id, req.params.slug]);
    res.json({ similar: rows });
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

// ─────────────────────────────────────────────────────────
// SEARCH
// ─────────────────────────────────────────────────────────
app.get('/api/v1/search', async (req, res) => {
  try {
    const { q, page = '1', limit = '24', sort = 'relevance', category, brand } = req.query;
    if (!q || (q as string).trim().length < 2) return res.status(400).json({ error: 'Query must be at least 2 characters' });

    const query = (q as string).trim();
    const likeQ = `%${query}%`;
    const pageNum = parseInt(page as string);
    const limitNum = Math.min(parseInt(limit as string), 100);
    const offset = (pageNum - 1) * limitNum;

    const conditions = ["p.status = 'APPROVED'", `(p.name ILIKE $1 OR b.name ILIKE $1 OR p.short_desc ILIKE $1)`];
    const params: any[] = [likeQ];
    let pi = 2;
    if (category) { conditions.push(`c.slug = $${pi++}`); params.push(category); }
    if (brand) { conditions.push(`b.slug = $${pi++}`); params.push(brand); }
    const where = conditions.join(' AND ');

    // Log search
    pool.query('INSERT INTO search_log (query) VALUES ($1) ON CONFLICT DO NOTHING', [query]).catch(() => {});

    const [{ rows: products }, { rows: cr }] = await Promise.all([
      pool.query(`
        SELECT p.id, p.name, p.slug, p.thumbnail, p.avg_rating, p.review_count, p.overall_score, p.is_trending,
          b.name AS brand_name, b.slug AS brand_slug,
          c.name AS category_name, c.slug AS category_slug, c.emoji AS category_emoji,
          MIN(pp.price) AS min_price,
          json_agg(json_build_object('price', pp.price, 'seller', s.name) ORDER BY pp.price)
            FILTER (WHERE pp.id IS NOT NULL) AS prices
        FROM products p
        JOIN brands b ON b.id = p.brand_id
        JOIN categories c ON c.id = p.category_id
        LEFT JOIN product_prices pp ON pp.product_id = p.id AND pp.in_stock = true
        LEFT JOIN sellers s ON s.id = pp.seller_id
        WHERE ${where}
        GROUP BY p.id, b.name, b.slug, c.name, c.slug, c.emoji
        ORDER BY p.view_count DESC
        LIMIT $${pi++} OFFSET $${pi++}
      `, [...params, limitNum, offset]),
      pool.query(
        `SELECT COUNT(DISTINCT p.id) FROM products p JOIN brands b ON b.id=p.brand_id JOIN categories c ON c.id=p.category_id WHERE ${where}`,
        params
      ),
    ]);

    const total = parseInt(cr[0].count);
    res.json({
      products, query,
      pagination: { page: pageNum, limit: limitNum, total, totalPages: Math.ceil(total/limitNum), hasNext: offset+limitNum<total, hasPrev: pageNum>1 },
    });
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

app.get('/api/v1/search/autocomplete', async (req, res) => {
  try {
    const { q } = req.query;
    if (!q || (q as string).length < 2) return res.json({ results: [] });

    const { rows } = await pool.query(`
      SELECT p.name, p.slug, p.thumbnail, c.name AS category, c.emoji, MIN(pp.price) AS price
      FROM products p
      JOIN categories c ON c.id = p.category_id
      LEFT JOIN product_prices pp ON pp.product_id = p.id
      WHERE p.status = 'APPROVED' AND p.name ILIKE $1
      GROUP BY p.id, p.name, p.slug, p.thumbnail, c.name, c.emoji
      ORDER BY p.view_count DESC
      LIMIT 8
    `, [`%${q}%`]);

    res.json({
      results: rows.map(r => ({
        type: 'product', name: r.name, slug: r.slug, image: r.thumbnail,
        category: `${r.emoji || ''} ${r.category}`,
        price: r.price ? `₹${(r.price / 100).toLocaleString('en-IN')}` : null,
      })),
    });
  } catch {
    res.json({ results: [] });
  }
});

app.get('/api/v1/search/trending', async (_req, res) => {
  try {
    const { rows } = await pool.query(`
      SELECT query, COUNT(*) AS count
      FROM search_log
      WHERE created_at > NOW() - INTERVAL '24 hours'
      GROUP BY query ORDER BY count DESC LIMIT 10
    `);
    res.json({ trending: rows.map(r => ({ query: r.query, count: parseInt(r.count) })) });
  } catch {
    res.json({ trending: [] });
  }
});

// ─────────────────────────────────────────────────────────
// DEALS
// ─────────────────────────────────────────────────────────
app.get('/api/v1/deals', async (_req, res) => {
  try {
    const { rows } = await pool.query(`
      SELECT p.id, p.name, p.slug, p.thumbnail, p.avg_rating,
        b.name AS brand_name, c.name AS category_name, c.slug AS category_slug, c.emoji AS category_emoji,
        json_agg(
          json_build_object('price', pp.price, 'mrp', pp.mrp, 'discount', pp.discount,
            'in_stock', pp.in_stock, 'affiliate_url', pp.affiliate_url,
            'seller', json_build_object('name', s.name, 'slug', s.slug))
          ORDER BY pp.price
        ) AS prices
      FROM products p
      JOIN brands b ON b.id = p.brand_id
      JOIN categories c ON c.id = p.category_id
      JOIN product_prices pp ON pp.product_id = p.id AND pp.discount >= 5 AND pp.in_stock = true
      JOIN sellers s ON s.id = pp.seller_id
      WHERE p.status = 'APPROVED'
      GROUP BY p.id, b.name, c.name, c.slug, c.emoji
      ORDER BY p.view_count DESC
      LIMIT 40
    `);
    res.json({ products: rows });
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

app.get('/api/v1/deals/flash', async (_req, res) => {
  try {
    const { rows } = await pool.query(`
      SELECT p.id, p.name, p.slug, p.thumbnail,
        b.name AS brand_name, c.name AS category_name, c.emoji AS category_emoji,
        json_agg(
          json_build_object('price', pp.price, 'mrp', pp.mrp, 'discount', pp.discount,
            'seller', json_build_object('name', s.name))
          ORDER BY pp.price
        ) AS prices
      FROM products p
      JOIN brands b ON b.id = p.brand_id
      JOIN categories c ON c.id = p.category_id
      JOIN product_prices pp ON pp.product_id = p.id AND pp.discount >= 10 AND pp.in_stock = true
      JOIN sellers s ON s.id = pp.seller_id
      WHERE p.status = 'APPROVED'
      GROUP BY p.id, b.name, c.name, c.emoji
      ORDER BY p.is_featured DESC, p.view_count DESC
      LIMIT 8
    `);
    res.json({ deals: rows });
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

// ─────────────────────────────────────────────────────────
// COMPARE
// ─────────────────────────────────────────────────────────
app.get('/api/v1/compare', async (req, res) => {
  try {
    const { ids } = req.query;
    if (!ids) return res.status(400).json({ error: 'ids required' });
    const productIds = (ids as string).split(',').slice(0, 4);

    const { rows } = await pool.query(`
      SELECT p.*, b.name AS brand_name, b.slug AS brand_slug,
        c.name AS category_name, c.slug AS category_slug,
        (SELECT json_agg(ps.* ORDER BY ps.group_name, ps.sort_order) FROM product_specs ps WHERE ps.product_id = p.id) AS specs,
        (SELECT json_agg(
          json_build_object('price', pp.price, 'mrp', pp.mrp, 'in_stock', pp.in_stock,
            'affiliate_url', pp.affiliate_url, 'seller', json_build_object('name', s.name)) ORDER BY pp.price)
          FROM product_prices pp JOIN sellers s ON s.id = pp.seller_id WHERE pp.product_id = p.id
        ) AS prices,
        (SELECT json_agg(bm.* ORDER BY bm.category) FROM benchmarks bm WHERE bm.product_id = p.id) AS benchmarks
      FROM products p
      JOIN brands b ON b.id = p.brand_id
      JOIN categories c ON c.id = p.category_id
      WHERE p.id = ANY($1) AND p.status = 'APPROVED'
    `, [productIds]);

    // Update compare count
    pool.query('UPDATE products SET compare_count = compare_count + 1 WHERE id = ANY($1)', [productIds]).catch(() => {});

    res.json({ products: rows });
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

// ─────────────────────────────────────────────────────────
// AI CHAT
// ─────────────────────────────────────────────────────────
app.post('/api/v1/ai/chat', aiLimiter, async (req, res) => {
  try {
    const { messages } = req.body;
    if (!messages || !Array.isArray(messages)) return res.status(400).json({ error: 'messages array required' });

    const key = process.env.OPENAI_API_KEY;
    if (key && !key.startsWith('sk-placeholder') && key.length > 20) {
      const { default: OpenAI } = await import('openai');
      const openai = new OpenAI({ apiKey: key });
      const r = await openai.chat.completions.create({
        model: 'gpt-4-turbo-preview',
        messages: [
          { role: 'system', content: 'You are AIComp, an expert electronics buying assistant for India. Be concise and helpful. Always mention prices in INR. Focus on value for Indian consumers.' },
          ...messages.slice(-20),
        ],
        max_tokens: 800,
        temperature: 0.7,
      });
      return res.json({ reply: r.choices[0].message.content, role: 'assistant' });
    }

    // Fallback — no OpenAI key
    const lastMsg = messages[messages.length - 1]?.content ?? '';
    res.json({
      reply: `I received your question: **"${lastMsg}"**\n\nTo enable full AI responses, add your OpenAI API key to \`.env\`:\n\`\`\`\nOPENAI_API_KEY=sk-your-key-here\n\`\`\`\n\nYou can still browse products, compare specs, and check live prices without AI.`,
      role: 'assistant',
    });
  } catch (e: any) {
    console.error('[AI Chat]', e.message);
    res.status(500).json({ error: 'AI service unavailable', reply: 'Sorry, AI is temporarily unavailable. Please try again later.' });
  }
});

app.post('/api/v1/ai/compare', aiLimiter, async (req, res) => {
  try {
    const { productIds } = req.body;
    if (!productIds?.length || productIds.length < 2) return res.status(400).json({ error: 'At least 2 product IDs required' });

    const { rows: products } = await pool.query(`
      SELECT p.name, p.overall_score, b.name AS brand, c.name AS category,
        json_object_agg(ps.spec_name, ps.spec_value) AS specs
      FROM products p
      JOIN brands b ON b.id = p.brand_id JOIN categories c ON c.id = p.category_id
      LEFT JOIN product_specs ps ON ps.product_id = p.id
      WHERE p.id = ANY($1)
      GROUP BY p.id, p.name, p.overall_score, b.name, c.name
    `, [productIds]);

    // Return structured verdict
    const sorted = [...products].sort((a, b) => (b.overall_score ?? 0) - (a.overall_score ?? 0));
    res.json({
      winner: sorted[0]?.name,
      verdict: `Based on AI scores, **${sorted[0]?.name}** leads with a score of ${sorted[0]?.overall_score}/100.`,
      scores: products.map(p => ({ name: p.name, score: p.overall_score })),
    });
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

// ─────────────────────────────────────────────────────────
// BRANDS
// ─────────────────────────────────────────────────────────
app.get('/api/v1/brands', async (_req, res) => {
  try {
    const { rows } = await pool.query(`
      SELECT b.id, b.name, b.slug, b.logo, b.country, b.website,
        (SELECT COUNT(*)::int FROM products p WHERE p.brand_id = b.id AND p.status = 'APPROVED') AS product_count
      FROM brands b WHERE b.is_active = true ORDER BY b.name
    `);
    res.json({ brands: rows });
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

// ─────────────────────────────────────────────────────────
// AUTH (basic — no Prisma sessions, just JWT)
// ─────────────────────────────────────────────────────────
app.post('/api/v1/auth/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) return res.status(400).json({ error: 'Email and password required' });

    const { rows } = await pool.query('SELECT id, email, name, role, password_hash FROM users WHERE email = $1', [email]);
    const user = rows[0];
    if (!user) return res.status(401).json({ error: 'Invalid credentials' });

    const { default: bcrypt } = await import('bcryptjs');
    const valid = await bcrypt.compare(password, user.password_hash);
    if (!valid) return res.status(401).json({ error: 'Invalid credentials' });

    const { default: jwt } = await import('jsonwebtoken');
    const secret = process.env.JWT_SECRET || 'aicomp-dev-secret';
    const token = jwt.sign({ id: user.id, email: user.email, role: user.role }, secret, { expiresIn: '30d' });

    res.json({ token, user: { id: user.id, email: user.email, name: user.name, role: user.role } });
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

app.post('/api/v1/auth/register', async (req, res) => {
  try {
    const { name, email, password } = req.body;
    if (!email || !password) return res.status(400).json({ error: 'Email and password required' });

    const { default: bcrypt } = await import('bcryptjs');
    const hash = await bcrypt.hash(password, 12);

    const { rows } = await pool.query(
      'INSERT INTO users (email, name, password_hash) VALUES ($1, $2, $3) RETURNING id, email, name, role',
      [email, name || 'User', hash]
    );

    const { default: jwt } = await import('jsonwebtoken');
    const token = jwt.sign({ id: rows[0].id, email: rows[0].email, role: rows[0].role }, process.env.JWT_SECRET || 'aicomp-dev-secret', { expiresIn: '30d' });

    res.status(201).json({ token, user: rows[0] });
  } catch (e: any) {
    if (e.code === '23505') return res.status(409).json({ error: 'Email already registered' });
    res.status(500).json({ error: e.message });
  }
});

// ─────────────────────────────────────────────────────────
// ADMIN STATS
// ─────────────────────────────────────────────────────────
app.get('/api/v1/admin/stats', async (_req, res) => {
  try {
    const [t, p, u, a] = await Promise.all([
      pool.query("SELECT COUNT(*)::int AS c FROM products"),
      pool.query("SELECT COUNT(*)::int AS c FROM products WHERE status = 'PENDING'"),
      pool.query("SELECT COUNT(*)::int AS c FROM users"),
      pool.query("SELECT COUNT(*)::int AS c FROM price_alerts WHERE is_active = true"),
    ]);
    res.json({
      products: t.rows[0].c,
      pendingProducts: p.rows[0].c,
      users: u.rows[0].c,
      activeAlerts: a.rows[0].c,
    });
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

// ─────────────────────────────────────────────────────────
// ANALYTICS
// ─────────────────────────────────────────────────────────
app.get('/api/v1/analytics/overview', async (_req, res) => {
  try {
    const { rows: [r] } = await pool.query(`
      SELECT
        (SELECT COUNT(*)::int FROM products WHERE status = 'APPROVED') AS products,
        (SELECT COUNT(*)::int FROM users) AS users,
        (SELECT COUNT(*)::int FROM price_alerts WHERE is_active = true) AS alerts,
        (SELECT COUNT(*)::int FROM search_log WHERE created_at > NOW() - INTERVAL '24 hours') AS searches_24h
    `);
    res.json(r);
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

// ─────────────────────────────────────────────────────────
// 404
// ─────────────────────────────────────────────────────────
app.use((req, res) => {
  res.status(404).json({ error: `Route ${req.method} ${req.url} not found` });
});

// ─────────────────────────────────────────────────────────
// START
// ─────────────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`\n✅ AIComp API → http://localhost:${PORT}`);
  console.log(`   Health:    http://localhost:${PORT}/health`);
  console.log(`   DB:        ${(process.env.DATABASE_URL || 'postgresql://localhost/aicomp').replace(/:[^:@]+@/, ':***@')}\n`);
});

export default app;
