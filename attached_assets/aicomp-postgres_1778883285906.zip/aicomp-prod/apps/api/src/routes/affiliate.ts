import { affiliateRouter } from './_all-routes';
export default affiliateRouter;
