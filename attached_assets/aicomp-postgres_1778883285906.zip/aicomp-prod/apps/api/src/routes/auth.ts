import { Router, Request, Response } from 'express';
import bcrypt from 'bcryptjs';
import { z } from 'zod';
import { PrismaClient } from '@prisma/client';
import { generateToken, authMiddleware, AuthRequest } from '../middleware/auth';
import { logger } from '../utils/logger';

const router = Router();
const prisma = new PrismaClient();

const registerSchema = z.object({
  email: z.string().email(),
  password: z.string().min(8),
  name: z.string().min(2).max(60).optional(),
});

const loginSchema = z.object({
  email: z.string().email(),
  password: z.string(),
});

// ─── POST /auth/register ───────────────────────────────────

router.post('/register', async (req: Request, res: Response) => {
  try {
    const { email, password, name } = registerSchema.parse(req.body);

    const existing = await prisma.user.findUnique({ where: { email } });
    if (existing) return res.status(409).json({ error: 'Email already registered' });

    const passwordHash = await bcrypt.hash(password, 12);
    const user = await prisma.user.create({
      data: { email, passwordHash, name: name || null },
      select: { id: true, email: true, name: true, role: true },
    });

    // Create empty profile
    await prisma.userProfile.create({ data: { userId: user.id } });

    const token = generateToken(user.id, user.email, user.role);
    const expiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);
    await prisma.userSession.create({ data: { userId: user.id, token, expiresAt } });

    res.status(201).json({ user, token });
  } catch (e) {
    if (e instanceof z.ZodError) return res.status(400).json({ error: e.errors });
    logger.error('Register error:', e);
    res.status(500).json({ error: 'Registration failed' });
  }
});

// ─── POST /auth/login ──────────────────────────────────────

router.post('/login', async (req: Request, res: Response) => {
  try {
    const { email, password } = loginSchema.parse(req.body);

    const user = await prisma.user.findUnique({
      where: { email },
      select: { id: true, email: true, name: true, role: true, passwordHash: true, isBanned: true },
    });

    if (!user || !user.passwordHash) return res.status(401).json({ error: 'Invalid credentials' });
    if (user.isBanned) return res.status(403).json({ error: 'Account suspended' });

    const valid = await bcrypt.compare(password, user.passwordHash);
    if (!valid) return res.status(401).json({ error: 'Invalid credentials' });

    const token = generateToken(user.id, user.email, user.role);
    const expiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);
    await prisma.userSession.create({ data: { userId: user.id, token, expiresAt } });

    const { passwordHash, ...safeUser } = user;
    res.json({ user: safeUser, token });
  } catch (e) {
    if (e instanceof z.ZodError) return res.status(400).json({ error: e.errors });
    logger.error('Login error:', e);
    res.status(500).json({ error: 'Login failed' });
  }
});

// ─── POST /auth/logout ─────────────────────────────────────

router.post('/logout', authMiddleware, async (req: AuthRequest, res: Response) => {
  try {
    const token = req.headers.authorization?.slice(7);
    if (token) await prisma.userSession.deleteMany({ where: { token } });
    res.json({ success: true });
  } catch {
    res.status(500).json({ error: 'Logout failed' });
  }
});

// ─── GET /auth/me ──────────────────────────────────────────

router.get('/me', authMiddleware, async (req: AuthRequest, res: Response) => {
  try {
    const user = await prisma.user.findUnique({
      where: { id: req.user!.id },
      select: {
        id: true, email: true, name: true, avatar: true, role: true,
        isVerified: true, reputationPoints: true, createdAt: true,
        profile: true,
        _count: { select: { wishlist: true, alerts: true, reviews: true } },
      },
    });
    res.json({ user });
  } catch {
    res.status(500).json({ error: 'Failed to fetch user' });
  }
});

// ─── POST /auth/google ─────────────────────────────────────
// (OAuth token verification — integrate with NextAuth on frontend)

router.post('/google', async (req: Request, res: Response) => {
  try {
    const { idToken } = req.body;
    // Verify Google ID token (use google-auth-library in production)
    // For now, return placeholder
    res.status(501).json({ error: 'Google OAuth: verify idToken with google-auth-library' });
  } catch {
    res.status(500).json({ error: 'Google auth failed' });
  }
});

// ─── POST /auth/refresh ────────────────────────────────────

router.post('/refresh', async (req: Request, res: Response) => {
  try {
    const { token } = req.body;
    const session = await prisma.userSession.findUnique({
      where: { token },
      include: { user: { select: { id: true, email: true, role: true, isBanned: true } } },
    });

    if (!session || session.expiresAt < new Date() || session.user.isBanned) {
      return res.status(401).json({ error: 'Invalid or expired session' });
    }

    const newToken = generateToken(session.user.id, session.user.email, session.user.role);
    const expiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);

    await prisma.userSession.update({ where: { token }, data: { token: newToken, expiresAt } });

    res.json({ token: newToken });
  } catch {
    res.status(500).json({ error: 'Token refresh failed' });
  }
});

export default router;
