import { Router, Request, Response } from 'express';
import { PrismaClient } from '@prisma/client';
import { z } from 'zod';
import { cache } from '../utils/cache';
import { chatWithAI } from '../services/aiService';
import { logger } from '../utils/logger';

const router = Router();
const prisma = new PrismaClient();

// ─── GET /search ───────────────────────────────────────────

router.get('/', async (req: Request, res: Response) => {
  try {
    const { q, category, brand, minPrice, maxPrice, sort = 'relevance', page = '1', limit = '24', mode } = req.query;

    if (!q || (q as string).trim().length < 2) {
      return res.status(400).json({ error: 'Query must be at least 2 characters' });
    }

    const query = (q as string).trim();
    const pageNum = parseInt(page as string);
    const limitNum = Math.min(parseInt(limit as string), 100);
    const skip = (pageNum - 1) * limitNum;

    // Log search
    prisma.searchLog.create({ data: { query, results: 0 } }).catch(() => {});

    // AI search mode — use AI to parse intent and suggest filters
    if (mode === 'ai') {
      const aiParsed = await parseSearchWithAI(query);
      // Apply AI-derived filters to DB query
    }

    const where: any = {
      status: 'APPROVED',
      OR: [
        { name: { contains: query, mode: 'insensitive' } },
        { brand: { name: { contains: query, mode: 'insensitive' } } },
        { tags: { some: { tag: { contains: query, mode: 'insensitive' } } } },
        { shortDesc: { contains: query, mode: 'insensitive' } },
      ],
    };

    if (category) where.category = { slug: category as string };
    if (brand) where.brand = { slug: brand as string };
    if (minPrice || maxPrice) {
      where.prices = {
        some: {
          price: {
            gte: minPrice ? parseInt(minPrice as string) * 100 : undefined,
            lte: maxPrice ? parseInt(maxPrice as string) * 100 : undefined,
          },
        },
      };
    }

    const orderBy: any = {
      relevance: [{ viewCount: 'desc' }, { avgRating: 'desc' }],
      popular: { viewCount: 'desc' },
      newest: { createdAt: 'desc' },
      price_asc: {},
      price_desc: {},
      rating: { avgRating: 'desc' },
    }[sort as string] || [{ viewCount: 'desc' }];

    const [products, total] = await Promise.all([
      prisma.product.findMany({
        where,
        skip,
        take: limitNum,
        orderBy: Array.isArray(orderBy) ? orderBy : [orderBy],
        select: {
          id: true, name: true, slug: true, thumbnail: true, avgRating: true,
          reviewCount: true, overallScore: true, isTrending: true,
          brand: { select: { name: true, slug: true } },
          category: { select: { name: true, slug: true, emoji: true } },
          prices: { take: 1, orderBy: { price: 'asc' }, include: { seller: { select: { name: true } } } },
        },
      }),
      prisma.product.count({ where }),
    ]);

    // Update search log with result count
    if (total > 0) {
      prisma.searchLog.updateMany({
        where: { query, createdAt: { gte: new Date(Date.now() - 5000) } },
        data: { results: total },
      }).catch(() => {});
    }

    // Also search in content
    const contentResults = total < 5 ? await prisma.seoContent.findMany({
      where: {
        isPublished: true,
        OR: [
          { title: { contains: query, mode: 'insensitive' } },
          { body: { contains: query, mode: 'insensitive' } },
        ],
      },
      take: 3,
      select: { title: true, slug: true, type: true, excerpt: true },
    }) : [];

    res.json({
      products,
      content: contentResults,
      query,
      pagination: {
        page: pageNum, limit: limitNum, total,
        totalPages: Math.ceil(total / limitNum),
        hasNext: skip + limitNum < total,
        hasPrev: pageNum > 1,
      },
    });
  } catch (error) {
    logger.error('Search error:', error);
    res.status(500).json({ error: 'Search failed' });
  }
});

// ─── GET /search/autocomplete ─────────────────────────────

router.get('/autocomplete', async (req: Request, res: Response) => {
  try {
    const { q } = req.query;
    if (!q || (q as string).length < 2) return res.json({ results: [] });

    const query = (q as string).trim();
    const cacheKey = `search:ac:${query.toLowerCase()}`;
    const cached = await cache.get(cacheKey);
    if (cached) return res.json(JSON.parse(cached));

    const [products, brands, categories] = await Promise.all([
      prisma.product.findMany({
        where: { status: 'APPROVED', name: { contains: query, mode: 'insensitive' } },
        take: 6,
        orderBy: { viewCount: 'desc' },
        select: {
          name: true, slug: true, thumbnail: true,
          category: { select: { name: true, emoji: true } },
          prices: { take: 1, orderBy: { price: 'asc' }, select: { price: true } },
        },
      }),
      prisma.brand.findMany({
        where: { name: { contains: query, mode: 'insensitive' }, isActive: true },
        take: 2,
        select: { name: true, slug: true, logo: true },
      }),
      prisma.category.findMany({
        where: { name: { contains: query, mode: 'insensitive' }, isActive: true },
        take: 2,
        select: { name: true, slug: true, emoji: true },
      }),
    ]);

    const results = [
      ...products.map(p => ({
        type: 'product',
        name: p.name,
        slug: p.slug,
        image: p.thumbnail,
        category: `${p.category.emoji || ''} ${p.category.name}`,
        price: p.prices[0]?.price ? `₹${(p.prices[0].price / 100).toLocaleString('en-IN')}` : null,
      })),
      ...brands.map(b => ({ type: 'brand', name: b.name, slug: b.slug, image: b.logo })),
      ...categories.map(c => ({ type: 'category', name: `${c.emoji || ''} ${c.name}`, slug: c.slug })),
    ];

    await cache.setEx(cacheKey, 300, JSON.stringify({ results }));
    res.json({ results });
  } catch (error) {
    res.status(500).json({ results: [] });
  }
});

// ─── GET /search/trending ─────────────────────────────────

router.get('/trending', async (req: Request, res: Response) => {
  try {
    const cacheKey = 'search:trending';
    const cached = await cache.get(cacheKey);
    if (cached) return res.json(JSON.parse(cached));

    const trending = await prisma.searchLog.groupBy({
      by: ['query'],
      _count: { query: true },
      orderBy: { _count: { query: 'desc' } },
      take: 10,
      where: { createdAt: { gte: new Date(Date.now() - 86400000) }, results: { gt: 0 } },
    });

    const result = { trending: trending.map(t => ({ query: t.query, count: t._count.query })) };
    await cache.setEx(cacheKey, 600, JSON.stringify(result));
    res.json(result);
  } catch {
    res.json({ trending: [] });
  }
});

// ─── AI search intent parser ──────────────────────────────

async function parseSearchWithAI(query: string): Promise<{
  category?: string;
  minBudget?: number;
  maxBudget?: number;
  useCase?: string;
  brands?: string[];
  specs?: Record<string, string>;
}> {
  const cacheKey = `search:ai:${query.toLowerCase().slice(0, 50)}`;
  const cached = await cache.get(cacheKey);
  if (cached) return JSON.parse(cached);

  const prompt = `Parse this electronics search query for Indian market and extract structured filters.
Query: "${query}"

Return ONLY valid JSON:
{
  "category": "smartphones|laptops|tvs|air-conditioners|cameras|monitors|smartwatches|null",
  "minBudget": 0,
  "maxBudget": 100000,
  "useCase": "gaming|photography|work|streaming|null",
  "brands": ["Apple", "Samsung"],
  "specs": {"ram": "12GB", "storage": "256GB"}
}`;

  try {
    const reply = await chatWithAI([{ role: 'user', content: prompt }]);
    const parsed = JSON.parse(reply.match(/\{[\s\S]*\}/)?.[0] || '{}');
    await cache.setEx(cacheKey, 3600, JSON.stringify(parsed));
    return parsed;
  } catch {
    return {};
  }
}

export default router;
