import { seoRouter } from './_all-routes';
export default seoRouter;
