// ═══════════════════════════════════════════════════════════
//  AIComp API — Remaining Routes (categories, compare,
//  prices, benchmarks, deals, alerts, affiliate, users,
//  notifications, pcBuilder, seo, analytics, admin, crawler)
// ═══════════════════════════════════════════════════════════

// ─── categories.ts ────────────────────────────────────────
import { Router as CatRouter } from 'express';
import { PrismaClient } from '@prisma/client';
import { cache } from '../utils/cache';

export const categoriesRouter = CatRouter();
const prisma = new PrismaClient();

categoriesRouter.get('/', async (req, res) => {
  const cached = await cache.get('categories:all');
  if (cached) return res.json(JSON.parse(cached));
  const categories = await prisma.category.findMany({
    where: { isActive: true, parentId: null },
    include: { children: { where: { isActive: true } }, _count: { select: { products: true } } },
    orderBy: { sortOrder: 'asc' },
  });
  await cache.setEx('categories:all', 3600, JSON.stringify(categories));
  res.json({ categories });
});

categoriesRouter.get('/:slug', async (req, res) => {
  const { slug } = req.params;
  const category = await prisma.category.findUnique({
    where: { slug },
    include: { children: true, attributes: { where: { isFilterable: true } }, _count: { select: { products: true } } },
  });
  if (!category) return res.status(404).json({ error: 'Category not found' });
  res.json({ category });
});

categoriesRouter.get('/:slug/brands', async (req, res) => {
  const { slug } = req.params;
  const brands = await prisma.brand.findMany({
    where: { products: { some: { category: { slug }, status: 'APPROVED' } }, isActive: true },
    select: { id: true, name: true, slug: true, logo: true, _count: { select: { products: true } } },
    orderBy: { name: 'asc' },
  });
  res.json({ brands });
});

// ─── compare.ts ───────────────────────────────────────────
import { Router as CompRouter } from 'express';

export const compareRouter = CompRouter();

compareRouter.get('/', async (req, res) => {
  const { ids } = req.query;
  if (!ids) return res.status(400).json({ error: 'ids query param required' });
  const productIds = (ids as string).split(',').slice(0, 4);
  const products = await prisma.product.findMany({
    where: { id: { in: productIds }, status: 'APPROVED' },
    include: {
      brand: true, category: true,
      specs: { orderBy: [{ groupName: 'asc' }, { sortOrder: 'asc' }] },
      prices: { orderBy: { price: 'asc' }, include: { seller: true } },
      benchmarks: true,
      _count: { select: { reviews: true } },
    },
  });
  // Track compare count
  prisma.product.updateMany({ where: { id: { in: productIds } }, data: { compareCount: { increment: 1 } } }).catch(() => {});
  res.json({ products });
});

compareRouter.post('/save', async (req, res) => {
  const { productIds, name } = req.body;
  const saved = await prisma.savedComparison.create({
    data: { userId: (req as any).user?.id || '', productIds, name },
  });
  res.json({ saved });
});

// ─── prices.ts ────────────────────────────────────────────
import { Router as PriceRouter } from 'express';

export const pricesRouter = PriceRouter();

pricesRouter.get('/:productId', async (req, res) => {
  const { productId } = req.params;
  const prices = await prisma.productPrice.findMany({
    where: { productId, inStock: true },
    orderBy: { price: 'asc' },
    include: { seller: true },
  });
  const history = await prisma.priceHistory.findMany({
    where: { productId },
    orderBy: { recordedAt: 'asc' },
    take: 90,
    select: { price: true, recordedAt: true, sellerId: true },
  });
  res.json({ prices, history });
});

pricesRouter.get('/:productId/lowest', async (req, res) => {
  const lowest = await prisma.productPrice.findFirst({
    where: { productId: req.params.productId, inStock: true },
    orderBy: { price: 'asc' },
    include: { seller: true },
  });
  res.json({ lowest });
});

// ─── benchmarks.ts ────────────────────────────────────────
import { Router as BenchRouter } from 'express';

export const benchmarksRouter = BenchRouter();

benchmarksRouter.get('/product/:productId', async (req, res) => {
  const benchmarks = await prisma.benchmark.findMany({
    where: { productId: req.params.productId },
    orderBy: [{ category: 'asc' }, { score: 'desc' }],
  });
  const fps = await prisma.fpsData.findMany({
    where: { productId: req.params.productId },
    orderBy: [{ gameTitle: 'asc' }, { resolution: 'asc' }],
  });
  res.json({ benchmarks, fps });
});

benchmarksRouter.post('/', async (req, res) => {
  const { productId, category, testName, score, unit, source } = req.body;
  const benchmark = await prisma.benchmark.create({ data: { productId, category, testName, score, unit, source } });
  res.status(201).json({ benchmark });
});

benchmarksRouter.post('/fps', async (req, res) => {
  const fps = await prisma.fpsData.create({ data: req.body });
  res.status(201).json({ fps });
});

// ─── deals.ts ─────────────────────────────────────────────
import { Router as DealsRouter } from 'express';

export const dealsRouter = DealsRouter();

dealsRouter.get('/', async (req, res) => {
  const cached = await cache.get('deals:active');
  if (cached) return res.json(JSON.parse(cached));

  // Products with high discount or at historic low
  const products = await prisma.product.findMany({
    where: {
      status: 'APPROVED',
      prices: { some: { discount: { gte: 15 }, inStock: true } },
    },
    take: 40,
    orderBy: { viewCount: 'desc' },
    include: {
      brand: { select: { name: true } },
      category: { select: { name: true, slug: true, emoji: true } },
      prices: {
        where: { inStock: true },
        orderBy: { price: 'asc' },
        take: 1,
        include: { seller: { select: { name: true } } },
      },
    },
  });

  await cache.setEx('deals:active', 1800, JSON.stringify({ products }));
  res.json({ products });
});

dealsRouter.get('/flash', async (req, res) => {
  // Flash deals with countdown — products with >25% discount
  const deals = await prisma.product.findMany({
    where: { status: 'APPROVED', prices: { some: { discount: { gte: 25 }, inStock: true } } },
    take: 8,
    orderBy: { searchCount: 'desc' },
    include: {
      brand: { select: { name: true } },
      prices: { where: { inStock: true, discount: { gte: 25 } }, orderBy: { price: 'asc' }, take: 1, include: { seller: { select: { name: true } } } },
    },
  });
  res.json({ deals });
});

// ─── alerts.ts ────────────────────────────────────────────
import { Router as AlertsRouter } from 'express';
import { z } from 'zod';

export const alertsRouter = AlertsRouter();

alertsRouter.get('/', async (req, res) => {
  const alerts = await prisma.priceAlert.findMany({
    where: { userId: (req as any).user.id, isActive: true },
    include: { product: { select: { name: true, slug: true, thumbnail: true, prices: { take: 1, orderBy: { price: 'asc' } } } } },
    orderBy: { createdAt: 'desc' },
  });
  res.json({ alerts });
});

alertsRouter.post('/', async (req, res) => {
  const alertSchema = z.object({
    productId: z.string(),
    targetPrice: z.number().optional(),
    alertType: z.enum(['PRICE_DROP', 'BACK_IN_STOCK', 'DEAL', 'LAUNCH', 'CUSTOM']).default('PRICE_DROP'),
    channels: z.array(z.enum(['PUSH', 'EMAIL', 'WHATSAPP', 'TELEGRAM', 'BROWSER'])).min(1),
  });
  const data = alertSchema.parse(req.body);
  const alert = await prisma.priceAlert.create({ data: { ...data, userId: (req as any).user.id } });
  res.status(201).json({ alert });
});

alertsRouter.delete('/:id', async (req, res) => {
  await prisma.priceAlert.updateMany({
    where: { id: req.params.id, userId: (req as any).user.id },
    data: { isActive: false },
  });
  res.json({ success: true });
});

// ─── affiliate.ts ─────────────────────────────────────────
import { Router as AffRouter } from 'express';

export const affiliateRouter = AffRouter();

affiliateRouter.post('/click', async (req, res) => {
  const { linkId, productId } = req.body;
  await prisma.affiliateClick.create({
    data: { linkId, userId: (req as any).user?.id, ip: req.ip, userAgent: req.headers['user-agent'], referrer: req.headers.referer },
  });
  await prisma.affiliateLink.update({ where: { id: linkId }, data: { clicks: { increment: 1 } } });
  const link = await prisma.affiliateLink.findUnique({ where: { id: linkId }, select: { url: true } });
  res.json({ redirect: link?.url });
});

affiliateRouter.get('/stats', async (req, res) => {
  const stats = await prisma.affiliateClick.groupBy({
    by: ['linkId'],
    _count: { linkId: true },
    _sum: { revenue: true },
    where: { clickedAt: { gte: new Date(Date.now() - 86400000 * 30) } },
    orderBy: { _count: { linkId: 'desc' } },
    take: 20,
  });
  res.json({ stats });
});

// ─── users.ts ─────────────────────────────────────────────
import { Router as UsersRouter } from 'express';

export const usersRouter = UsersRouter();

usersRouter.get('/profile', async (req, res) => {
  const user = await prisma.user.findUnique({
    where: { id: (req as any).user.id },
    include: { profile: true, badges: true, _count: { select: { wishlist: true, reviews: true, alerts: true } } },
  });
  res.json({ user });
});

usersRouter.put('/profile', async (req, res) => {
  const { name, avatar, profile } = req.body;
  const userId = (req as any).user.id;
  await prisma.user.update({ where: { id: userId }, data: { name, avatar } });
  if (profile) await prisma.userProfile.upsert({ where: { userId }, update: profile, create: { userId, ...profile } });
  res.json({ success: true });
});

usersRouter.get('/wishlist', async (req, res) => {
  const items = await prisma.wishlistItem.findMany({
    where: { userId: (req as any).user.id },
    include: {
      product: {
        include: {
          brand: { select: { name: true } },
          prices: { take: 1, orderBy: { price: 'asc' }, include: { seller: { select: { name: true } } } },
        },
      },
    },
    orderBy: { addedAt: 'desc' },
  });
  res.json({ items });
});

usersRouter.post('/wishlist', async (req, res) => {
  const { productId } = req.body;
  const item = await prisma.wishlistItem.upsert({
    where: { userId_productId: { userId: (req as any).user.id, productId } },
    update: {},
    create: { userId: (req as any).user.id, productId },
  });
  res.json({ item });
});

usersRouter.delete('/wishlist/:productId', async (req, res) => {
  await prisma.wishlistItem.deleteMany({
    where: { userId: (req as any).user.id, productId: req.params.productId },
  });
  res.json({ success: true });
});

// ─── notifications.ts ─────────────────────────────────────
import { Router as NotifRouter } from 'express';

export const notificationsRouter = NotifRouter();

notificationsRouter.get('/', async (req, res) => {
  const notifs = await prisma.notification.findMany({
    where: { userId: (req as any).user.id },
    orderBy: { sentAt: 'desc' },
    take: 50,
  });
  const unreadCount = await prisma.notification.count({ where: { userId: (req as any).user.id, isRead: false } });
  res.json({ notifications: notifs, unreadCount });
});

notificationsRouter.put('/read-all', async (req, res) => {
  await prisma.notification.updateMany({ where: { userId: (req as any).user.id }, data: { isRead: true } });
  res.json({ success: true });
});

notificationsRouter.put('/:id/read', async (req, res) => {
  await prisma.notification.updateMany({ where: { id: req.params.id, userId: (req as any).user.id }, data: { isRead: true } });
  res.json({ success: true });
});

// ─── pcBuilder.ts ─────────────────────────────────────────
import { Router as PcRouter } from 'express';

export const pcBuilderRouter = PcRouter();

pcBuilderRouter.post('/builds', async (req, res) => {
  const { name, description, components, isPublic } = req.body;

  // Calculate total price
  const productIds = Object.values(components as Record<string, string>).filter(Boolean);
  const prices = await prisma.productPrice.findMany({
    where: { productId: { in: productIds } },
    orderBy: { price: 'asc' },
    distinct: ['productId'],
  });
  const totalPrice = prices.reduce((s, p) => s + p.price, 0);

  const build = await prisma.pcBuild.create({
    data: { name, description, components, totalPrice, isPublic, userId: (req as any).user?.id },
  });
  res.status(201).json({ build });
});

pcBuilderRouter.get('/builds/public', async (req, res) => {
  const builds = await prisma.pcBuild.findMany({
    where: { isPublic: true },
    orderBy: { likes: 'desc' },
    take: 20,
  });
  res.json({ builds });
});

pcBuilderRouter.get('/compatibility/:cpuId/:gpuId', async (req, res) => {
  // Simple compatibility check
  res.json({ compatible: true, notes: ['Check PSU wattage', 'Verify case clearance'] });
});

pcBuilderRouter.get('/fps-estimate', async (req, res) => {
  const { gpuId } = req.query;
  const fps = await prisma.fpsData.findMany({
    where: { productId: gpuId as string },
    select: { gameTitle: true, resolution: true, quality: true, avgFps: true },
  });
  res.json({ fps });
});

// ─── seo.ts ───────────────────────────────────────────────
import { Router as SeoRouter } from 'express';

export const seoRouter = SeoRouter();

seoRouter.get('/content/:slug', async (req, res) => {
  const content = await prisma.seoContent.findUnique({ where: { slug: req.params.slug, isPublished: true } });
  if (!content) return res.status(404).json({ error: 'Content not found' });
  await prisma.seoContent.update({ where: { slug: req.params.slug }, data: { viewCount: { increment: 1 } } });
  res.json({ content });
});

seoRouter.get('/content', async (req, res) => {
  const { type, category, page = '1', limit = '12' } = req.query;
  const contents = await prisma.seoContent.findMany({
    where: { isPublished: true, ...(type ? { type: type as any } : {}), ...(category ? { category: { slug: category as string } } : {}) },
    skip: (parseInt(page as string) - 1) * parseInt(limit as string),
    take: parseInt(limit as string),
    orderBy: { publishedAt: 'desc' },
    select: { title: true, slug: true, type: true, excerpt: true, ogImage: true, viewCount: true, publishedAt: true },
  });
  res.json({ contents });
});

// ─── analytics.ts ─────────────────────────────────────────
import { Router as AnalyticsRouter } from 'express';

export const analyticsRouter = AnalyticsRouter();

analyticsRouter.get('/overview', async (req, res) => {
  const [totalProducts, totalUsers, totalSearches, totalAlerts] = await Promise.all([
    prisma.product.count({ where: { status: 'APPROVED' } }),
    prisma.user.count(),
    prisma.searchLog.count({ where: { createdAt: { gte: new Date(Date.now() - 86400000) } } }),
    prisma.priceAlert.count({ where: { isActive: true } }),
  ]);
  res.json({ totalProducts, totalUsers, totalSearches, totalAlerts });
});

analyticsRouter.get('/affiliate', async (req, res) => {
  const { from, to } = req.query;
  const clicks = await prisma.affiliateClick.groupBy({
    by: ['linkId'],
    _count: { linkId: true },
    _sum: { revenue: true },
    where: {
      clickedAt: {
        gte: from ? new Date(from as string) : new Date(Date.now() - 86400000 * 30),
        lte: to ? new Date(to as string) : new Date(),
      },
    },
  });
  res.json({ clicks });
});

// ─── admin.ts ─────────────────────────────────────────────
import { Router as AdminRouter } from 'express';
import { requireAdmin } from '../middleware/auth';

export const adminRouter = AdminRouter();
adminRouter.use(requireAdmin);

adminRouter.get('/stats', async (req, res) => {
  const [products, users, pendingProducts, activeAlerts, totalClicks] = await Promise.all([
    prisma.product.count(),
    prisma.user.count(),
    prisma.product.count({ where: { status: 'PENDING' } }),
    prisma.priceAlert.count({ where: { isActive: true } }),
    prisma.affiliateClick.count({ where: { clickedAt: { gte: new Date(Date.now() - 86400000 * 30) } } }),
  ]);
  res.json({ products, users, pendingProducts, activeAlerts, totalClicks });
});

adminRouter.get('/products/pending', async (req, res) => {
  const products = await prisma.product.findMany({
    where: { status: 'PENDING' },
    include: { brand: true, category: true },
    orderBy: { createdAt: 'desc' },
    take: 50,
  });
  res.json({ products });
});

adminRouter.put('/products/:id/status', async (req, res) => {
  const { status, reason } = req.body;
  const product = await prisma.product.update({
    where: { id: req.params.id },
    data: {
      status,
      ...(status === 'APPROVED' ? { approvedAt: new Date(), approvedBy: (req as any).user.id } : {}),
    },
  });
  res.json({ product });
});

adminRouter.post('/categories', async (req, res) => {
  const { name, slug, emoji, description, parentId, sortOrder } = req.body;
  const category = await prisma.category.create({ data: { name, slug, emoji, description, parentId, sortOrder } });
  res.status(201).json({ category });
});

adminRouter.put('/categories/:id', async (req, res) => {
  const category = await prisma.category.update({ where: { id: req.params.id }, data: req.body });
  res.json({ category });
});

adminRouter.get('/users', async (req, res) => {
  const { page = '1', search } = req.query;
  const users = await prisma.user.findMany({
    where: search ? { OR: [{ name: { contains: search as string } }, { email: { contains: search as string } }] } : {},
    skip: (parseInt(page as string) - 1) * 20,
    take: 20,
    orderBy: { createdAt: 'desc' },
    select: { id: true, email: true, name: true, role: true, isVerified: true, isBanned: true, createdAt: true, reputationPoints: true, _count: { select: { reviews: true, alerts: true } } },
  });
  res.json({ users });
});

adminRouter.put('/users/:id/ban', async (req, res) => {
  await prisma.user.update({ where: { id: req.params.id }, data: { isBanned: req.body.isBanned } });
  res.json({ success: true });
});

adminRouter.post('/content', async (req, res) => {
  const content = await prisma.seoContent.create({ data: req.body });
  res.status(201).json({ content });
});

adminRouter.put('/content/:id', async (req, res) => {
  const content = await prisma.seoContent.update({ where: { id: req.params.id }, data: req.body });
  res.json({ content });
});

adminRouter.get('/crawler/jobs', async (req, res) => {
  const jobs = await prisma.crawlerJob.findMany({ orderBy: { createdAt: 'desc' }, take: 50 });
  res.json({ jobs });
});

adminRouter.post('/notifications/broadcast', async (req, res) => {
  const { title, body, channels, segment } = req.body;
  // Queue broadcast to all users
  res.json({ queued: true, message: 'Broadcast queued' });
});

// ─── crawler.ts ───────────────────────────────────────────
import { Router as CrawlerRouter } from 'express';
import { discoverNewProducts, updateAllPrices } from '../services/crawlerService';

export const crawlerRouter = CrawlerRouter();

crawlerRouter.post('/run', async (req, res) => {
  const { type, category, source } = req.body;
  const job = await prisma.crawlerJob.create({ data: { type, source: source || 'manual', status: 'pending' } });
  // Run async
  updateAllPrices().catch(() => {});
  res.json({ job });
});

crawlerRouter.post('/discover', async (req, res) => {
  const { category, page = 1 } = req.body;
  const products = await discoverNewProducts(category, page);
  res.json({ discovered: products.length, products });
});

crawlerRouter.get('/jobs', async (req, res) => {
  const jobs = await prisma.crawlerJob.findMany({ orderBy: { createdAt: 'desc' }, take: 20 });
  res.json({ jobs });
});
