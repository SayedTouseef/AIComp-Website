import { adminRouter } from './_all-routes';
export default adminRouter;
