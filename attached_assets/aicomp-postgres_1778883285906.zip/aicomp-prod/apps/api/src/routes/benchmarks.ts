import { benchmarksRouter } from './_all-routes';
export default benchmarksRouter;
