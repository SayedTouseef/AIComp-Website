import { alertsRouter } from './_all-routes';
export default alertsRouter;
