import { analyticsRouter } from './_all-routes';
export default analyticsRouter;
