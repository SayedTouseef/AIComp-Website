import { pcBuilderRouter } from './_all-routes';
export default pcBuilderRouter;
