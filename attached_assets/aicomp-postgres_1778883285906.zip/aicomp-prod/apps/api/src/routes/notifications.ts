import { notificationsRouter } from './_all-routes';
export default notificationsRouter;
