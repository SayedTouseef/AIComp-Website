import { pricesRouter } from './_all-routes';
export default pricesRouter;
