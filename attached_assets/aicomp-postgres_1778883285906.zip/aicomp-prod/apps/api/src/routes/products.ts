import { Router, Request, Response } from 'express';
import { PrismaClient } from '@prisma/client';
import { z } from 'zod';
import { cache } from '../utils/cache';
import { requireAdmin } from '../middleware/auth';
import { generateProductSummary, calculateAiScores } from '../services/aiService';
import { logger } from '../utils/logger';

const router = Router();
const prisma = new PrismaClient();

// ─── Validation Schemas ────────────────────────────────────

const productQuerySchema = z.object({
  page: z.coerce.number().min(1).default(1),
  limit: z.coerce.number().min(1).max(100).default(24),
  category: z.string().optional(),
  brand: z.string().optional(),
  minPrice: z.coerce.number().optional(),
  maxPrice: z.coerce.number().optional(),
  sort: z.enum(['popular', 'newest', 'price_asc', 'price_desc', 'rating', 'trending']).default('popular'),
  search: z.string().optional(),
  status: z.enum(['APPROVED', 'PENDING', 'DRAFT']).optional(),
  isFeatured: z.coerce.boolean().optional(),
  isTrending: z.coerce.boolean().optional(),
});

// ─── GET /products — list with filters ────────────────────

router.get('/', async (req: Request, res: Response) => {
  try {
    const query = productQuerySchema.parse(req.query);
    const cacheKey = `products:list:${JSON.stringify(query)}`;
    const cached = await cache.get(cacheKey);
    if (cached) return res.json(JSON.parse(cached));

    const skip = (query.page - 1) * query.limit;

    const where: any = { status: query.status || 'APPROVED' };
    if (query.category) where.category = { slug: query.category };
    if (query.brand) where.brand = { slug: query.brand };
    if (query.isFeatured !== undefined) where.isFeatured = query.isFeatured;
    if (query.isTrending !== undefined) where.isTrending = query.isTrending;
    if (query.search) where.name = { contains: query.search, mode: 'insensitive' };

    // Price filter (join with prices)
    if (query.minPrice || query.maxPrice) {
      where.prices = {
        some: {
          price: {
            gte: query.minPrice ? query.minPrice * 100 : undefined,
            lte: query.maxPrice ? query.maxPrice * 100 : undefined,
          },
        },
      };
    }

    const orderBy: any = {
      popular: { viewCount: 'desc' },
      newest: { createdAt: 'desc' },
      price_asc: { prices: { _min: { price: 'asc' } } },
      price_desc: { prices: { _min: { price: 'desc' } } },
      rating: { avgRating: 'desc' },
      trending: { searchCount: 'desc' },
    }[query.sort] || { viewCount: 'desc' };

    const [products, total] = await Promise.all([
      prisma.product.findMany({
        where,
        skip,
        take: query.limit,
        orderBy,
        select: {
          id: true,
          name: true,
          slug: true,
          thumbnail: true,
          images: true,
          avgRating: true,
          reviewCount: true,
          overallScore: true,
          valueScore: true,
          isTrending: true,
          isFeatured: true,
          brand: { select: { name: true, slug: true, logo: true } },
          category: { select: { name: true, slug: true, emoji: true } },
          prices: {
            orderBy: { price: 'asc' },
            take: 3,
            include: { seller: { select: { name: true, logo: true } } },
          },
          _count: { select: { reviews: true } },
        },
      }),
      prisma.product.count({ where }),
    ]);

    const result = {
      products,
      pagination: {
        page: query.page,
        limit: query.limit,
        total,
        totalPages: Math.ceil(total / query.limit),
        hasNext: skip + query.limit < total,
        hasPrev: query.page > 1,
      },
    };

    await cache.setEx(cacheKey, 300, JSON.stringify(result)); // 5 min cache
    res.json(result);
  } catch (error) {
    if (error instanceof z.ZodError) return res.status(400).json({ error: error.errors });
    logger.error('Products list error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// ─── GET /products/:slug — single product ─────────────────

router.get('/:slug', async (req: Request, res: Response) => {
  try {
    const { slug } = req.params;
    const cacheKey = `product:${slug}`;
    const cached = await cache.get(cacheKey);
    if (cached) {
      // Increment view count async
      prisma.product.update({ where: { slug }, data: { viewCount: { increment: 1 } } }).catch(() => {});
      return res.json(JSON.parse(cached));
    }

    const product = await prisma.product.findUnique({
      where: { slug, status: 'APPROVED' },
      include: {
        brand: true,
        category: { include: { attributes: true } },
        specs: { orderBy: [{ groupName: 'asc' }, { sortOrder: 'asc' }] },
        prices: {
          orderBy: { price: 'asc' },
          include: { seller: true },
        },
        priceHistory: {
          orderBy: { recordedAt: 'desc' },
          take: 90, // last 90 data points
          select: { price: true, recordedAt: true, sellerId: true },
        },
        benchmarks: { orderBy: { category: 'asc' } },
        fpsData: { orderBy: [{ gameTitle: 'asc' }, { resolution: 'asc' }] },
        energyData: true,
        videos: { take: 6 },
        tags: true,
        affiliateLinks: { where: { isActive: true } },
        launchInfo: true,
        _count: { select: { reviews: true, wishlistItems: true } },
      },
    });

    if (!product) return res.status(404).json({ error: 'Product not found' });

    // Group specs
    const groupedSpecs = product.specs.reduce((acc, spec) => {
      if (!acc[spec.groupName]) acc[spec.groupName] = [];
      acc[spec.groupName].push({ name: spec.specName, value: spec.specValue, unit: spec.unit });
      return acc;
    }, {} as Record<string, any[]>);

    // Price stats
    const prices = product.prices;
    const priceStats = prices.length ? {
      min: Math.min(...prices.map(p => p.price)),
      max: Math.max(...prices.map(p => p.price)),
      avg: Math.round(prices.reduce((s, p) => s + p.price, 0) / prices.length),
      historicMin: product.priceHistory.length ? Math.min(...product.priceHistory.map(p => p.price)) : null,
      historicMax: product.priceHistory.length ? Math.max(...product.priceHistory.map(p => p.price)) : null,
    } : null;

    const result = { ...product, groupedSpecs, priceStats };

    // Cache 10 min for product pages
    await cache.setEx(cacheKey, 600, JSON.stringify(result));

    // Increment view async
    prisma.product.update({ where: { slug }, data: { viewCount: { increment: 1 } } }).catch(() => {});

    res.json(result);
  } catch (error) {
    logger.error('Product detail error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// ─── GET /products/:slug/similar ──────────────────────────

router.get('/:slug/similar', async (req: Request, res: Response) => {
  try {
    const { slug } = req.params;
    const product = await prisma.product.findUnique({
      where: { slug },
      select: { categoryId: true, brandId: true, prices: { take: 1, orderBy: { price: 'asc' } } },
    });
    if (!product) return res.status(404).json({ error: 'Not found' });

    const minPrice = product.prices[0]?.price || 0;
    const priceRange = minPrice * 0.3; // ±30%

    const similar = await prisma.product.findMany({
      where: {
        categoryId: product.categoryId,
        slug: { not: slug },
        status: 'APPROVED',
        prices: { some: { price: { gte: minPrice - priceRange, lte: minPrice + priceRange } } },
      },
      take: 6,
      orderBy: { viewCount: 'desc' },
      include: {
        brand: { select: { name: true } },
        prices: { take: 1, orderBy: { price: 'asc' }, include: { seller: { select: { name: true } } } },
      },
    });

    res.json({ similar });
  } catch (error) {
    res.status(500).json({ error: 'Internal server error' });
  }
});

// ─── GET /products/:slug/ai-summary ───────────────────────

router.get('/:slug/ai-summary', async (req: Request, res: Response) => {
  try {
    const { slug } = req.params;
    const cacheKey = `ai:summary:product:${slug}`;
    const cached = await cache.get(cacheKey);
    if (cached) return res.json(JSON.parse(cached));

    const product = await prisma.product.findUnique({
      where: { slug },
      include: {
        brand: true,
        category: true,
        specs: { take: 30 },
        prices: { take: 1, orderBy: { price: 'asc' } },
      },
    });
    if (!product) return res.status(404).json({ error: 'Not found' });

    const specsObj = product.specs.reduce((a, s) => ({ ...a, [s.specName]: s.specValue }), {});
    const summary = await generateProductSummary({
      id: product.id,
      name: product.name,
      brand: product.brand.name,
      category: product.category.name,
      specs: specsObj,
      price: product.prices[0]?.price,
    });

    await cache.setEx(cacheKey, 86400 * 7, JSON.stringify(summary));
    res.json(summary);
  } catch (error) {
    res.status(500).json({ error: 'Internal server error' });
  }
});

// ─── POST /products — admin create ────────────────────────

router.post('/', requireAdmin, async (req: Request, res: Response) => {
  try {
    const { name, brandId, categoryId, description, specs, images, releaseDate } = req.body;

    const slug = name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');

    const product = await prisma.product.create({
      data: {
        name,
        slug: `${slug}-${Date.now()}`,
        brandId,
        categoryId,
        description,
        images: images || [],
        thumbnail: images?.[0] || null,
        releaseDate: releaseDate ? new Date(releaseDate) : null,
        status: 'PENDING',
      },
    });

    // Create specs if provided
    if (specs) {
      for (const [group, specItems] of Object.entries(specs as Record<string, any[]>)) {
        for (const [idx, item] of (specItems as any[]).entries()) {
          await prisma.productSpec.create({
            data: {
              productId: product.id,
              groupName: group,
              specName: item.name,
              specValue: item.value,
              unit: item.unit || null,
              sortOrder: idx,
            },
          });
        }
      }
    }

    res.status(201).json({ product });
  } catch (error) {
    logger.error('Product create error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// ─── PUT /products/:id/approve — admin ────────────────────

router.put('/:id/approve', requireAdmin, async (req: Request, res: Response) => {
  try {
    const product = await prisma.product.update({
      where: { id: req.params.id },
      data: {
        status: 'APPROVED',
        approvedAt: new Date(),
        approvedBy: (req as any).user?.id,
      },
    });
    // Trigger AI score generation async
    calculateAiScores({
      id: product.id,
      name: product.name,
      brand: '',
      category: '',
      specs: {},
      price: undefined,
    }).catch(() => {});

    res.json({ product });
  } catch (error) {
    res.status(500).json({ error: 'Internal server error' });
  }
});

// ─── DELETE /products/:id — admin ─────────────────────────

router.delete('/:id', requireAdmin, async (req: Request, res: Response) => {
  try {
    await prisma.product.update({
      where: { id: req.params.id },
      data: { status: 'ARCHIVED' },
    });
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: 'Internal server error' });
  }
});

export default router;
