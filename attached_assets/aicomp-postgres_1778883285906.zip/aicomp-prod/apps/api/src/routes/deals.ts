import { dealsRouter } from './_all-routes';
export default dealsRouter;
