import { categoriesRouter } from './_all-routes';
export default categoriesRouter;
