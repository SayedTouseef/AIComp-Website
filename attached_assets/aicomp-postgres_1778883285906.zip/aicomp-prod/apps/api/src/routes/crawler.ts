import { crawlerRouter } from './_all-routes';
export default crawlerRouter;
