import { Router, Request, Response } from 'express';
import { z } from 'zod';
import {
  chatWithAI,
  streamChatWithAI,
  generateComparisonVerdict,
  predictBuyingTime,
  analyzeReviews,
  generateSeoContent,
} from '../services/aiService';
import { PrismaClient } from '@prisma/client';
import { cache } from '../utils/cache';
import { logger } from '../utils/logger';

const router = Router();
const prisma = new PrismaClient();

// ─── POST /ai/chat ─────────────────────────────────────────

router.post('/chat', async (req: Request, res: Response) => {
  try {
    const { messages, context } = req.body;
    if (!messages || !Array.isArray(messages)) {
      return res.status(400).json({ error: 'messages array required' });
    }

    // Validate message count
    if (messages.length > 30) {
      return res.status(400).json({ error: 'Too many messages in conversation' });
    }

    const reply = await chatWithAI(messages, context);
    res.json({ reply, role: 'assistant' });
  } catch (error) {
    logger.error('AI chat error:', error);
    res.status(500).json({ error: 'AI service unavailable' });
  }
});

// ─── POST /ai/chat/stream ──────────────────────────────────

router.post('/chat/stream', async (req: Request, res: Response) => {
  try {
    const { messages, context } = req.body;

    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');
    res.flushHeaders();

    const stream = streamChatWithAI(messages, context);
    for await (const chunk of stream) {
      res.write(`data: ${JSON.stringify({ chunk })}\n\n`);
    }
    res.write('data: [DONE]\n\n');
    res.end();
  } catch (error) {
    logger.error('AI stream error:', error);
    res.write(`data: ${JSON.stringify({ error: 'Stream error' })}\n\n`);
    res.end();
  }
});

// ─── POST /ai/compare ─────────────────────────────────────

router.post('/compare', async (req: Request, res: Response) => {
  try {
    const { productIds } = req.body;
    if (!productIds || productIds.length < 2) {
      return res.status(400).json({ error: 'At least 2 product IDs required' });
    }

    const cacheKey = `ai:compare:${[...productIds].sort().join('-')}`;
    const cached = await cache.get(cacheKey);
    if (cached) return res.json(JSON.parse(cached));

    const products = await prisma.product.findMany({
      where: { id: { in: productIds } },
      include: {
        brand: true,
        category: true,
        specs: { take: 20 },
        prices: { take: 1, orderBy: { price: 'asc' } },
      },
    });

    const formattedProducts = products.map(p => ({
      id: p.id,
      name: p.name,
      brand: p.brand.name,
      category: p.category.name,
      specs: p.specs.reduce((a, s) => ({ ...a, [s.specName]: s.specValue }), {}),
      price: p.prices[0]?.price,
    }));

    const verdict = await generateComparisonVerdict(formattedProducts);

    await cache.setEx(cacheKey, 86400, JSON.stringify(verdict)); // 1 day cache
    res.json(verdict);
  } catch (error) {
    logger.error('AI compare error:', error);
    res.status(500).json({ error: 'AI service unavailable' });
  }
});

// ─── GET /ai/should-i-buy/:productId ──────────────────────

router.get('/should-i-buy/:productId', async (req: Request, res: Response) => {
  try {
    const { productId } = req.params;
    const cacheKey = `ai:buy:${productId}`;
    const cached = await cache.get(cacheKey);
    if (cached) return res.json(JSON.parse(cached));

    const product = await prisma.product.findUnique({
      where: { id: productId },
      include: {
        category: { select: { name: true } },
        prices: { take: 1, orderBy: { price: 'asc' } },
        priceHistory: {
          orderBy: { recordedAt: 'desc' },
          take: 60,
          select: { price: true, recordedAt: true },
        },
      },
    });

    if (!product) return res.status(404).json({ error: 'Product not found' });
    if (!product.prices[0]) return res.status(400).json({ error: 'No price data available' });

    const prediction = await predictBuyingTime({
      name: product.name,
      currentPrice: product.prices[0].price,
      category: product.category.name,
      priceHistory: product.priceHistory.map(h => ({
        price: h.price,
        date: h.recordedAt.toISOString(),
      })),
    });

    await cache.setEx(cacheKey, 21600, JSON.stringify(prediction)); // 6 hours
    res.json(prediction);
  } catch (error) {
    logger.error('Buy prediction error:', error);
    res.status(500).json({ error: 'AI service unavailable' });
  }
});

// ─── POST /ai/analyze-reviews ─────────────────────────────

router.post('/analyze-reviews', async (req: Request, res: Response) => {
  try {
    const { productId } = req.body;
    const cacheKey = `ai:reviews:${productId}`;
    const cached = await cache.get(cacheKey);
    if (cached) return res.json(JSON.parse(cached));

    const reviews = await prisma.review.findMany({
      where: { productId, isApproved: true },
      select: { body: true, rating: true },
      take: 30,
    });

    if (reviews.length < 3) {
      return res.json({ error: 'Not enough reviews to analyze' });
    }

    const analysis = await analyzeReviews(reviews.map(r => `Rating: ${r.rating}/5 — ${r.body}`));

    await cache.setEx(cacheKey, 86400, JSON.stringify(analysis));
    res.json(analysis);
  } catch (error) {
    logger.error('Review analysis error:', error);
    res.status(500).json({ error: 'AI service unavailable' });
  }
});

// ─── POST /ai/generate-seo ────────────────────────────────

router.post('/generate-seo', async (req: Request, res: Response) => {
  try {
    const { type, topic, products, category, keywords } = req.body;
    const content = await generateSeoContent({ type, topic, products, category, keywords });
    res.json(content);
  } catch (error) {
    logger.error('SEO generation error:', error);
    res.status(500).json({ error: 'AI service unavailable' });
  }
});

// ─── POST /ai/recommend ───────────────────────────────────

router.post('/recommend', async (req: Request, res: Response) => {
  try {
    const { prompt, budget, category, useCase } = req.body;

    const systemPrompt = `You are AIComp's product recommender. Suggest 3-5 specific products with:
- Exact model name
- Price in ₹ 
- One line reason why
- Best place to buy in India
Return as JSON array: [{"name": "", "price": 0, "reason": "", "buyAt": ""}]`;

    const { chatWithAI } = await import('../services/aiService');
    const response = await chatWithAI([
      { role: 'user', content: `${prompt || ''} Budget: ₹${budget || 'flexible'}, Category: ${category || 'any'}, Use case: ${useCase || 'general'}` }
    ], { budget, useCase, category });

    // Try to parse JSON from response
    try {
      const jsonMatch = response.match(/\[[\s\S]*\]/);
      if (jsonMatch) {
        const recommendations = JSON.parse(jsonMatch[0]);
        return res.json({ recommendations, rawResponse: response });
      }
    } catch {}

    res.json({ recommendations: [], rawResponse: response });
  } catch (error) {
    res.status(500).json({ error: 'AI service unavailable' });
  }
});

// ─── GET /ai/trending-insights ────────────────────────────

router.get('/trending-insights', async (req: Request, res: Response) => {
  try {
    const cacheKey = 'ai:trending:insights';
    const cached = await cache.get(cacheKey);
    if (cached) return res.json(JSON.parse(cached));

    const [topSearched, topCompared, topViewed, recentAlerts] = await Promise.all([
      prisma.searchLog.groupBy({
        by: ['query'],
        _count: { query: true },
        orderBy: { _count: { query: 'desc' } },
        take: 10,
        where: { createdAt: { gte: new Date(Date.now() - 86400000) } }, // last 24h
      }),
      prisma.product.findMany({
        orderBy: { compareCount: 'desc' },
        take: 5,
        select: { name: true, slug: true, compareCount: true, thumbnail: true },
      }),
      prisma.product.findMany({
        orderBy: { viewCount: 'desc' },
        take: 10,
        where: { status: 'APPROVED' },
        select: { name: true, slug: true, viewCount: true, thumbnail: true, brand: { select: { name: true } } },
      }),
      prisma.priceHistory.findMany({
        orderBy: { recordedAt: 'desc' },
        take: 5,
        select: { productId: true, price: true, recordedAt: true },
      }),
    ]);

    const insights = { topSearched, topCompared, topViewed };
    await cache.setEx(cacheKey, 1800, JSON.stringify(insights)); // 30 min
    res.json(insights);
  } catch (error) {
    res.status(500).json({ error: 'Internal server error' });
  }
});

export default router;
