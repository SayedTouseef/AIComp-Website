import { compareRouter } from './_all-routes';
export default compareRouter;
