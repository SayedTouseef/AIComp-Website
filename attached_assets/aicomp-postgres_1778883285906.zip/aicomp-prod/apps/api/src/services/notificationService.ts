import nodemailer from 'nodemailer';
import * as admin from 'firebase-admin';
import axios from 'axios';
import { logger } from '../utils/logger';

// ─── Initialize Firebase ───────────────────────────────────

let firebaseApp: admin.app.App | null = null;

function getFirebaseApp() {
  if (!firebaseApp) {
    firebaseApp = admin.initializeApp({
      credential: admin.credential.cert({
        projectId: process.env.FIREBASE_PROJECT_ID,
        clientEmail: process.env.FIREBASE_CLIENT_EMAIL,
        privateKey: process.env.FIREBASE_PRIVATE_KEY?.replace(/\\n/g, '\n'),
      }),
    });
  }
  return firebaseApp;
}

// ─── Email transporter ─────────────────────────────────────

const emailTransporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST || 'smtp.gmail.com',
  port: parseInt(process.env.SMTP_PORT || '587'),
  secure: false,
  auth: {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASS,
  },
});

// ─── Types ────────────────────────────────────────────────

interface NotificationPayload {
  title: string;
  body: string;
  imageUrl?: string;
  actionUrl?: string;
  data?: Record<string, string>;
}

interface UserContactInfo {
  email?: string;
  name?: string;
  pushToken?: string;
  telegramChatId?: string;
  whatsappNumber?: string;
}

// ─── Push notification (FCM) ──────────────────────────────

export async function sendPushNotification(
  token: string,
  payload: NotificationPayload
): Promise<boolean> {
  try {
    const app = getFirebaseApp();
    await admin.messaging(app).send({
      token,
      notification: {
        title: payload.title,
        body: payload.body,
        imageUrl: payload.imageUrl,
      },
      data: {
        actionUrl: payload.actionUrl || 'https://aicomp.in',
        ...payload.data,
      },
      android: {
        priority: 'high',
        notification: {
          clickAction: 'FLUTTER_NOTIFICATION_CLICK',
          channelId: 'aicomp_deals',
          sound: 'default',
        },
      },
      apns: {
        payload: {
          aps: {
            badge: 1,
            sound: 'default',
          },
        },
      },
    });
    return true;
  } catch (error) {
    logger.error('Push notification failed:', error);
    return false;
  }
}

// ─── Email notification ───────────────────────────────────

export async function sendEmailNotification(
  to: string,
  name: string,
  payload: NotificationPayload
): Promise<boolean> {
  try {
    const html = generateEmailHTML(name, payload);
    await emailTransporter.sendMail({
      from: `"AIComp" <${process.env.EMAIL_FROM || 'hello@aicomp.in'}>`,
      to,
      subject: payload.title,
      html,
    });
    return true;
  } catch (error) {
    logger.error('Email notification failed:', error);
    return false;
  }
}

function generateEmailHTML(name: string, payload: NotificationPayload): string {
  return `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${payload.title}</title>
</head>
<body style="margin:0;padding:0;background:#050810;font-family:'DM Sans',sans-serif;">
  <div style="max-width:600px;margin:0 auto;padding:40px 24px;">
    <!-- Logo -->
    <div style="margin-bottom:32px;">
      <span style="background:linear-gradient(135deg,#63b3ed,#9f7aea);padding:4px 12px;border-radius:8px;font-size:14px;font-weight:800;color:white;">AIComp</span>
    </div>

    <!-- Card -->
    <div style="background:rgba(255,255,255,0.03);border:1px solid rgba(255,255,255,0.07);border-radius:20px;overflow:hidden;">
      ${payload.imageUrl ? `<img src="${payload.imageUrl}" style="width:100%;height:200px;object-fit:cover;" alt="">` : ''}
      <div style="padding:32px;">
        <p style="color:#6b7a9a;font-size:13px;margin:0 0 8px;">Hey ${name || 'there'},</p>
        <h1 style="color:#e8edf8;font-size:24px;margin:0 0 16px;font-weight:700;">${payload.title}</h1>
        <p style="color:#6b7a9a;font-size:15px;line-height:1.6;margin:0 0 32px;">${payload.body}</p>
        ${payload.actionUrl ? `
          <a href="${payload.actionUrl}" style="display:inline-block;background:linear-gradient(135deg,#63b3ed,#9f7aea);color:white;text-decoration:none;padding:14px 32px;border-radius:12px;font-weight:600;font-size:15px;">
            View Deal →
          </a>
        ` : ''}
      </div>
    </div>

    <!-- Footer -->
    <div style="margin-top:32px;text-align:center;">
      <p style="color:#3a4460;font-size:12px;">
        © 2025 AIComp · <a href="https://aicomp.in" style="color:#3a4460;">aicomp.in</a><br>
        <a href="https://aicomp.in/unsubscribe" style="color:#3a4460;">Unsubscribe</a>
      </p>
    </div>
  </div>
</body>
</html>`;
}

// ─── Telegram notification ────────────────────────────────

export async function sendTelegramNotification(
  chatId: string,
  payload: NotificationPayload
): Promise<boolean> {
  try {
    const botToken = process.env.TELEGRAM_BOT_TOKEN;
    if (!botToken) return false;

    const text = `*${escapeMarkdown(payload.title)}*\n\n${escapeMarkdown(payload.body)}${
      payload.actionUrl ? `\n\n[View on AIComp](${payload.actionUrl})` : ''
    }`;

    await axios.post(`https://api.telegram.org/bot${botToken}/sendMessage`, {
      chat_id: chatId,
      text,
      parse_mode: 'MarkdownV2',
      disable_web_page_preview: false,
    });

    return true;
  } catch (error) {
    logger.error('Telegram notification failed:', error);
    return false;
  }
}

function escapeMarkdown(text: string): string {
  return text.replace(/[_*[\]()~`>#+\-=|{}.!]/g, '\\$&');
}

// ─── WhatsApp notification (via Twilio/WhatsApp Cloud API) ─

export async function sendWhatsAppNotification(
  phoneNumber: string,
  payload: NotificationPayload
): Promise<boolean> {
  try {
    const accessToken = process.env.WHATSAPP_ACCESS_TOKEN;
    const phoneNumberId = process.env.WHATSAPP_PHONE_NUMBER_ID;
    if (!accessToken || !phoneNumberId) return false;

    await axios.post(
      `https://graph.facebook.com/v18.0/${phoneNumberId}/messages`,
      {
        messaging_product: 'whatsapp',
        to: phoneNumber.replace(/\D/g, ''),
        type: 'template',
        template: {
          name: 'price_alert',
          language: { code: 'en' },
          components: [
            {
              type: 'body',
              parameters: [
                { type: 'text', text: payload.title },
                { type: 'text', text: payload.body },
              ],
            },
            ...(payload.actionUrl ? [{
              type: 'button',
              sub_type: 'url',
              index: 0,
              parameters: [{ type: 'text', text: payload.actionUrl }],
            }] : []),
          ],
        },
      },
      { headers: { Authorization: `Bearer ${accessToken}`, 'Content-Type': 'application/json' } }
    );

    return true;
  } catch (error) {
    logger.error('WhatsApp notification failed:', error);
    return false;
  }
}

// ─── Multi-channel dispatcher ─────────────────────────────

export async function sendNotification(
  channel: 'PUSH' | 'EMAIL' | 'WHATSAPP' | 'TELEGRAM' | 'BROWSER',
  user: UserContactInfo,
  payload: NotificationPayload
): Promise<boolean> {
  switch (channel) {
    case 'PUSH':
      if (!user.pushToken) return false;
      return sendPushNotification(user.pushToken, payload);

    case 'EMAIL':
      if (!user.email) return false;
      return sendEmailNotification(user.email, user.name || '', payload);

    case 'TELEGRAM':
      if (!user.telegramChatId) return false;
      return sendTelegramNotification(user.telegramChatId, payload);

    case 'WHATSAPP':
      if (!user.whatsappNumber) return false;
      return sendWhatsAppNotification(user.whatsappNumber, payload);

    default:
      return false;
  }
}

// ─── Bulk notification sender ─────────────────────────────

export async function sendBulkNotification(
  users: Array<{ id: string; contactInfo: UserContactInfo; channels: string[] }>,
  payload: NotificationPayload
): Promise<{ sent: number; failed: number }> {
  let sent = 0;
  let failed = 0;

  const BATCH_SIZE = 50;
  for (let i = 0; i < users.length; i += BATCH_SIZE) {
    const batch = users.slice(i, i + BATCH_SIZE);
    await Promise.all(
      batch.map(async user => {
        for (const channel of user.channels) {
          const ok = await sendNotification(channel as any, user.contactInfo, payload);
          ok ? sent++ : failed++;
        }
      })
    );
    // Rate limit between batches
    if (i + BATCH_SIZE < users.length) {
      await new Promise(r => setTimeout(r, 1000));
    }
  }

  return { sent, failed };
}

export function startNotificationWorker() {
  logger.info('🔔 Notification worker ready');
}
