import { chromium, Browser, Page } from 'playwright';
import * as cheerio from 'cheerio';
import axios from 'axios';
import { PrismaClient } from '@prisma/client';
import { logger } from '../utils/logger';
import { priceQueue } from '../utils/queues';

const prisma = new PrismaClient();

// ─── Seller configs ───────────────────────────────────────

interface SellerConfig {
  name: string;
  baseUrl: string;
  searchUrl: (query: string) => string;
  selectors: {
    price: string;
    title: string;
    image: string;
    inStock: string;
    mrp?: string;
  };
  usePlaywright?: boolean;
  rateLimit: number; // ms between requests
}

const SELLERS: SellerConfig[] = [
  {
    name: 'Amazon',
    baseUrl: 'https://www.amazon.in',
    searchUrl: (q) => `https://www.amazon.in/s?k=${encodeURIComponent(q)}`,
    selectors: {
      price: '.a-price-whole',
      title: 'span.a-text-normal',
      image: '.s-image',
      inStock: '.a-color-base',
      mrp: '.a-price.a-text-price .a-offscreen',
    },
    usePlaywright: true,
    rateLimit: 3000,
  },
  {
    name: 'Flipkart',
    baseUrl: 'https://www.flipkart.com',
    searchUrl: (q) => `https://www.flipkart.com/search?q=${encodeURIComponent(q)}`,
    selectors: {
      price: '._30jeq3',
      title: '._4rR01T',
      image: '._396cs4',
      inStock: '.In-Stock',
      mrp: '._3I9_wc',
    },
    usePlaywright: true,
    rateLimit: 3000,
  },
  {
    name: 'Croma',
    baseUrl: 'https://www.croma.com',
    searchUrl: (q) => `https://www.croma.com/searchB?q=${encodeURIComponent(q)}`,
    selectors: {
      price: '.pdp-selling-price',
      title: '.pdp-product-title',
      image: '.pdp-main-image',
      inStock: '.in-stock',
      mrp: '.pdp-mrp',
    },
    usePlaywright: true,
    rateLimit: 4000,
  },
];

// ─── Browser manager (singleton) ─────────────────────────

let browser: Browser | null = null;

async function getBrowser(): Promise<Browser> {
  if (!browser || !browser.isConnected()) {
    browser = await chromium.launch({
      headless: true,
      args: [
        '--no-sandbox',
        '--disable-setuid-sandbox',
        '--disable-dev-shm-usage',
        '--disable-accelerated-2d-canvas',
        '--no-first-run',
        '--no-zygote',
        '--disable-gpu',
        '--user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
      ],
    });
  }
  return browser;
}

// ─── Sleep utility ────────────────────────────────────────

const sleep = (ms: number) => new Promise(r => setTimeout(r, ms));

// ─── Extract price from text ──────────────────────────────

function parsePrice(text: string): number | null {
  const cleaned = text.replace(/[₹,\s]/g, '');
  const num = parseFloat(cleaned);
  return isNaN(num) ? null : Math.round(num * 100); // store in paise
}

// ─── Amazon price scraper ─────────────────────────────────

export async function scrapeAmazonPrice(asin: string): Promise<{
  price: number | null;
  mrp: number | null;
  inStock: boolean;
  title: string;
}> {
  const b = await getBrowser();
  const page = await b.newPage();

  try {
    await page.setExtraHTTPHeaders({
      'Accept-Language': 'en-IN,en;q=0.9',
      'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    });

    await page.goto(`https://www.amazon.in/dp/${asin}`, {
      waitUntil: 'domcontentloaded',
      timeout: 15000,
    });

    // Wait for price
    await page.waitForSelector('.a-price-whole', { timeout: 8000 }).catch(() => {});

    const data = await page.evaluate(() => {
      const priceEl = document.querySelector('.a-price-whole');
      const mrpEl = document.querySelector('.a-price.a-text-price .a-offscreen');
      const titleEl = document.querySelector('#productTitle');
      const inStockEl = document.querySelector('#availability span');

      return {
        price: priceEl?.textContent?.trim() || null,
        mrp: mrpEl?.textContent?.trim() || null,
        title: titleEl?.textContent?.trim() || '',
        inStock: !inStockEl?.textContent?.toLowerCase().includes('out of stock'),
      };
    });

    return {
      price: data.price ? parsePrice(data.price) : null,
      mrp: data.mrp ? parsePrice(data.mrp) : null,
      inStock: data.inStock,
      title: data.title,
    };
  } catch (error) {
    logger.error(`Amazon scrape failed for ASIN ${asin}:`, error);
    return { price: null, mrp: null, inStock: false, title: '' };
  } finally {
    await page.close();
  }
}

// ─── Flipkart price scraper ───────────────────────────────

export async function scrapeFlipkartPrice(url: string): Promise<{
  price: number | null;
  mrp: number | null;
  inStock: boolean;
}> {
  const b = await getBrowser();
  const page = await b.newPage();

  try {
    await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 15000 });
    await page.waitForSelector('._30jeq3', { timeout: 8000 }).catch(() => {});

    const data = await page.evaluate(() => {
      const priceEl = document.querySelector('._30jeq3');
      const mrpEl = document.querySelector('._3I9_wc');
      const stockEl = document.querySelector('._16FRp0');

      return {
        price: priceEl?.textContent?.trim() || null,
        mrp: mrpEl?.textContent?.trim() || null,
        inStock: !stockEl,
      };
    });

    return {
      price: data.price ? parsePrice(data.price) : null,
      mrp: data.mrp ? parsePrice(data.mrp) : null,
      inStock: data.inStock,
    };
  } catch (error) {
    logger.error(`Flipkart scrape failed for ${url}:`, error);
    return { price: null, mrp: null, inStock: false };
  } finally {
    await page.close();
  }
}

// ─── Product discovery crawler ────────────────────────────

export async function discoverNewProducts(category: string, page = 1): Promise<Array<{
  name: string;
  brand: string;
  specs: Record<string, string>;
  images: string[];
  prices: Array<{ seller: string; price: number; url: string }>;
  source: string;
}>> {
  const b = await getBrowser();
  const browserPage = await b.newPage();
  const discovered: any[] = [];

  try {
    // Amazon category search
    const url = `https://www.amazon.in/s?k=${encodeURIComponent(category)}&page=${page}`;
    await browserPage.goto(url, { waitUntil: 'networkidle', timeout: 20000 });

    const products = await browserPage.evaluate(() => {
      const items = document.querySelectorAll('[data-component-type="s-search-result"]');
      return Array.from(items).slice(0, 12).map(item => {
        const titleEl = item.querySelector('h2 a span');
        const priceEl = item.querySelector('.a-price-whole');
        const imageEl = item.querySelector('.s-image') as HTMLImageElement;
        const asinEl = item as HTMLElement;

        return {
          name: titleEl?.textContent?.trim() || '',
          price: priceEl?.textContent?.replace(/[,]/g, '') || '0',
          image: imageEl?.src || '',
          asin: asinEl?.dataset?.asin || '',
          url: (item.querySelector('h2 a') as HTMLAnchorElement)?.href || '',
        };
      }).filter(p => p.name && p.price !== '0');
    });

    for (const product of products) {
      if (!product.name) continue;
      discovered.push({
        name: product.name,
        brand: extractBrand(product.name),
        specs: {},
        images: [product.image],
        prices: [{ seller: 'Amazon', price: parseInt(product.price) * 100, url: product.url }],
        source: 'amazon',
        externalId: product.asin,
      });
    }
  } catch (error) {
    logger.error(`Product discovery failed for ${category}:`, error);
  } finally {
    await browserPage.close();
  }

  return discovered;
}

// ─── Bulk price update job ────────────────────────────────

export async function updateAllPrices(): Promise<void> {
  logger.info('Starting bulk price update...');

  const affiliateLinks = await prisma.affiliateLink.findMany({
    where: { isActive: true, network: { in: ['AMAZON', 'FLIPKART'] } },
    include: { product: { select: { id: true, name: true } } },
    take: 200, // batch size
  });

  let updated = 0;
  let failed = 0;

  for (const link of affiliateLinks) {
    try {
      await sleep(2000); // rate limit
      let priceData: any = null;

      if (link.network === 'AMAZON' && link.trackingId) {
        priceData = await scrapeAmazonPrice(link.trackingId);
      } else if (link.network === 'FLIPKART') {
        priceData = await scrapeFlipkartPrice(link.url);
      }

      if (priceData?.price) {
        // Update current price
        await prisma.productPrice.upsert({
          where: { productId_sellerId: { productId: link.productId, sellerId: link.sellerId! } },
          update: {
            price: priceData.price,
            mrp: priceData.mrp,
            inStock: priceData.inStock,
            lastChecked: new Date(),
          },
          create: {
            productId: link.productId,
            sellerId: link.sellerId!,
            price: priceData.price,
            mrp: priceData.mrp,
            inStock: priceData.inStock,
            affiliateUrl: link.url,
          },
        });

        // Record price history
        await prisma.priceHistory.create({
          data: {
            productId: link.productId,
            sellerId: link.sellerId,
            price: priceData.price,
          },
        });

        updated++;

        // Check for price drop alerts
        await checkPriceAlerts(link.productId, priceData.price);
      }
    } catch (err) {
      failed++;
      logger.error(`Price update failed for product ${link.productId}:`, err);
    }
  }

  logger.info(`Price update complete: ${updated} updated, ${failed} failed`);
}

// ─── Price alert checker ──────────────────────────────────

async function checkPriceAlerts(productId: string, newPrice: number): Promise<void> {
  const alerts = await prisma.priceAlert.findMany({
    where: {
      productId,
      isActive: true,
      OR: [
        { targetPrice: null }, // any drop
        { targetPrice: { gte: newPrice } }, // price reached target
      ],
    },
    include: { user: { include: { profile: true } } },
  });

  for (const alert of alerts) {
    await priceQueue.add('send-price-alert', {
      alertId: alert.id,
      userId: alert.userId,
      productId,
      newPrice,
      channels: alert.channels,
    });
  }
}

// ─── Helpers ──────────────────────────────────────────────

function extractBrand(productName: string): string {
  const brands = ['Apple', 'Samsung', 'Google', 'OnePlus', 'Realme', 'Poco', 'Xiaomi', 'ASUS', 'Lenovo', 'HP', 'Dell', 'Sony', 'LG', 'Bosch', 'Daikin', 'Voltas'];
  for (const brand of brands) {
    if (productName.toLowerCase().startsWith(brand.toLowerCase())) return brand;
  }
  return productName.split(' ')[0];
}

export async function closeBrowser(): Promise<void> {
  if (browser) {
    await browser.close();
    browser = null;
  }
}

export default {
  scrapeAmazonPrice,
  scrapeFlipkartPrice,
  discoverNewProducts,
  updateAllPrices,
};
