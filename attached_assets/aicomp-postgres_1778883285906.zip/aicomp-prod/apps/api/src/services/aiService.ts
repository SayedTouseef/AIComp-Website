import OpenAI from 'openai';
import { logger } from '../utils/logger';
import { cache } from '../utils/cache';

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

// ─── Types ────────────────────────────────────────────────

interface Product {
  id: string;
  name: string;
  brand: string;
  category: string;
  specs: Record<string, string>;
  price?: number;
  scores?: Record<string, number>;
}

interface ChatMessage {
  role: 'user' | 'assistant' | 'system';
  content: string;
}

// ─── Core AI Chat (Shopping Assistant) ───────────────────

export async function chatWithAI(
  messages: ChatMessage[],
  context?: { budget?: number; useCase?: string; category?: string }
): Promise<string> {
  const systemPrompt = `You are AIComp's AI Shopping Assistant — an expert electronics buying advisor for the Indian market.

Your capabilities:
- Recommend specific products with exact model names and prices in ₹ (Indian Rupees)
- Compare products across specs, value, performance, gaming, battery life
- Explain technical specs in simple terms
- Know about Amazon India, Flipkart, Croma, Reliance Digital pricing
- Understand use cases: gaming, photography, office work, streaming, coding, video editing
- Consider budgets: "budget" (under ₹20K), "mid-range" (₹20K-60K), "premium" (₹60K+)
- Give honest pros/cons, not just positive reviews

Format your responses:
- Use bullet points for lists
- Bold important specs like **6000 mAh battery**
- Include approximate prices: ~₹45,000
- Give a clear TOP RECOMMENDATION at the end

Context: ${JSON.stringify(context || {})}

Always end with: "Want me to compare these in detail or find the best price right now?"`;

  const response = await openai.chat.completions.create({
    model: 'gpt-4-turbo-preview',
    messages: [{ role: 'system', content: systemPrompt }, ...messages],
    max_tokens: 1000,
    temperature: 0.7,
    stream: false,
  });

  return response.choices[0].message.content || '';
}

// ─── Streaming chat ──────────────────────────────────────

export async function* streamChatWithAI(
  messages: ChatMessage[],
  context?: object
): AsyncGenerator<string> {
  const systemPrompt = `You are AIComp's AI Shopping Assistant for Indian electronics market. Be concise, specific, and always mention Indian prices in ₹.`;

  const stream = await openai.chat.completions.create({
    model: 'gpt-4-turbo-preview',
    messages: [{ role: 'system', content: systemPrompt }, ...messages],
    max_tokens: 800,
    temperature: 0.7,
    stream: true,
  });

  for await (const chunk of stream) {
    const delta = chunk.choices[0]?.delta?.content;
    if (delta) yield delta;
  }
}

// ─── Product Summary Generator ───────────────────────────

export async function generateProductSummary(product: Product): Promise<{
  summary: string;
  pros: string[];
  cons: string[];
  verdict: string;
  bestFor: string[];
  notFor: string[];
}> {
  const cacheKey = `ai:summary:${product.id}`;
  const cached = await cache.get(cacheKey);
  if (cached) return JSON.parse(cached);

  const prompt = `Generate a comprehensive product analysis for the Indian market.

Product: ${product.name}
Brand: ${product.brand}
Category: ${product.category}
Specs: ${JSON.stringify(product.specs, null, 2)}
Price: ₹${product.price?.toLocaleString('en-IN') || 'Unknown'}

Return ONLY valid JSON (no markdown, no backticks):
{
  "summary": "2-3 sentence overview",
  "pros": ["pro1", "pro2", "pro3", "pro4", "pro5"],
  "cons": ["con1", "con2", "con3"],
  "verdict": "One sentence buying verdict",
  "bestFor": ["use case 1", "use case 2", "use case 3"],
  "notFor": ["who should avoid 1", "who should avoid 2"]
}`;

  const response = await openai.chat.completions.create({
    model: 'gpt-4-turbo-preview',
    messages: [{ role: 'user', content: prompt }],
    max_tokens: 600,
    temperature: 0.5,
  });

  try {
    const result = JSON.parse(response.choices[0].message.content || '{}');
    await cache.setEx(cacheKey, 86400 * 7, JSON.stringify(result)); // Cache 7 days
    return result;
  } catch (e) {
    logger.error('Failed to parse AI summary JSON', e);
    return { summary: '', pros: [], cons: [], verdict: '', bestFor: [], notFor: [] };
  }
}

// ─── Comparison AI Verdict ────────────────────────────────

export async function generateComparisonVerdict(products: Product[]): Promise<{
  winner: string;
  verdict: string;
  perCategory: Record<string, string>;
  recommendation: string;
}> {
  const cacheKey = `ai:compare:${products.map(p => p.id).sort().join('-')}`;
  const cached = await cache.get(cacheKey);
  if (cached) return JSON.parse(cached);

  const prompt = `Compare these products for Indian buyers and return ONLY valid JSON:

Products:
${products.map(p => `${p.name}: ${JSON.stringify(p.specs)}, Price: ₹${p.price?.toLocaleString('en-IN')}`).join('\n')}

Return:
{
  "winner": "product name that wins overall",
  "verdict": "2-3 sentence overall comparison",
  "perCategory": {
    "value": "which wins on value",
    "gaming": "which wins for gaming",
    "battery": "which wins on battery",
    "camera": "which wins on camera",
    "performance": "which wins on performance"
  },
  "recommendation": "Final buying recommendation for Indian buyers"
}`;

  const response = await openai.chat.completions.create({
    model: 'gpt-4-turbo-preview',
    messages: [{ role: 'user', content: prompt }],
    max_tokens: 500,
    temperature: 0.4,
  });

  try {
    const result = JSON.parse(response.choices[0].message.content || '{}');
    await cache.setEx(cacheKey, 86400 * 3, JSON.stringify(result));
    return result;
  } catch (e) {
    return { winner: '', verdict: '', perCategory: {}, recommendation: '' };
  }
}

// ─── Spec Extraction & Normalization ─────────────────────

export async function extractAndNormalizeSpecs(
  rawText: string,
  category: string
): Promise<Record<string, Record<string, string>>> {
  const prompt = `Extract and normalize product specifications from this raw text for category: ${category}

Raw text:
${rawText.slice(0, 3000)}

Return ONLY valid JSON with grouped specs:
{
  "Display": { "Screen Size": "6.7 inches", "Resolution": "2400x1080", "Type": "AMOLED" },
  "Performance": { "Processor": "Snapdragon 8 Gen 3", "RAM": "12 GB", "Storage": "256 GB" },
  "Camera": { "Main Camera": "200 MP", "Front Camera": "12 MP" },
  "Battery": { "Capacity": "5000 mAh", "Charging": "45W Fast Charging" },
  "Connectivity": { "5G": "Yes", "WiFi": "WiFi 6E", "Bluetooth": "5.3" }
}

Normalize: "16GB" → "16 GB", "6.7\"" → "6.7 inches", all values standardized.`;

  const response = await openai.chat.completions.create({
    model: 'gpt-4-turbo-preview',
    messages: [{ role: 'user', content: prompt }],
    max_tokens: 1000,
    temperature: 0.1, // Low temp for accuracy
  });

  try {
    return JSON.parse(response.choices[0].message.content || '{}');
  } catch (e) {
    return {};
  }
}

// ─── SEO Content Generator ────────────────────────────────

export async function generateSeoContent(params: {
  type: 'buying_guide' | 'comparison' | 'top10' | 'faq';
  topic: string;
  products?: string[];
  category?: string;
  keywords?: string[];
}): Promise<{ title: string; content: string; metaDesc: string; faqs: Array<{q: string; a: string}> }> {
  const prompt = `Generate SEO-optimized content for AIComp (India's AI electronics comparison platform).

Type: ${params.type}
Topic: ${params.topic}
Category: ${params.category || 'General Electronics'}
Target Keywords: ${params.keywords?.join(', ') || params.topic}
Products to mention: ${params.products?.join(', ') || 'top products in category'}

Requirements:
- Write for Indian audience (₹ prices, Indian sellers like Amazon India, Flipkart)
- 800-1200 words for guides, 400-600 for comparisons
- Include H2/H3 headings with ## / ###
- Natural keyword integration
- Add buying advice specific to Indian market

Return ONLY valid JSON:
{
  "title": "SEO title (under 60 chars)",
  "content": "Full markdown content",
  "metaDesc": "Meta description (under 160 chars)",
  "faqs": [
    {"q": "Frequently asked question", "a": "Comprehensive answer"}
  ]
}`;

  const response = await openai.chat.completions.create({
    model: 'gpt-4-turbo-preview',
    messages: [{ role: 'user', content: prompt }],
    max_tokens: 2000,
    temperature: 0.7,
  });

  try {
    return JSON.parse(response.choices[0].message.content || '{}');
  } catch (e) {
    return { title: '', content: '', metaDesc: '', faqs: [] };
  }
}

// ─── "Should I Buy Now?" Prediction ──────────────────────

export async function predictBuyingTime(product: {
  name: string;
  currentPrice: number;
  priceHistory: Array<{ price: number; date: string }>;
  category: string;
}): Promise<{
  recommendation: 'buy_now' | 'wait' | 'good_deal';
  confidence: number;
  reasoning: string;
  predictedDrop?: string;
  bestTimeToBuy?: string;
}> {
  const prompt = `Analyze this product's price history and predict buying timing for Indian e-commerce market.

Product: ${product.name}
Current Price: ₹${product.currentPrice.toLocaleString('en-IN')}
Category: ${product.category}
Price History (last 30 entries): ${JSON.stringify(product.priceHistory.slice(-30))}

Consider:
- Indian sale events: Republic Day (Jan), Holi (Mar), Independence Day (Aug), Navratri (Oct), Diwali (Oct-Nov), 11.11 Sale, Black Friday, Christmas
- Seasonal demand patterns for ${product.category}
- Price trend direction

Return ONLY valid JSON:
{
  "recommendation": "buy_now|wait|good_deal",
  "confidence": 0.85,
  "reasoning": "2 sentence explanation",
  "predictedDrop": "Estimated % price drop if waiting",
  "bestTimeToBuy": "When to buy if waiting (e.g. 'Diwali sale, ~October')"
}`;

  const response = await openai.chat.completions.create({
    model: 'gpt-4-turbo-preview',
    messages: [{ role: 'user', content: prompt }],
    max_tokens: 300,
    temperature: 0.3,
  });

  try {
    return JSON.parse(response.choices[0].message.content || '{}');
  } catch (e) {
    return { recommendation: 'good_deal', confidence: 0.5, reasoning: 'Unable to analyze price data.' };
  }
}

// ─── Review Sentiment Analysis ────────────────────────────

export async function analyzeReviews(reviews: string[]): Promise<{
  sentiment: 'positive' | 'negative' | 'mixed';
  score: number;
  commonPraises: string[];
  commonComplaints: string[];
  summary: string;
}> {
  const cacheKey = `ai:reviews:${Buffer.from(reviews.join('').slice(0, 100)).toString('base64')}`;
  const cached = await cache.get(cacheKey);
  if (cached) return JSON.parse(cached);

  const prompt = `Analyze these product reviews and extract insights.

Reviews:
${reviews.slice(0, 20).map((r, i) => `${i+1}. ${r.slice(0, 200)}`).join('\n')}

Return ONLY valid JSON:
{
  "sentiment": "positive|negative|mixed",
  "score": 0.75,
  "commonPraises": ["praise1", "praise2", "praise3"],
  "commonComplaints": ["complaint1", "complaint2", "complaint3"],
  "summary": "2 sentence review summary"
}`;

  const response = await openai.chat.completions.create({
    model: 'gpt-4-turbo-preview',
    messages: [{ role: 'user', content: prompt }],
    max_tokens: 400,
    temperature: 0.3,
  });

  try {
    const result = JSON.parse(response.choices[0].message.content || '{}');
    await cache.setEx(cacheKey, 86400, JSON.stringify(result));
    return result;
  } catch (e) {
    return { sentiment: 'mixed', score: 0.5, commonPraises: [], commonComplaints: [], summary: '' };
  }
}

// ─── Product Score Calculator ─────────────────────────────

export async function calculateAiScores(product: Product): Promise<Record<string, number>> {
  const prompt = `Calculate AI scores (0-100) for this ${product.category} product based on specs.

Product: ${product.name}
Specs: ${JSON.stringify(product.specs)}
Price: ₹${product.price?.toLocaleString('en-IN') || 'Unknown'}

Return ONLY valid JSON with scores 0-100:
{
  "gaming": 85,
  "battery": 78,
  "camera": 92,
  "performance": 88,
  "value": 76,
  "cooling": 82,
  "repairability": 65,
  "overall": 84
}`;

  const response = await openai.chat.completions.create({
    model: 'gpt-4-turbo-preview',
    messages: [{ role: 'user', content: prompt }],
    max_tokens: 200,
    temperature: 0.2,
  });

  try {
    return JSON.parse(response.choices[0].message.content || '{}');
  } catch (e) {
    return {};
  }
}

export default {
  chatWithAI,
  streamChatWithAI,
  generateProductSummary,
  generateComparisonVerdict,
  extractAndNormalizeSpecs,
  generateSeoContent,
  predictBuyingTime,
  analyzeReviews,
  calculateAiScores,
};
