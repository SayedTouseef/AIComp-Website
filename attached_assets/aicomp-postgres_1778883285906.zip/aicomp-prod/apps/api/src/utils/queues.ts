import Queue from 'bull';

const redisConfig = {
  redis: {
    host: process.env.REDIS_HOST || 'localhost',
    port: parseInt(process.env.REDIS_PORT || '6379'),
    password: process.env.REDIS_PASSWORD || undefined,
  },
  defaultJobOptions: {
    removeOnComplete: 100,
    removeOnFail: 50,
    attempts: 3,
    backoff: { type: 'exponential' as const, delay: 5000 },
  },
};

export const priceQueue = new Queue('price-updates', redisConfig);
export const notificationQueue = new Queue('notifications', redisConfig);
export const crawlerQueue = new Queue('crawler', redisConfig);
export const seoQueue = new Queue('seo-generation', redisConfig);
export const affiliateQueue = new Queue('affiliate-clicks', redisConfig);
