import { createClient } from 'redis';
import { logger } from './logger';

const client = createClient({
  socket: {
    host: process.env.REDIS_HOST || 'localhost',
    port: parseInt(process.env.REDIS_PORT || '6379'),
  },
  password: process.env.REDIS_PASSWORD || undefined,
});

client.on('error', (err) => logger.error('Redis error:', err));
client.on('connect', () => logger.info('✅ Redis connected'));

client.connect().catch((err) => logger.error('Redis connect failed:', err));

export const cache = {
  get: async (key: string): Promise<string | null> => {
    try { return await client.get(key); }
    catch (e) { logger.warn(`Cache get failed: ${key}`, e); return null; }
  },
  set: async (key: string, value: string): Promise<void> => {
    try { await client.set(key, value); }
    catch (e) { logger.warn(`Cache set failed: ${key}`, e); }
  },
  setEx: async (key: string, ttl: number, value: string): Promise<void> => {
    try { await client.setEx(key, ttl, value); }
    catch (e) { logger.warn(`Cache setEx failed: ${key}`, e); }
  },
  del: async (key: string): Promise<void> => {
    try { await client.del(key); }
    catch (e) { logger.warn(`Cache del failed: ${key}`, e); }
  },
  delPattern: async (pattern: string): Promise<void> => {
    try {
      const keys = await client.keys(pattern);
      if (keys.length) await client.del(keys);
    } catch (e) { logger.warn(`Cache delPattern failed: ${pattern}`, e); }
  },
  incr: async (key: string): Promise<number> => {
    try { return await client.incr(key); }
    catch { return 0; }
  },
  exists: async (key: string): Promise<boolean> => {
    try { return (await client.exists(key)) > 0; }
    catch { return false; }
  },
  ttl: async (key: string): Promise<number> => {
    try { return await client.ttl(key); }
    catch { return -1; }
  },
};

export default client;
