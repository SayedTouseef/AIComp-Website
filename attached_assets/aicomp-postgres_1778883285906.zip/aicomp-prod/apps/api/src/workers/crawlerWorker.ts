import cron from 'node-cron';
import Queue from 'bull';
import { discoverNewProducts, scrapeAmazonPrice } from '../services/crawlerService';
import { PrismaClient } from '@prisma/client';
import { logger } from '../utils/logger';
import { crawlerQueue } from '../utils/queues';

const prisma = new PrismaClient();

const DISCOVERY_CATEGORIES = [
  'smartphone', 'laptop', 'television 4k', 'inverter air conditioner',
  'gaming laptop', 'mirrorless camera', 'gaming monitor', 'wireless earbuds',
  'smartwatch', 'refrigerator', 'washing machine front load', 'graphics card RTX',
];

// ─── Process crawler jobs ─────────────────────────────────

crawlerQueue.process('discover', 2, async (job) => {
  const { category, source = 'amazon', page = 1 } = job.data;
  logger.info(`Crawling: ${category} from ${source} page ${page}`);

  const discovered = await discoverNewProducts(category, page);

  for (const product of discovered) {
    // Check if product already exists (by name similarity)
    const existing = await prisma.product.findFirst({
      where: { name: { contains: product.name.slice(0, 30), mode: 'insensitive' } },
    });
    if (existing) continue;

    // Find or create brand
    let brand = await prisma.brand.findFirst({ where: { name: { contains: product.brand, mode: 'insensitive' } } });
    if (!brand) {
      brand = await prisma.brand.create({ data: { name: product.brand, slug: product.brand.toLowerCase().replace(/\s+/g, '-') } });
    }

    // Find default category (map crawler category to DB category)
    const categorySlug = mapToCategory(category);
    const cat = await prisma.category.findUnique({ where: { slug: categorySlug } });
    if (!cat) continue;

    // Create product
    const slug = `${product.name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '')}-${Date.now()}`;
    await prisma.product.create({
      data: {
        name: product.name,
        slug,
        brandId: brand.id,
        categoryId: cat.id,
        images: product.images,
        thumbnail: product.images[0] || null,
        status: 'PENDING', // requires manual approval
      },
    });
  }

  logger.info(`Discovery complete: ${discovered.length} found for "${category}"`);
  return { discovered: discovered.length };
});

crawlerQueue.process('update-price', 5, async (job) => {
  const { productId, asin, url, network } = job.data;

  let priceData: any;
  if (network === 'AMAZON' && asin) {
    priceData = await scrapeAmazonPrice(asin);
  }

  if (priceData?.price) {
    await prisma.priceHistory.create({ data: { productId, price: priceData.price } });
  }

  return priceData;
});

// ─── Cron schedules ────────────────────────────────────────

export function startCrawlerWorker() {
  logger.info('🕷️  Starting crawler worker...');

  // Discover new products daily at 3 AM
  cron.schedule('0 3 * * *', async () => {
    logger.info('🔍 Starting product discovery crawl...');
    for (const [i, category] of DISCOVERY_CATEGORIES.entries()) {
      await crawlerQueue.add('discover', { category, page: 1 }, {
        delay: i * 30000, // 30 sec between categories
        priority: 5,
      });
    }
  });

  // Re-crawl page 2 of popular categories weekly
  cron.schedule('0 4 * * 1', async () => {
    const hotCategories = ['smartphone', 'laptop', 'gaming laptop'];
    for (const cat of hotCategories) {
      for (let page = 2; page <= 5; page++) {
        await crawlerQueue.add('discover', { category: cat, page }, { delay: page * 60000 });
      }
    }
  });

  logger.info('✅ Crawler cron jobs registered');
}

// ─── Category mapping ─────────────────────────────────────

function mapToCategory(crawlerCategory: string): string {
  const lower = crawlerCategory.toLowerCase();
  if (lower.includes('smartphone') || lower.includes('phone')) return 'smartphones';
  if (lower.includes('laptop') || lower.includes('notebook')) return 'laptops';
  if (lower.includes('tv') || lower.includes('television')) return 'tvs';
  if (lower.includes('air condition') || lower.includes(' ac ')) return 'air-conditioners';
  if (lower.includes('camera')) return 'cameras';
  if (lower.includes('monitor')) return 'monitors';
  if (lower.includes('earbuds') || lower.includes('headphone')) return 'headphones';
  if (lower.includes('smartwatch') || lower.includes('watch')) return 'smartwatches';
  if (lower.includes('refrigerator') || lower.includes('fridge')) return 'refrigerators';
  if (lower.includes('washing')) return 'washing-machines';
  if (lower.includes('gpu') || lower.includes('graphics')) return 'gpus';
  return 'smartphones'; // fallback
}
