import cron from 'node-cron';
import Queue from 'bull';
import { updateAllPrices, scrapeAmazonPrice, scrapeFlipkartPrice } from '../services/crawlerService';
import { PrismaClient } from '@prisma/client';
import { logger } from '../utils/logger';
import { sendNotification } from '../services/notificationService';
import { cache } from '../utils/cache';

const prisma = new PrismaClient();

// Queues
export const priceQueue = new Queue('price-updates', {
  redis: { host: process.env.REDIS_HOST || 'localhost', port: 6379 },
  defaultJobOptions: {
    removeOnComplete: 100,
    removeOnFail: 50,
    attempts: 3,
    backoff: { type: 'exponential', delay: 5000 },
  },
});

export const notificationQueue = new Queue('notifications', {
  redis: { host: process.env.REDIS_HOST || 'localhost', port: 6379 },
});

// ─── Queue processors ──────────────────────────────────────

priceQueue.process('update-product-price', 5, async (job) => {
  const { productId, affiliateLinkId, network, identifier } = job.data;

  let priceData: any = null;

  if (network === 'AMAZON') {
    priceData = await scrapeAmazonPrice(identifier);
  } else if (network === 'FLIPKART') {
    priceData = await scrapeFlipkartPrice(identifier);
  }

  if (!priceData?.price) {
    logger.warn(`No price data for product ${productId}`);
    return;
  }

  // Get current price
  const currentPrice = await prisma.productPrice.findFirst({
    where: { productId, seller: { name: network } },
    select: { price: true },
  });

  // Update price
  await prisma.$transaction([
    prisma.productPrice.upsert({
      where: { productId_sellerId: { productId, sellerId: job.data.sellerId } },
      update: {
        price: priceData.price,
        mrp: priceData.mrp,
        inStock: priceData.inStock,
        lastChecked: new Date(),
        discount: priceData.mrp ? Math.round((1 - priceData.price / priceData.mrp) * 100) : null,
      },
      create: {
        productId,
        sellerId: job.data.sellerId,
        price: priceData.price,
        mrp: priceData.mrp,
        inStock: priceData.inStock,
        affiliateUrl: job.data.url,
      },
    }),
    prisma.priceHistory.create({
      data: { productId, sellerId: job.data.sellerId, price: priceData.price },
    }),
  ]);

  // Detect price drops
  if (currentPrice && priceData.price < currentPrice.price) {
    const dropPct = Math.round((1 - priceData.price / currentPrice.price) * 100);
    logger.info(`Price drop detected: ${productId} -${dropPct}% (₹${priceData.price / 100})`);

    // Check alerts
    await priceQueue.add('send-price-alert', {
      productId,
      newPrice: priceData.price,
      oldPrice: currentPrice.price,
      dropPct,
    });
  }

  // Invalidate product cache
  await cache.del(`product:${job.data.slug}`);
});

priceQueue.process('send-price-alert', 10, async (job) => {
  const { productId, newPrice, oldPrice, dropPct } = job.data;

  const product = await prisma.product.findUnique({
    where: { id: productId },
    select: { name: true, slug: true, thumbnail: true },
  });
  if (!product) return;

  const alerts = await prisma.priceAlert.findMany({
    where: {
      productId,
      isActive: true,
      OR: [
        { targetPrice: null },
        { targetPrice: { gte: newPrice } },
      ],
    },
    include: {
      user: {
        select: {
          email: true,
          name: true,
          profile: { select: { pushToken: true, telegramChatId: true, whatsappNumber: true } },
        },
      },
    },
  });

  for (const alert of alerts) {
    for (const channel of alert.channels) {
      await notificationQueue.add('send', {
        channel,
        userId: alert.userId,
        user: alert.user,
        product,
        title: `💰 Price Drop: ${product.name}`,
        body: `Now ₹${(newPrice / 100).toLocaleString('en-IN')} (${dropPct}% off)`,
        imageUrl: product.thumbnail,
        actionUrl: `https://aicomp.in/product/${product.slug}`,
      });
    }

    // Mark alert as triggered
    await prisma.priceAlert.update({
      where: { id: alert.id },
      data: { triggeredAt: new Date() },
    });

    // Save notification record
    await prisma.notification.create({
      data: {
        userId: alert.userId,
        title: `💰 Price Drop: ${product.name}`,
        body: `Price dropped by ${dropPct}% — now ₹${(newPrice / 100).toLocaleString('en-IN')}`,
        actionUrl: `https://aicomp.in/product/${product.slug}`,
        imageUrl: product.thumbnail,
        channel: channel as any,
      },
    });
  }
});

// ─── Cron schedules ────────────────────────────────────────

export function startPriceWorker() {
  logger.info('⚙️  Starting price update worker...');

  // Every 4 hours — full price update
  cron.schedule('0 */4 * * *', async () => {
    logger.info('🔄 Starting scheduled price update...');
    try {
      await updateAllPrices();
    } catch (err) {
      logger.error('Scheduled price update failed:', err);
    }
  });

  // Every 30 min — update trending/featured products (higher priority)
  cron.schedule('*/30 * * * *', async () => {
    const hotProducts = await prisma.product.findMany({
      where: { status: 'APPROVED', OR: [{ isTrending: true }, { isFeatured: true }] },
      include: {
        affiliateLinks: { where: { isActive: true }, take: 3 },
      },
      take: 50,
    });

    for (const product of hotProducts) {
      for (const link of product.affiliateLinks) {
        await priceQueue.add('update-product-price', {
          productId: product.id,
          slug: product.slug,
          affiliateLinkId: link.id,
          network: link.network,
          identifier: link.trackingId || link.url,
          sellerId: link.sellerId,
          url: link.url,
        }, { priority: 1 });
      }
    }
  });

  // Daily at 2 AM — update deal detection
  cron.schedule('0 2 * * *', async () => {
    logger.info('🏷️  Running daily deal detection...');
    await detectDeals();
  });

  // Update trending products hourly
  cron.schedule('0 * * * *', async () => {
    await updateTrendingProducts();
  });

  logger.info('✅ Price worker cron jobs registered');
}

// ─── Deal detection ────────────────────────────────────────

async function detectDeals() {
  const products = await prisma.product.findMany({
    where: { status: 'APPROVED' },
    include: {
      prices: { orderBy: { price: 'asc' }, take: 1 },
      priceHistory: { orderBy: { recordedAt: 'desc' }, take: 30, select: { price: true } },
    },
    take: 500,
  });

  let dealsFound = 0;

  for (const product of products) {
    if (!product.prices[0] || product.priceHistory.length < 7) continue;

    const currentPrice = product.prices[0].price;
    const historyPrices = product.priceHistory.map(h => h.price);
    const avgPrice = historyPrices.reduce((s, p) => s + p, 0) / historyPrices.length;
    const minHistoricPrice = Math.min(...historyPrices);

    // Deal if >10% below average
    if (currentPrice < avgPrice * 0.9) {
      dealsFound++;
      // Could tag as deal, send to deals feed, etc.
    }
  }

  logger.info(`Deal detection complete: ${dealsFound} deals found`);
}

// ─── Trending products updater ─────────────────────────────

async function updateTrendingProducts() {
  // Get products with highest recent search/view activity
  const recentSearches = await prisma.searchLog.groupBy({
    by: ['clicked'],
    _count: { clicked: true },
    where: {
      clicked: { not: null },
      createdAt: { gte: new Date(Date.now() - 86400000 * 7) },
    },
    orderBy: { _count: { clicked: 'desc' } },
    take: 20,
  });

  const trendingSlugs = recentSearches
    .filter(r => r.clicked)
    .map(r => r.clicked as string);

  // Update trending flags
  await prisma.product.updateMany({ data: { isTrending: false } }); // reset all
  if (trendingSlugs.length > 0) {
    await prisma.product.updateMany({
      where: { slug: { in: trendingSlugs } },
      data: { isTrending: true },
    });
  }
}

export default priceQueue;
