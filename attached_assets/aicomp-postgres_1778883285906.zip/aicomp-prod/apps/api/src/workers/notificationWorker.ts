import { notificationQueue } from '../utils/queues';
import { sendNotification } from '../services/notificationService';
import { logger } from '../utils/logger';

// Process notification jobs from the queue
notificationQueue.process('send', 10, async (job) => {
  const { channel, user, product, title, body, imageUrl, actionUrl } = job.data;

  const contactInfo = {
    email: user.email,
    name: user.name,
    pushToken: user.profile?.pushToken,
    telegramChatId: user.profile?.telegramChatId,
    whatsappNumber: user.profile?.whatsappNumber,
  };

  const payload = { title, body, imageUrl, actionUrl };

  const success = await sendNotification(channel, contactInfo, payload);

  if (!success) {
    throw new Error(`Notification failed: ${channel} for user ${user.id || user.email}`);
  }

  return { sent: true, channel };
});

notificationQueue.on('completed', (job) => {
  logger.info(`Notification sent: ${job.data.channel} to ${job.data.user?.email}`);
});

notificationQueue.on('failed', (job, err) => {
  logger.error(`Notification failed: ${job.data.channel}`, err);
});

export function startNotificationWorker() {
  logger.info('🔔 Notification queue processor active');
}
