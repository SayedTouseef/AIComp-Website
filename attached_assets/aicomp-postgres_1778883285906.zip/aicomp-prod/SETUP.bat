@echo off
echo ===============================================
echo   AIComp — First-Time Setup
echo   PostgreSQL user: postgres / admin123
echo ===============================================
echo.

echo [1/5] Installing dependencies...
call pnpm install
if errorlevel 1 (
  echo pnpm not found, trying npm...
  cd apps\web   && npm install --legacy-peer-deps && cd ..\..
  cd apps\api   && npm install --legacy-peer-deps && cd ..\..
  cd apps\admin && npm install --legacy-peer-deps && cd ..\..
  cd packages\database && npm install --legacy-peer-deps && cd ..\..
)

echo.
echo [2/5] Setting up .env file...
if not exist .env (
  copy .env.example .env
  echo ✅ .env created with your postgres:admin123 credentials
) else (
  echo .env already exists — skipping
)

echo.
echo [3/5] Creating database...
set PGPASSWORD=admin123
psql -U postgres -c "CREATE DATABASE aicomp;" 2>nul
if errorlevel 1 (
  echo Database aicomp may already exist — continuing...
)

echo.
echo [4/5] Creating tables (Prisma push)...
set DATABASE_URL=postgresql://postgres:admin123@localhost:5432/aicomp
cd packages\database
npx prisma db push
cd ..\..

echo.
echo [5/5] Seeding database (categories, brands, admin user)...
set DATABASE_URL=postgresql://postgres:admin123@localhost:5432/aicomp
cd packages\database
npx tsx seed-pg.ts
cd ..\..

echo.
echo ===============================================
echo   ✅ Setup complete!
echo.
echo   Admin login: admin@aicomp.in
echo   Password:    admin@aicomp123
echo.
echo   Run START.bat to launch all services
echo ===============================================
pause
