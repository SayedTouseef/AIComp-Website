@echo off
echo ===============================================
echo   AIComp — Starting All Services
echo ===============================================
echo.

set DATABASE_URL=postgresql://postgres:admin123@localhost:5432/aicomp
set NEXT_PUBLIC_API_URL=http://localhost:4000
set NODE_ENV=development

echo [1/3] Starting API on http://localhost:4000
start "AIComp API" cmd /k "set DATABASE_URL=postgresql://postgres:admin123@localhost:5432/aicomp && cd /d %~dp0apps\api && npx tsx src\index.ts"
timeout /t 4 /nobreak > nul

echo [2/3] Starting Web on http://localhost:3000
start "AIComp Web" cmd /k "set NEXT_PUBLIC_API_URL=http://localhost:4000 && cd /d %~dp0apps\web && npx next dev -p 3000"

echo [3/3] Starting Admin on http://localhost:3001
start "AIComp Admin" cmd /k "cd /d %~dp0apps\admin && npx next dev -p 3001"

echo.
echo ✅ All services launching in separate windows
echo.
echo   Web:   http://localhost:3000
echo   Admin: http://localhost:3001
echo   API:   http://localhost:4000/health
echo.
echo   Admin login: admin@aicomp.in / admin@aicomp123
echo.
pause
